import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { collection, query, where, getDocs, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Navbar } from '../components/Navbar';
import { Escrow } from '../components/EscrowCard';
import { Search, ArrowDownLeft, ArrowUpRight, Clock, CheckCircle2, XCircle, Filter, Calendar, Info, ShoppingBag, Store, Truck, FileDown, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { DisputeModal } from '../components/DisputeModal';
import { generateReceiptPDF } from '../utils/receiptGenerator';
import { getQRBase64 } from '../utils/qrHelper';

export function TransactionsView() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Escrow[]>([]);
  const [pdfLoadingMap, setPdfLoadingMap] = useState<Record<string, boolean>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'completed' | 'pending'>('all');
  const [selectedEscrow, setSelectedEscrow] = useState<Escrow | null>(null);

  const [buyingTx, setBuyingTx] = useState<Escrow[]>([]);
  const [sellingTx, setSellingTx] = useState<Escrow[]>([]);

  useEffect(() => {
    if (!user?.uid) return;

    const q1 = query(collection(db, 'escrows'), where('buyerId', '==', user.uid));
    const unsub1 = onSnapshot(q1, (snap1) => {
      const list = snap1.docs.map(doc => ({ id: doc.id, ...doc.data() } as Escrow));
      setBuyingTx(list);
    }, (err) => {
      console.warn("Failed to listen buying transactions in real-time:", err);
    });

    const q2 = query(collection(db, 'escrows'), where('sellerId', '==', user.uid));
    const unsub2 = onSnapshot(q2, (snap2) => {
      const list = snap2.docs.map(doc => ({ id: doc.id, ...doc.data() } as Escrow));
      setSellingTx(list);
    }, (err) => {
      console.warn("Failed to listen selling transactions in real-time:", err);
    });

    return () => {
      unsub1();
      unsub2();
    };
  }, [user?.uid]);

  useEffect(() => {
    const merged = [...buyingTx, ...sellingTx].sort((a, b) => {
      const aDate = a.createdAt?.seconds ? a.createdAt.seconds * 1000 : (a.createdAt ? new Date(a.createdAt).getTime() : 0);
      const bDate = b.createdAt?.seconds ? b.createdAt.seconds * 1000 : (b.createdAt ? new Date(b.createdAt).getTime() : 0);
      return bDate - aDate;
    });

    // Unique records de-duplication
    const uniqueMerged = Array.from(new Map(merged.map(item => [item.id, item])).values());
    setTransactions(uniqueMerged);
  }, [buyingTx, sellingTx]);

  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.itemDescription.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         t.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filter === 'all' ? true : 
                         filter === 'completed' ? t.status === 'COMPLETED' : 
                         ['PROPOSED', 'ACCEPTED', 'FUNDED', 'SHIPPED', 'DELIVERED', 'DISPUTED'].includes(t.status);
    
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED': return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case 'CANCELLED': return <XCircle className="w-4 h-4 text-rose-500" />;
      case 'DISPUTED': return <Info className="w-4 h-4 text-amber-500" />;
      default: return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'COMPLETED': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'CANCELLED': return 'bg-rose-50 text-rose-700 border-rose-100';
      case 'DISPUTED': return 'bg-amber-50 text-amber-700 border-amber-100 animate-pulse';
      case 'ACCEPTED': return 'bg-indigo-50 text-indigo-700 border-indigo-100';
      case 'SHIPPED': return 'bg-violet-50 text-violet-700 border-violet-100';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Transaction History</h1>
            <p className="text-slate-500 mt-1 font-medium">All your secure payments and escrow records.</p>
          </div>
          
          <div className="flex items-center gap-3 bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
            <button 
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'all' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              All
            </button>
            <button 
              onClick={() => setFilter('completed')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'completed' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              Completed
            </button>
            <button 
              onClick={() => setFilter('pending')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'pending' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              Active
            </button>
          </div>
        </div>

        {/* Search & Stats Bar */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text"
              placeholder="Search by description or transaction ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-4 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
            />
          </div>
          <div className="bg-emerald-600 rounded-2xl p-4 flex flex-col justify-center text-white shadow-lg shadow-emerald-600/20">
            <span className="text-[10px] font-black uppercase tracking-widest opacity-80">Total Transactions</span>
            <span className="text-2xl font-black">{transactions.length}</span>
          </div>
        </div>

        {/* Transactions List */}
        <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/60 overflow-hidden border border-slate-100">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                  <th className="px-8 py-5">Date & Transaction</th>
                  <th className="px-8 py-5">Type</th>
                  <th className="px-8 py-5 text-right">Amount</th>
                  <th className="px-8 py-5 text-right">Status</th>
                  <th className="px-8 py-5 text-right">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-8 py-20 text-center">
                      <div className="bg-slate-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <Filter className="w-8 h-8 text-slate-200" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">No matching records</h3>
                      <p className="text-slate-500 text-sm">Try adjusting your filters or search term.</p>
                    </td>
                  </tr>
                ) : (
                  filteredTransactions.map((t, i) => {
                    const isBuyer = t.buyerId === user?.uid;
                    const dateObj = t.createdAt?.seconds ? new Date(t.createdAt.seconds * 1000) : (t.createdAt ? new Date(t.createdAt) : null);
                    const date = dateObj && !isNaN(dateObj.getTime()) ? dateObj.toLocaleDateString('en-PK', {
                      timeZone: 'Asia/Karachi',
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric'
                    }) : 'Pending';
                    const time = dateObj && !isNaN(dateObj.getTime()) ? dateObj.toLocaleTimeString('en-PK', {
                      timeZone: 'Asia/Karachi',
                      hour: '2-digit',
                      minute: '2-digit',
                      hour12: true
                    }) : '';

                    return (
                      <motion.tr 
                        key={t.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => t.status === 'DISPUTED' && setSelectedEscrow(t)}
                        className={`group transition-colors ${t.status === 'DISPUTED' ? 'cursor-pointer hover:bg-amber-50/50' : 'hover:bg-slate-50/80'}`}
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${isBuyer ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                              {isBuyer ? <ShoppingBag className="w-6 h-6" /> : <Store className="w-6 h-6" />}
                            </div>
                            <div>
                              <p className="font-black text-slate-900 group-hover:text-emerald-700 transition-colors uppercase text-sm tracking-tight">{t.itemDescription}</p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <Calendar className="w-3 h-3 text-slate-300" />
                                <span className="text-xs font-bold text-slate-400">{date} {time && `• ${time}`}</span>
                                <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono font-bold tracking-tighter">ID: {t.id.slice(0, 8)}...</span>
                              </div>
                              {t.trackingId && (
                                <div className="mt-1 flex items-center gap-1.5 text-indigo-600">
                                  <Truck className="w-3 h-3" />
                                  <span className="text-[10px] font-black uppercase tracking-tighter">Track: {t.trackingId}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-2">
                            {isBuyer ? (
                              <ArrowUpRight className="w-4 h-4 text-rose-500" />
                            ) : (
                              <ArrowDownLeft className="w-4 h-4 text-emerald-500" />
                            )}
                            <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-lg ${isBuyer ? 'bg-rose-50 text-rose-700 border border-rose-100' : 'bg-emerald-50 text-emerald-700 border border-emerald-100'}`}>
                              {isBuyer ? 'Buyer' : 'Seller'}
                            </span>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <span className={`text-lg font-black tracking-tighter ${isBuyer ? 'text-slate-900' : 'text-emerald-600'}`}>
                            {isBuyer ? '-' : '+'}Rs. {t.amount.toLocaleString()}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="flex flex-col items-end gap-1">
                            <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[10px] font-black uppercase tracking-wider ${getStatusStyles(t.status)}`}>
                              {getStatusIcon(t.status)}
                              {t.status}
                            </div>
                            {t.status === 'DISPUTED' && (
                              <span className="text-[9px] font-black text-amber-600 uppercase tracking-tighter opacity-0 group-hover:opacity-100 transition-opacity">
                                Click to Review Dispute
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <button
                            type="button"
                            title="Download Secure PDF Receipt"
                            disabled={pdfLoadingMap[t.id]}
                            onClick={async (e) => {
                              e.stopPropagation();
                              setPdfLoadingMap(prev => ({ ...prev, [t.id]: true }));
                              try {
                                const verifyLink = `${window.location.origin}/?verify=${t.id}`;
                                const qrDataUrl = await getQRBase64(verifyLink);
                                const pdf = generateReceiptPDF(t, isBuyer, 'Counterparty Trader', qrDataUrl);
                                const rawName = t.itemDescription ? t.itemDescription.trim() : 'Secured_Receipt';
                                const sanitized = rawName.replace(/[/\\?%*:|"<>]/g, '-').replace(/\s+/g, '_').trim();
                                const shortId = t.id ? t.id.substring(0, 6).toUpperCase() : 'RC';
                                const safeName = `${sanitized}_ID_${shortId}`;
                                pdf.save(`${safeName}.pdf`);
                              } catch (err) {
                                console.error('Error generating transaction PDF on list:', err);
                              } finally {
                                setPdfLoadingMap(prev => ({ ...prev, [t.id]: false }));
                              }
                            }}
                            className="inline-flex items-center justify-center p-2.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 rounded-xl transition-all cursor-pointer h-10 w-10 active:scale-90 shadow-sm border border-slate-200"
                          >
                            {pdfLoadingMap[t.id] ? (
                              <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
                            ) : (
                              <FileDown className="w-4 h-4 text-emerald-600" />
                            )}
                          </button>
                        </td>
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {selectedEscrow && (
        <DisputeModal 
          isOpen={!!selectedEscrow} 
          onClose={() => setSelectedEscrow(null)} 
          escrow={selectedEscrow}
        />
      )}
    </div>
  );
}

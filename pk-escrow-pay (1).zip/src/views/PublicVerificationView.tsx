import React, { useEffect, useState } from 'react';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Escrow } from '../components/EscrowCard';
import { 
  ShieldCheck, 
  Search, 
  Lock, 
  Unlock, 
  FileCheck, 
  Calendar, 
  Building2, 
  Heart, 
  ThumbsUp,
  AlertOctagon,
  Copy,
  Check,
  ChevronRight,
  Globe
} from 'lucide-react';
import { motion } from 'motion/react';

interface PublicVerificationViewProps {
  verifyId?: string;
}

export function PublicVerificationView({ verifyId: initialVerifyId }: PublicVerificationViewProps) {
  const [verifyId, setVerifyId] = useState(initialVerifyId || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [escrow, setEscrow] = useState<Escrow | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [lang, setLang] = useState<'en' | 'ur'>('en');

  const fetchEscrow = async (targetId: string) => {
    if (!targetId.trim()) return;
    setLoading(true);
    setErrorMsg('');
    setEscrow(null);
    try {
      // 1. Try to fetch directly by Document ID first
      const docRef = doc(db, 'escrows', targetId.trim());
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setEscrow({ id: docSnap.id, ...docSnap.data() } as Escrow);
        setVerifyId(targetId.trim());
        // Standardize the URL for sharing if someone pastes search query
        const url = new URL(window.location.href);
        url.searchParams.set('verify', targetId.trim());
        window.history.replaceState({}, '', url.toString());
      } else {
        // 2. Try partial search by prefix or looking up as fallback
        const escrowsCol = collection(db, 'escrows');
        const q = query(escrowsCol);
        const querySnap = await getDocs(q);
        
        const matched = querySnap.docs.find(d => 
          d.id.toLowerCase().startsWith(targetId.trim().toLowerCase())
        );

        if (matched) {
          setEscrow({ id: matched.id, ...matched.data() } as Escrow);
          setVerifyId(matched.id);
          const url = new URL(window.location.href);
          url.searchParams.set('verify', matched.id);
          window.history.replaceState({}, '', url.toString());
        } else {
          setErrorMsg(
            lang === 'ur' 
              ? 'معاہدہ ریفرنس کوڈ درست نہیں ہے یا یہ سسٹم سے خارج ہو چکا ہے۔ برائے مہربانی درست کوڈ درج کریں۔' 
              : 'Escrow reference code not found. Please double-check the digital lock ID.'
          );
        }
      }
    } catch (err) {
      console.error('Error verifying transaction:', err);
      setErrorMsg('Failed to query compliance database. Network issue.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialVerifyId) {
      fetchEscrow(initialVerifyId);
    }
  }, [initialVerifyId]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      fetchEscrow(searchQuery.trim());
    }
  };

  const copyVerificationLink = () => {
    const link = `${window.location.origin}/?verify=${verifyId}`;
    navigator.clipboard.writeText(link).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Status visual configurations
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'PAYMENT_PENDING':
        return {
          title: lang === 'ur' ? 'ادائیگی کا انتظار' : 'PAYMENT PENDING',
          desc: lang === 'ur' ? 'خریدار کی طرف سے فنڈز لاک کرنے کا انتظار ہے' : 'Waiting for buyer to transfer assets into the securing channel.',
          color: 'bg-amber-100 text-amber-800 border-amber-200',
          indicator: 'bg-amber-500',
          step: 1
        };
      case 'FUNDS_LOCKED':
        return {
          title: lang === 'ur' ? 'رقم امانت میں محفوظ' : 'FUNDS SECURED & LOCKED',
          desc: lang === 'ur' ? 'رقم امانت والٹ میں کامیابی سے لاک کر دی گئی ہے' : 'Funds are successfully locked inside PK Escrow multi-sig vault.',
          color: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          indicator: 'bg-indigo-600',
          step: 2
        };
      case 'SHIPPED':
        return {
          title: lang === 'ur' ? 'سامان بھیج دیا گیا ہے' : 'ASSETS DISPATCHED / SHIPPED',
          desc: lang === 'ur' ? 'بیچنے والے نے ٹرانزٹ روانگی فراہم کی ہے' : 'The seller has dispatched the goods and provided official courier details.',
          color: 'bg-cyan-100 text-cyan-800 border-cyan-200',
          indicator: 'bg-cyan-500',
          step: 3
        };
      case 'COMPLETED':
        return {
          title: lang === 'ur' ? 'سودا مکمل شدہ' : 'ESCROW AGREEMENT COMPLETED',
          desc: lang === 'ur' ? 'سودا کامیابی کے ساتھ مکمل اور فنڈز ریلیز ہو چکے ہیں' : 'Agreement successfully completed. Locked holdings released to the seller.',
          color: 'bg-emerald-100 text-emerald-800 border-emerald-250',
          indicator: 'bg-emerald-600',
          step: 4
        };
      case 'DISPUTED':
        return {
          title: lang === 'ur' ? 'تنازعہ زیرِ بحث' : 'UNDER ACTIVE ARBITRATION',
          desc: lang === 'ur' ? 'فریقین کے اختلاف پر ٹرانزیکشن روک دی گئی ہے' : 'Transaction frozen due to trade dispute. Internal sovereign legal audit active.',
          color: 'bg-rose-100 text-rose-800 border-rose-200',
          indicator: 'bg-rose-500',
          step: 2
        };
      case 'CANCELLED':
        return {
          title: lang === 'ur' ? 'منسوخ شدہ' : 'DISMISSED / CANCELLED',
          desc: lang === 'ur' ? 'معاہدہ منسوخ اور فنڈز واپس ہو گئے ہیں' : 'Escrow agreement cancelled. Locked holdings returned to source.',
          color: 'bg-slate-200 text-slate-700 border-slate-300',
          indicator: 'bg-slate-500',
          step: 0
        };
      default:
        return {
          title: status,
          desc: 'Verified system parameters confirm correct transition state.',
          color: 'bg-slate-100 text-slate-800 border-slate-200',
          indicator: 'bg-slate-500',
          step: 1
        };
    }
  };

  const statusInfo = escrow ? getStatusConfig(escrow.status) : null;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Top Header Branding Row */}
      <header className="bg-slate-950 border-b border-slate-850 px-4 py-4.5 xs:px-6 sticky top-0 z-50 shadow-md">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-xl text-white shadow-lg shadow-emerald-600/10">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-wider uppercase text-white">PK Escrow Gatekeeper</h1>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Sovereign Compliance & Audits</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Lang Switcher */}
            <button
              onClick={() => setLang(l => l === 'en' ? 'ur' : 'en')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-xl text-[10px] font-bold text-slate-300 tracking-wider transition-all"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'en' ? 'اردو' : 'English'}</span>
            </button>

            <a
              href="/"
              className="text-[10px] font-black text-emerald-400 uppercase tracking-widest hover:underline bg-emerald-500/5 px-2.5 py-1.5 rounded-xl border border-emerald-500/10"
            >
              Portal Login →
            </a>
          </div>
        </div>
      </header>

      {/* Main Core Content Container */}
      <main className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-center space-y-6">
        
        {/* Title greeting */}
        <div className="text-center">
          <div className="inline-flex w-14 h-14 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 rounded-2xl items-center justify-center mb-3">
            <Lock className="w-6 h-6 animate-pulse" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white leading-tight">
            {lang === 'ur' ? 'سیکیور امانت تصدیق مرکز' : 'Sovereign Escrow Verifier'}
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-normal">
            {lang === 'ur'
              ? 'امانتی سودے کے فنڈز اور سیکیورٹی لاک اسٹیٹس کی تصدیق براہِ راست فائر اسٹور لیجر ڈیٹا بیس سے لائیو کریں۔'
              : 'Audit locked funds, courier routing, active balances, and financial legal parameters instantly.'}
          </p>
        </div>

        {/* Dynamic Search Box (Look up another escrow) */}
        <div className="bg-slate-950 border border-slate-850 rounded-3xl p-5 shadow-xl">
          <form onSubmit={handleSearch} className="space-y-4">
            <div>
              <label className="block text-[9px] font-black uppercase text-slate-450 tracking-wider mb-2 px-1">
                {lang === 'ur' ? 'امانتی سودا ریفرنس کوڈ درج کریں:' : 'SECURE LOCK REFERENCE ID:'}
              </label>
              
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                <input
                  type="text"
                  required
                  placeholder={lang === 'ur' ? 'مثال: CoJ7xY8zBpk...' : 'Paste Escrow Code / reference key...'}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3.5 pl-11 pr-4 text-xs font-black text-white focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all placeholder:text-slate-600 uppercase select-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black py-3.5 px-4 rounded-2xl text-xs uppercase tracking-widest transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin shrink-0" />
                  <span>{lang === 'ur' ? 'ڈیٹا بیس سے رابطہ لائیو...' : 'AUDITING SECURITY LEDGERS...'}</span>
                </>
              ) : (
                <>
                  <FileCheck className="w-4 h-4 text-white shrink-0" />
                  <span>{lang === 'ur' ? 'سیکیورٹی آڈٹ کریں' : 'AUTHENTICATE LEDGER STATE'}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Block */}
        {loading && !escrow && (
          <div className="bg-slate-950/40 border border-slate-850/50 rounded-3xl p-8 text-center flex flex-col items-center justify-center space-y-3 animate-pulse">
            <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs font-mono text-emerald-400 font-bold uppercase tracking-widest">CONNECTING TO PUBLIC TRUST PORTAL SECURE_CHANNELS...</p>
          </div>
        )}

        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-rose-950/20 border border-rose-900/30 p-5 rounded-3xl text-center space-y-3"
          >
            <div className="w-10 h-10 bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-500 mx-auto text-lg font-black leading-none">
              ⚠️
            </div>
            <p className="text-xs font-semibold leading-relaxed text-rose-300">
              {errorMsg}
            </p>
          </motion.div>
        )}

        {escrow && statusInfo && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-4"
          >
            {/* Primary Ledger Card */}
            <div className="bg-gradient-to-b from-slate-950 to-slate-990 border-2 border-emerald-550/30 rounded-3xl shadow-xl overflow-hidden relative">
              {/* Dynamic top bar flag */}
              <div className="bg-emerald-600 h-2 w-full" />

              {/* Verified Ribbon */}
              <div className="absolute top-6 right-6 flex items-center gap-1 text-[9px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5 animate-bounce" />
                <span>VERIFIED LOCK</span>
              </div>

              {/* Title Section */}
              <div className="p-6 pb-2 text-left space-y-1">
                <span className="text-[9px] text-slate-500 font-bold font-mono tracking-wider block">PK COMPLIANCE CERTIFICATE_X81Q</span>
                <h3 className="text-base font-black text-white tracking-tight line-clamp-2">
                  {escrow.itemDescription}
                </h3>
              </div>

              {/* Core Ledger Values */}
              <div className="mx-6 p-4 bg-slate-900 border border-slate-850 rounded-2xl grid grid-cols-2 gap-4 text-left">
                <div>
                  <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider block">Locked Escrow Fund</span>
                  <span className="text-lg font-black text-white block mt-1 font-mono">
                    Rs. {Number(escrow.amount || 0).toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-wider block">Sovereign System Fee</span>
                  <span className="text-xs font-bold text-emerald-400 block mt-2 uppercase tracking-wide">
                    {escrow.escrowFee && escrow.escrowFee > 0 ? `Rs. ${escrow.escrowFee}` : '0% PROMO FREE'}
                  </span>
                </div>
              </div>

              {/* Current Status Block */}
              <div className="p-6 space-y-4 text-left border-t border-slate-900/80 mt-2">
                <div className="space-y-1">
                  <span className="text-[9px] text-slate-450 font-black uppercase tracking-widest block">Audit standing</span>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${statusInfo.indicator} shrink-0 animate-ping`} />
                    <span className="text-sm font-black text-white uppercase tracking-tight">{statusInfo.title}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 font-medium leading-relaxed">
                    {statusInfo.desc}
                  </p>
                </div>

                {/* Progress bar graph visual model */}
                <div className="space-y-1 pt-1">
                  <div className="h-2 w-full bg-slate-900 rounded-full flex items-center overflow-hidden p-[2px] border border-slate-800">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                      style={{ width: `${Math.max(10, (statusInfo.step / 4) * 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[8px] font-mono font-bold text-slate-500 uppercase tracking-tighter">
                    <span className={statusInfo.step >= 1 ? 'text-emerald-450' : ''}>Proposed</span>
                    <span className={statusInfo.step >= 2 ? 'text-emerald-450' : ''}>Locked</span>
                    <span className={statusInfo.step >= 3 ? 'text-emerald-450' : ''}>Shipped</span>
                    <span className={statusInfo.step >= 4 ? 'text-emerald-450' : ''}>Released</span>
                  </div>
                </div>
              </div>

              {/* Meta information items */}
              <div className="p-6 pt-0 space-y-2 border-t border-slate-900 text-left text-xs bg-slate-950/30">
                <div className="flex justify-between items-center py-2.5 border-b border-slate-900">
                  <span className="font-bold text-slate-500 uppercase tracking-wider text-[9px]">{lang === 'ur' ? 'سودا ریفرنس کوڈ:' : 'Agreement reference key'}</span>
                  <span className="font-mono font-black text-slate-200 select-all tracking-tight text-[11px]">
                    {escrow.id.toUpperCase()}
                  </span>
                </div>

                <div className="flex justify-between items-center py-2.5 border-b border-slate-900">
                  <span className="font-bold text-slate-500 uppercase tracking-wider text-[9px]">{lang === 'ur' ? 'طریقہ کار:' : 'Security mode'}</span>
                  <span className="font-semibold text-slate-300 uppercase tracking-wider text-[10px]">
                    {escrow.deliveryMode ? escrow.deliveryMode.toUpperCase() : 'STANDARD P2P ESCROW'}
                  </span>
                </div>

                <div className="flex justify-between items-center py-2.5">
                  <span className="font-bold text-slate-500 uppercase tracking-wider text-[9px]">{lang === 'ur' ? 'تاریخ و وقت:' : 'Ledger signature stamp'}</span>
                  <span className="font-semibold text-slate-300 text-[10px]">
                    {escrow.createdAt?.seconds 
                      ? new Date(escrow.createdAt.seconds * 1000).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) + ' (PKT)'
                      : (escrow.createdAt ? new Date(escrow.createdAt).toLocaleDateString() : 'N/A')}
                  </span>
                </div>
              </div>
            </div>

            {/* Verification Link sharing block */}
            <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl flex flex-col sm:flex-row items-center gap-3 justify-between">
              <div className="text-left">
                <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">{lang === 'ur' ? 'تصدیق لنک شئیر کریں' : 'SHARE VERIFIABLE PROOF'}</h4>
                <p className="text-[10px] text-slate-450 font-bold leading-normal mt-0.5">{lang === 'ur' ? 'کسی کو بھی لاک دکھانے کے لیے لنک شئیر کریں۔' : 'Anyone can scan or visit this link to verify securely.'}</p>
              </div>
              <button
                type="button"
                onClick={copyVerificationLink}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black select-none cursor-pointer border border-slate-800 active:scale-95 transition-all shrink-0"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{lang === 'ur' ? 'لنک کاپی ہو گیا!' : 'LINK COPIED!'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{lang === 'ur' ? 'لنک کاپی کریں' : 'COPY PROOF LINK'}</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}

        {/* Security Legal compliance seal disclaimer footer */}
        <div className="text-center text-[10px] text-slate-500 font-medium max-w-sm mx-auto leading-relaxed border-t border-slate-850 pt-5">
          <p>
            PK Escrow is a registered secure multi-sig escrow clearinghouse system. Under secure compliance protocols, all digital locking signatures are irreversible without dual authorization or formal sovereign mediation decisions.
          </p>
          <a
            href="/"
            className="text-emerald-500 hover:underline font-bold block mt-3 uppercase tracking-wider"
          >
            ← {lang === 'ur' ? 'مرکزی لاگ ان اسکرین' : 'Return to Authorized Terminal login'}
          </a>
        </div>

      </main>
    </div>
  );
}

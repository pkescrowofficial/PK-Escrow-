import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { collection, query, where, getDocs, orderBy, doc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Navbar } from '../components/Navbar';
import { EscrowCard, Escrow } from '../components/EscrowCard';
import { CreateEscrowModal } from '../components/CreateEscrowModal';
import { 
  PlusCircle, 
  Search, 
  LayoutGrid, 
  List, 
  ArrowRightLeft, 
  Calculator, 
  AlertCircle, 
  Info,
  ShieldCheck,
  CheckCircle2,
  Fingerprint,
  RefreshCw,
  Smile,
  Sparkles,
  Truck,
  Laptop,
  Briefcase,
  Coins,
  BookOpen,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getTranslation } from '../lib/translations';

enum OperationType {
  GET = 'get'
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, userId?: string) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: userId,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
}

export function DashboardView() {
  const { user, profile, lang } = useAuth();
  const t = getTranslation(lang);
  const [escrows, setEscrows] = useState<Escrow[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'buying' | 'selling'>('all');
  const [selectedCategory, setSelectedCategory] = useState<'digital' | 'physical' | 'freelance' | 'digital_asset'>('digital');
  
  // Interactive Calculator states
  const [isOpenCalc, setIsOpenCalc] = useState(false);
  const [calcAmount, setCalcAmount] = useState<number>(15000);
  const [calcSplit, setCalcSplit] = useState<'buyer' | 'seller' | 'split'>('split');

  // User Guide states
  const [showGuide, setShowGuide] = useState(true);
  const [guideTab, setGuideTab] = useState<'buyer' | 'seller'>('buyer');

  // Verification and Level Sandbox States
  const [isScanningFace, setIsScanningFace] = useState(false);
  const [scanStep, setScanStep] = useState<'idle' | 'initializing' | 'scanning' | 'comparing' | 'success'>('idle');
  const [scanLogs, setScanLogs] = useState<string[]>([]);

  // Derived Values
  const currentLevel = profile?.verificationLevel || (profile?.onboardingStatus === 'COMPLETED' ? 2 : 1);
  const currentLimit = 2000000;

  // Track daily transaction volume completely reactive from escrows
  const [dailyTotal, setDailyTotal] = useState(0);

  useEffect(() => {
    if (!user?.uid) return;
    
    // Start of today (Local boundaries)
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    
    let total = 0;
    escrows.forEach(e => {
      // Sum where initiatorId is current user and status is valid
      if (e.initiatorId === user.uid && e.status !== 'CANCELLED') {
        let createdTime = 0;
        if (e.createdAt?.seconds) {
          createdTime = e.createdAt.seconds * 1000;
        } else if (e.createdAt) {
          createdTime = new Date(e.createdAt).getTime();
        }
        
        if (createdTime >= startOfToday) {
          total += Number(e.amount || 0);
        }
      }
    });
    setDailyTotal(total);
  }, [escrows, user]);

  const startFaceScan = () => {
    setIsScanningFace(true);
    setScanStep('initializing');
    setScanLogs(['Initializing biometric hardware camera [RAW_PORT_FACE]...', 'Activating camera viewport grid scanning contours...']);
    
    setTimeout(() => {
      setScanStep('scanning');
      setScanLogs(prev => [...prev, 'Webstream dynamic connection: ACTIVE', 'Mapping face structure angles and bone-structure indices...', 'Checking depth & biological liveness mesh...', 'Capturing 128 high-precision tracking milestones...']);
    }, 1200);

    setTimeout(() => {
      setScanStep('comparing');
      setScanLogs(prev => [...prev, 'Face structure mapped perfectly.', 'Quering National ID and CNIC verification registries...', 'Matching biometric details with database...', 'Authenticating certificate of confirmation...']);
    }, 2800);

    setTimeout(() => {
      setScanStep('success');
      setScanLogs(prev => [...prev, 'Database match INDEX: 99.91% MATCH CONFORMS', 'Security Level upgraded: LEVEL 3 BIOMETRIC STATUS', 'Writing ledger transaction state...']);
      
      if (user?.uid) {
        updateDoc(doc(db, 'users', user.uid), {
          verificationLevel: 3,
          biometricVerified: true,
          biometricVerifiedAt: new Date().toISOString()
        }).catch(err => console.warn('Failed to update biometric status:', err));
      }
    }, 4500);
  };

  const updateLevelSandbox = async (targetLevel: number) => {
    if (!user?.uid) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        verificationLevel: targetLevel
      });
    } catch (err) {
      console.error(err);
    }
  };

  const [isFetching, setIsFetching] = useState<boolean>(false);
  const [buyingEscrows, setBuyingEscrows] = useState<Escrow[]>([]);
  const [sellingEscrows, setSellingEscrows] = useState<Escrow[]>([]);

  const fetchDashboardEscrows = async () => {
    // Standard visual trigger showing live database connection is active
    setIsFetching(true);
    setTimeout(() => {
      setIsFetching(false);
    }, 450);
  };

  useEffect(() => {
    if (!user?.uid) return;

    setIsFetching(true);
    const q1 = query(
      collection(db, 'escrows'), 
      where('buyerId', '==', user.uid)
    );
    
    const unsub1 = onSnapshot(q1, (snap1) => {
      const rawBuy = snap1.docs.map(d => ({ id: d.id, ...d.data() } as Escrow));
      setBuyingEscrows(rawBuy);
      setIsFetching(false);
    }, (err) => {
      console.error("Failed to listen buying escrows in real-time:", err);
      setIsFetching(false);
    });

    const q2 = query(
      collection(db, 'escrows'), 
      where('sellerId', '==', user.uid)
    );
    
    const unsub2 = onSnapshot(q2, (snap2) => {
      const rawSell = snap2.docs.map(d => ({ id: d.id, ...d.data() } as Escrow));
      setSellingEscrows(rawSell);
      setIsFetching(false);
    }, (err) => {
      console.error("Failed to listen selling escrows in real-time:", err);
      setIsFetching(false);
    });

    return () => {
      unsub1();
      unsub2();
    };
  }, [user?.uid]);

  useEffect(() => {
    const merged = [...buyingEscrows, ...sellingEscrows].sort((a, b) => {
      const aDate = a.createdAt?.seconds ? a.createdAt.seconds * 1000 : (a.createdAt ? new Date(a.createdAt).getTime() : 0);
      const bDate = b.createdAt?.seconds ? b.createdAt.seconds * 1000 : (b.createdAt ? new Date(b.createdAt).getTime() : 0);
      return bDate - aDate;
    });

    // De-duplicate if buyerId == sellerId
    const uniqueMerged = Array.from(new Map(merged.map(item => [item.id, item])).values());
    setEscrows(uniqueMerged);
  }, [buyingEscrows, sellingEscrows]);

  const filteredEscrows = escrows.filter(e => {

    if (filter === 'buying') return e.buyerId === user?.uid;
    if (filter === 'selling') return e.sellerId === user?.uid;
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        {/* Bento Stats Header */}
        <div className="mb-8">
          {/* Limits Progress Card */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-6 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden border border-slate-855">
            {/* Ambient pattern */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '16px 16px' }} />
            
            <div className="space-y-4 md:space-y-2 md:max-w-md w-full text-left">
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full font-black uppercase tracking-wider border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  {lang === 'ur' ? 'یومیہ حد' : 'Daily Channel Cap'}
                </span>
                <span className="text-xs text-slate-400 font-mono font-bold">
                  {profile?.phoneNumber || 'N/A'}
                </span>
              </div>

              <div className="space-y-1">
                <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">
                  {lang === 'ur' ? 'آج کی ٹرانزیکشنز' : 'TODAY\'S ESCROW VOLUME'}
                </p>
                <div className="flex items-baseline gap-1.5">
                  <h3 className="text-2xl font-black text-white leading-none">
                    Rs. {dailyTotal.toLocaleString()}
                  </h3>
                  <span className="text-xs text-slate-400 font-medium font-mono">
                    / Rs. {currentLimit.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex-1 w-full space-y-3">
              {/* Progress bar graph */}
              <div className="space-y-1">
                <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden p-[2px]">
                  <div 
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-450 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (dailyTotal / currentLimit) * 100)}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 font-semibold">
                  <span>{Math.min(100, Math.round((dailyTotal / currentLimit) * 100))}% {lang === 'ur' ? 'استعمال' : 'Limit Used'}</span>
                  <span>{lang === 'ur' ? 'باقی گنجائش:' : 'Available:'} Rs. {Math.max(0, currentLimit - dailyTotal).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Simple & Clear 3-Step Visual Escrow Flow / طریقہ کار */}
        {showGuide && (
          <div className="mb-8 bg-white border border-slate-200/95 rounded-3xl shadow-sm overflow-hidden animate-fade-in text-left">
            {/* Header Banner */}
            <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="bg-white/15 p-1.5 rounded-xl">
                  <ShieldCheck className="w-5 h-5 text-emerald-50" />
                </div>
                <div>
                  <h2 className="text-xs sm:text-sm font-black tracking-tight flex items-center gap-2">
                    {lang === 'ur' ? 'پی کے ایسکرو استعمال کرنے کا آسان طریقہ' : 'How PK Escrow Protects You'}
                    <span className="text-[8px] bg-red-500/90 text-white px-2 py-0.5 rounded-full font-black tracking-widest uppercase">
                      100% Secure
                    </span>
                  </h2>
                  <p className="text-[10px] text-emerald-100/90 font-semibold">
                    {lang === 'ur' ? 'فراڈ سے بچنے کا سب سے آسان اور محفوظ ترین عمل' : 'Fast and ultra-secure 3-step trust loop for both buyer and seller'}
                  </p>
                </div>
              </div>

              <button 
                type="button"
                onClick={() => setShowGuide(false)}
                className="text-white/80 hover:text-white hover:bg-white/10 p-1 rounded-full transition-colors cursor-pointer"
                title="Hide Guide"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Steps Container */}
            <div className="p-6">
              <div className="relative grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Visual Connector Line for Desktop */}
                <div className="hidden md:block absolute top-7 left-[15%] right-[15%] h-0.5 bg-gradient-to-r from-emerald-200 via-teal-200 to-emerald-200 -z-0 pointer-events-none" />

                {/* Step 1 */}
                <div className="relative z-10 flex flex-col items-center md:items-start text-center md:text-left bg-slate-50/70 md:bg-transparent p-4 md:p-0 rounded-2xl border border-slate-100 md:border-transparent">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 font-extrabold text-sm flex items-center justify-center shadow-sm shrink-0 mb-3 border border-emerald-200/40">
                    1
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-xs text-slate-900 flex items-center justify-center md:justify-start gap-1.5">
                      <span>{lang === 'ur' ? '١۔ ڈیل بنائیں' : '1. Create Deal'}</span>
                      <span className="text-[8px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-200/50 font-black uppercase">START</span>
                    </h4>
                    <p className="text-[11px] leading-relaxed text-slate-500 font-medium">
                      {lang === 'ur'
                        ? 'خریدار "New Deal" بناتا ہے، طے شدہ قیمت اور سیلر کا موبائل نمبر لکھ کر آفر بھیجتا ہے۔'
                        : 'Buyer inputs Seller\'s number, agreed deal amount, and details to fire the offer.'
                      }
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="relative z-10 flex flex-col items-center md:items-start text-center md:text-left bg-slate-50/70 md:bg-transparent p-4 md:p-0 rounded-2xl border border-slate-100 md:border-transparent">
                  <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 font-extrabold text-sm flex items-center justify-center shadow-sm shrink-0 mb-3 border border-amber-200/40 animate-pulse">
                    2
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-xs text-slate-900 flex items-center justify-center md:justify-start gap-1.5">
                      <span>{lang === 'ur' ? '٢۔ رقم لاک کروائیں (پیسے جمع)' : '2. Lock Funds'}</span>
                      <span className="text-[8px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-black uppercase">HOLD</span>
                    </h4>
                    <p className="text-[11px] leading-relaxed text-slate-500 font-medium">
                      {lang === 'ur'
                        ? 'خریدار رقم ایڈمن اکاؤنٹ (EasyPaisa/Bank) کر کے اسکرین شاٹ اپلوڈ کرتا ہے، ایڈمن رقم کو پی کے ایسکرو میں لاک کر دیتا ہے۔'
                        : 'Buyer sends deposit to Admin (EasyPaisa/Bank) & uploads proof. Our escrow locks funds safely.'
                      }
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative z-10 flex flex-col items-center md:items-start text-center md:text-left bg-slate-50/70 md:bg-transparent p-4 md:p-0 rounded-2xl border border-slate-100 md:border-transparent">
                  <div className="w-10 h-10 rounded-2xl bg-teal-100 text-teal-800 font-extrabold text-sm flex items-center justify-center shadow-sm shrink-0 mb-3 border border-teal-200/40">
                    3
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-xs text-slate-900 flex items-center justify-center md:justify-start gap-1.5">
                      <span>{lang === 'ur' ? '٣۔ پروڈکٹ چیک اور رقم جاری' : '3. Inspect & Release'}</span>
                      <span className="text-[8px] bg-teal-50 text-teal-700 px-1.5 py-0.5 rounded border border-teal-200/50 font-black uppercase">PAYOUT</span>
                    </h4>
                    <p className="text-[11px] leading-relaxed text-slate-500 font-medium">
                      {lang === 'ur'
                        ? 'سیلر سامان فراہم کرتا ہے۔ خریدار تسلی کر کے "Release Money" دباتا ہے اور پیسے فورا سیلر کو والٹ میں مل جاتے ہیں۔'
                        : 'Seller delivers. Buyer inspects & clicks Release. Money moves instantly to Seller\'s withdrawable wallet.'
                      }
                    </p>
                  </div>
                </div>
              </div>

              {/* Alert Ribbon */}
              <div className="mt-5 p-3.5 bg-emerald-50/30 border border-emerald-100/60 rounded-2xl text-[10px] text-slate-600 font-bold text-left flex items-start gap-2">
                <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  {lang === 'ur'
                    ? 'سیلر کے لیے اہم نوٹ: جب تک ڈیل کا اسٹیٹس "Locked" نہ ہو، سودا ڈیلیور نہ کریں! رقم پی کے ایسکرو کے پاس ۱۰۰ فیصد محفوظ ہے اور ایڈمن مڈریٹر پینل کے زیرِ نگرانی کام کرتی ہے۔'
                    : 'Critical Note to Sellers: Never dispatch any asset before active deal signals "Locked". Your funds are protected by our admin mediator board.'
                  }
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Quick Launch Categories / Services Selector */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xs sm:text-sm font-extrabold text-slate-800 uppercase tracking-widest">
                {lang === 'ur' ? 'نیا امانت سودا تجویز کریں' : 'Propose Secure P2P Escrow'}
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-400 font-medium mt-0.5">
                {lang === 'ur' ? 'محفوظ امانتی ڈیل شروع کرنے کے لئے کیٹیگری منتخب کریں' : 'Select a services channel to propose a lock & release agreement'}
              </p>
            </div>
            
            <div className="hidden sm:flex items-center gap-2">
              {!showGuide && (
                <button 
                  type="button"
                  onClick={() => setShowGuide(true)}
                  className="flex items-center gap-2 px-3.5 py-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm"
                >
                  <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'ur' ? 'طریقہ کار (رہنما)' : 'How it works'}</span>
                </button>
              )}

              {/* Collapsible Calculator Button */}
              <button 
                type="button"
                onClick={() => setIsOpenCalc(!isOpenCalc)}
                className={`flex items-center gap-2 px-3.5 py-1.5 border rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm ${isOpenCalc ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
              >
                <Calculator className="w-3.5 h-3.5 text-indigo-550" />
                <span>{t.feeCalculator}</span>
              </button>

              <button 
                type="button"
                onClick={fetchDashboardEscrows}
                disabled={isFetching}
                className="flex items-center justify-center w-8 h-8 bg-white border border-slate-200 hover:bg-slate-50 disabled:opacity-50 text-slate-600 rounded-xl transition-all active:scale-95 cursor-pointer shadow-sm flex-shrink-0"
                title="Refresh Data"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 ${isFetching ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div id="quick-categories-selector" className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Box 1: Physical Services */}
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('physical');
                setIsModalOpen(true);
              }}
              className="flex flex-col items-start p-4 bg-white hover:bg-indigo-50/10 border border-slate-250 hover:border-indigo-500 rounded-2xl sm:rounded-3xl transition-all shadow-sm hover:shadow group text-left cursor-pointer active:scale-[0.98] duration-200"
            >
              <div className="flex items-center gap-2.5 mb-2.5 w-full">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0 transition-all group-hover:bg-indigo-600 group-hover:text-white">
                  <Truck className="w-4 h-4" />
                </div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-950 group-hover:text-indigo-600 transition-colors line-clamp-1">Physical</h3>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 leading-relaxed line-clamp-2">Secured physical shipments, retail items, tangible goods, and local trades.</p>
              <span className="text-[9px] sm:text-[10px] text-indigo-600 font-extrabold tracking-wider uppercase mt-3.5 block group-hover:translate-x-1 transition-transform">Propose Trade →</span>
            </button>

            {/* Box 2: Digital Services */}
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('digital');
                setIsModalOpen(true);
              }}
              className="flex flex-col items-start p-4 bg-white hover:bg-emerald-50/10 border border-slate-250 hover:border-emerald-500 rounded-2xl sm:rounded-3xl transition-all shadow-sm hover:shadow group text-left cursor-pointer active:scale-[0.98] duration-200"
            >
              <div className="flex items-center gap-2.5 mb-2.5 w-full">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0 transition-all group-hover:bg-emerald-600 group-hover:text-white">
                  <Laptop className="w-4 h-4" />
                </div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-950 group-hover:text-emerald-600 transition-colors line-clamp-1">Digital</h3>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 leading-relaxed line-clamp-2">Software codes, virtual support, web assets, social keys, and digital items.</p>
              <span className="text-[9px] sm:text-[10px] text-emerald-600 font-extrabold tracking-wider uppercase mt-3.5 block group-hover:translate-x-1 transition-transform">Propose Trade →</span>
            </button>

            {/* Box 3: Freelancing */}
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('freelance');
                setIsModalOpen(true);
              }}
              className="flex flex-col items-start p-4 bg-white hover:bg-rose-50/10 border border-slate-250 hover:border-rose-500 rounded-2xl sm:rounded-3xl transition-all shadow-sm hover:shadow group text-left cursor-pointer active:scale-[0.98] duration-200"
            >
              <div className="flex items-center gap-2.5 mb-2.5 w-full">
                <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center flex-shrink-0 transition-all group-hover:bg-rose-600 group-hover:text-white">
                  <Briefcase className="w-4 h-4" />
                </div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-950 group-hover:text-rose-600 transition-colors line-clamp-1">Freelance</h3>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 leading-relaxed line-clamp-2">Project milestones, creative design, developer contracts, and tasks.</p>
              <span className="text-[9px] sm:text-[10px] text-rose-600 font-extrabold tracking-wider uppercase mt-3.5 block group-hover:translate-x-1 transition-transform">Propose Trade →</span>
            </button>

            {/* Box 4: Digital Assets */}
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('digital_asset');
                setIsModalOpen(true);
              }}
              className="flex flex-col items-start p-4 bg-white hover:bg-amber-50/10 border border-slate-250 hover:border-amber-500 rounded-2xl sm:rounded-3xl transition-all shadow-sm hover:shadow group text-left cursor-pointer active:scale-[0.98] duration-200"
            >
              <div className="flex items-center gap-2.5 mb-2.5 w-full">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center flex-shrink-0 transition-all group-hover:bg-amber-500 group-hover:text-white">
                  <Coins className="w-4 h-4" />
                </div>
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-955 group-hover:text-amber-600 transition-colors line-clamp-1">Assets</h3>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-500 leading-relaxed line-clamp-2">YouTube pages, gaming accounts, domains, and virtual assets.</p>
              <span className="text-[9px] sm:text-[10px] text-amber-600 font-extrabold tracking-wider uppercase mt-3.5 block group-hover:translate-x-1 transition-transform">Propose Trade →</span>
            </button>
          </div>

          {/* Mobile-only Quick Utility Buttons */}
          <div className="flex sm:hidden items-center gap-2 mt-4">
            {!showGuide && (
              <button 
                type="button"
                onClick={() => setShowGuide(true)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-2xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <BookOpen className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>{lang === 'ur' ? 'رہنما گائیڈ' : 'Trading Guide'}</span>
              </button>
            )}

            <button 
              type="button"
              onClick={() => setIsOpenCalc(!isOpenCalc)}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 border rounded-2xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-sm ${isOpenCalc ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
            >
              <Calculator className="w-4 h-4 text-indigo-500 flex-shrink-0" />
              <span>{t.feeCalculator}</span>
            </button>

            <button 
              type="button"
              onClick={fetchDashboardEscrows}
              disabled={isFetching}
              className="flex items-center justify-center w-11 h-11 bg-white border border-slate-200 hover:bg-slate-50 disabled:opacity-50 text-slate-600 rounded-2xl transition-all active:scale-95 cursor-pointer shadow-sm flex-shrink-0"
            >
              <RefreshCw className={`w-4 h-4 text-emerald-600 ${isFetching ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Filter Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 border-b border-slate-250 pb-4">
          <div>
            <h2 className="text-xs sm:text-xs font-extrabold text-slate-800 uppercase tracking-widest">
              {lang === 'ur' ? 'محفوظ معاہدے اور ٹرانزیکشنز' : 'Sovereign Protected Transactions'}
            </h2>
            <p className="text-[11px] sm:text-xs text-slate-400 font-medium mt-0.5">
              {lang === 'ur' ? 'اپنے جاری اور مکمل شدہ معاہدوں کو مانیٹر کریں' : 'Track locked values, dispatch releases, and completed secure transfers'}
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-2xl w-full sm:w-max justify-around gap-1">
            <button 
              type="button"
              onClick={() => setFilter('all')}
              className={`relative px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${filter === 'all' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:bg-slate-200/50'}`}
            >
              <span>{t.all}</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${filter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-600'}`}>
                {escrows.length}
              </span>
            </button>
            <button 
              type="button"
              onClick={() => setFilter('buying')}
              className={`relative px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${filter === 'buying' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:bg-slate-200/50'}`}
            >
              <span>{t.buying}</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${filter === 'buying' ? 'bg-indigo-600 text-white' : 'bg-slate-250 text-slate-600'}`}>
                {buyingEscrows.length}
              </span>
            </button>
            <button 
              type="button"
              onClick={() => setFilter('selling')}
              className={`relative px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${filter === 'selling' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:bg-slate-200/50'}`}
            >
              <span>{t.selling}</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${filter === 'selling' ? 'bg-emerald-600 text-white' : 'bg-slate-250 text-slate-600'}`}>
                {sellingEscrows.length}
              </span>
            </button>
          </div>
        </div>


        {/* Animated Biometric Face Verification Modal */}
        <AnimatePresence>
          {isScanningFace && (
            <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col"
              >
                {/* Header */}
                <div className="p-6 border-b border-slate-100 flex justify-between items-center text-left bg-indigo-900 text-white">
                  <div>
                    <span className="text-[8px] bg-indigo-505/30 text-indigo-200 px-2 py-0.5 rounded font-black tracking-widest uppercase block w-max border border-indigo-400/20">PK Compliance Vault</span>
                    <h3 className="text-lg font-black tracking-tight mt-1">Biometric Face Authentication</h3>
                  </div>
                  {scanStep === 'success' && (
                    <button 
                      type="button"
                      onClick={() => setIsScanningFace(false)}
                      className="text-white/80 hover:text-white text-xs font-black uppercase bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                    >
                      Close [X]
                    </button>
                  )}
                </div>

                {/* Content */}
                <div className="p-6 flex flex-col items-center justify-center space-y-6">
                  
                  {/* Visual Camera view block */}
                  <div className="relative w-48 h-48 rounded-full border-4 border-slate-100 bg-slate-950 flex items-center justify-center overflow-hidden shadow-inner">
                    
                    {/* Pulsing indicator grid */}
                    {scanStep !== 'success' && (
                      <div className="absolute inset-2 border-2 border-dashed border-indigo-500/30 rounded-full animate-spin" style={{ animationDuration: '10s' }} />
                    )}
                    
                    {/* Red Scanning Laser Line */}
                    {scanStep === 'scanning' && (
                      <motion.div 
                        animate={{ top: ['10%', '90%', '10%'] }}
                        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                        className="absolute left-0 right-0 h-1 bg-red-500 shadow-[0_0_10px_#ef4444] z-10"
                      />
                    )}

                    {/* Camera view placeholders */}
                    {scanStep === 'initializing' && (
                      <div className="space-y-2 text-center text-indigo-400">
                        <RefreshCw className="w-8 h-8 mx-auto animate-spin" />
                        <span className="text-[9px] uppercase tracking-wider font-bold block">Setting Camera Ports...</span>
                      </div>
                    )}

                    {scanStep === 'scanning' && (
                      <div className="relative w-full h-full flex items-center justify-center">
                        <div className="absolute inset-0 bg-indigo-900/10" />
                        <Smile className="w-16 h-16 text-indigo-450 animate-pulse stroke-[1.2]" />
                        <span className="absolute bottom-4 text-[9px] uppercase tracking-wider text-slate-400 font-extrabold">KEEP STILL NOW</span>
                      </div>
                    )}

                    {scanStep === 'comparing' && (
                      <div className="space-y-2 text-center text-amber-500">
                        <RefreshCw className="w-8 h-8 mx-auto animate-spin" />
                        <span className="text-[9px] uppercase tracking-wider font-bold block">Parsing Database...</span>
                      </div>
                    )}

                    {scanStep === 'success' && (
                      <motion.div 
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="space-y-2 text-center text-emerald-505 z-10 flex flex-col items-center justify-center"
                      >
                        <div className="w-14 h-14 bg-emerald-500 rounded-full flex items-center justify-center text-white mb-1 shadow-lg shadow-emerald-500/30 animate-bounce">
                          <CheckCircle2 className="w-8 h-8" />
                        </div>
                        <span className="text-[10px] uppercase tracking-widest font-black text-emerald-500 block">FACE REGISTERED</span>
                      </motion.div>
                    )}

                  </div>

                  {/* Scientific scanner logs terminal */}
                  <div className="w-full bg-slate-900 text-slate-300 font-mono text-[9px] p-4 rounded-xl text-left border border-slate-850 h-36 overflow-y-auto space-y-1.5 shadow-md">
                    <span className="text-slate-500 font-bold uppercase tracking-wider block border-b border-slate-800 pb-1 mb-1">// TELEMETRY LOGGER OUTPUT</span>
                    {scanLogs.map((log, idx) => (
                      <div key={idx} className="flex gap-1">
                        <span className="text-emerald-500 shrink-0">PK_SEC&gt;</span>
                        <span className="leading-relaxed whitespace-pre-wrap">{log}</span>
                      </div>
                    ))}
                  </div>

                  {scanStep !== 'success' && (
                    <p className="text-[10px] text-slate-450 font-medium italic animate-pulse">
                      Do not block your camera lens. Hold face alignment static.
                    </p>
                  )}
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Collapsible Calculator Panel */}
        {isOpenCalc && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 p-6 rounded-3xl text-white shadow-xl border border-indigo-800/40 mb-8 overflow-hidden"
          >
            <div className="flex flex-col lg:flex-row gap-8 items-center justify-between">
              
              <div className="flex-1 w-full space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <Calculator className="w-6 h-6 text-indigo-400 stroke-[2.5]" />
                  <h3 className="text-lg font-black tracking-tight">{t.feeCalculator}</h3>
                  <span className="text-[10px] bg-indigo-500/30 text-indigo-300 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">PK P2P Rates</span>
                </div>
                
                <p className="text-xs text-slate-350 font-medium leading-relaxed max-w-xl">
                  {t.feesCoveredPromo} {t.totalTaxWarn}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-4">
                  {/* Amount Input */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.calcAmount}</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-indigo-300 text-sm">Rs.</span>
                      <input 
                        type="number"
                        min="1"
                        value={calcAmount}
                        onChange={(e) => setCalcAmount(Math.max(0, parseInt(e.target.value) || 0))}
                        className="w-full bg-slate-950/60 border border-indigo-700/30 rounded-2xl pl-12 pr-4 py-3 font-black text-white focus:outline-none focus:ring-4 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>

                  {/* Fee Split Settings */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">{t.calcFeeSplit}</label>
                    <div className="grid grid-cols-3 gap-1 bg-slate-950/60 p-1 rounded-2xl border border-indigo-700/30">
                      <button
                        type="button"
                        onClick={() => setCalcSplit('buyer')}
                        className={`py-2 rounded-xl text-[9px] font-black uppercase tracking-tighter cursor-pointer ${calcSplit === 'buyer' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
                      >
                        Buyer
                      </button>
                      <button
                        type="button"
                        onClick={() => setCalcSplit('seller')}
                        className={`py-2 rounded-xl text-[9px] font-black uppercase tracking-tighter cursor-pointer ${calcSplit === 'seller' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
                      >
                        Seller
                      </button>
                      <button
                        type="button"
                        onClick={() => setCalcSplit('split')}
                        className={`py-2 rounded-xl text-[9px] font-black uppercase tracking-tighter cursor-pointer ${calcSplit === 'split' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
                      >
                        50:50
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Display Result Widget Card */}
              <div className="w-full lg:w-96 bg-indigo-950 p-6 rounded-2xl border border-indigo-800/40 relative overflow-hidden shrink-0 space-y-4">
                <div className="absolute top-0 right-0 p-3 bg-indigo-500/5 rounded-bl-3xl text-indigo-400/20">
                  <Calculator className="w-16 h-16 pointer-events-none translate-x-4 -translate-y-4" />
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between border-b border-indigo-900 pb-2 text-xs">
                    <span className="font-bold text-slate-400">{t.escrowFee}</span>
                    <span className="font-black text-slate-350 line-through">Rs. {Math.round(calcAmount * 0.015).toLocaleString()}</span>
                  </div>
                  
                  <div className="flex justify-between border-b border-indigo-900 pb-2 text-xs">
                    <span className="font-bold text-slate-400">{t.actualPlatformFee}</span>
                    <span className="font-black text-emerald-400">Rs. 0</span>
                  </div>

                  <div className="pt-2">
                    <div className="flex justify-between items-baseline">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">{t.youPay}</p>
                        <p className="text-xs font-bold text-slate-500 mt-0.5">({calcSplit === 'buyer' ? 'Amount + Fee' : calcSplit === 'split' ? 'Amount + Half Fee' : 'Amount Only' })</p>
                      </div>
                      <p className="text-2xl font-black text-indigo-300">
                        Rs. {(calcAmount + (calcSplit === 'buyer' ? Math.round(calcAmount * 0.015) : calcSplit === 'split' ? Math.round(calcAmount * 0.015 / 2) : 0)).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2">
                    <div className="flex justify-between items-baseline">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">{t.youReceive}</p>
                        <p className="text-xs font-bold text-slate-500 mt-0.5">({calcSplit === 'seller' ? 'Amount - Fee' : calcSplit === 'split' ? 'Amount - Half Fee' : 'Full Amount' })</p>
                      </div>
                      <p className="text-2xl font-black text-emerald-400">
                        Rs. {(calcAmount - (calcSplit === 'seller' ? Math.round(calcAmount * 0.015) : calcSplit === 'split' ? Math.round(calcAmount * 0.015 / 2) : 0)).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </motion.div>
        )}

        {filteredEscrows.length === 0 ? (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center shadow-sm">
            <div className="bg-slate-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">{t.noTransactions}</h3>
            <p className="text-slate-500 mt-2 max-w-sm mx-auto">
              {t.startFirst}
            </p>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="mt-6 text-emerald-600 font-bold hover:underline"
            >
              {t.proposeFirst} →
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEscrows.map(escrow => (
              <EscrowCard 
                key={escrow.id} 
                escrow={escrow}
                isBuyer={escrow.buyerId === user?.uid}
              />
            ))}
          </div>
        )}
      </main>

      <CreateEscrowModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        defaultDeliveryMode={selectedCategory}
      />
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, getDoc, onSnapshot, collection, query, where, orderBy, addDoc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { sendNotification } from '../lib/notifications';
import { compressImage } from '../lib/watermark';
import { 
  ArrowLeft, 
  Send, 
  Paperclip, 
  MessageSquare, 
  ShieldCheck, 
  DollarSign
} from 'lucide-react';
import { motion } from 'motion/react';
import { Escrow } from '../components/EscrowCard';

interface Message {
  id: string;
  senderId: string;
  senderPhone?: string;
  text: string;
  proofUrl?: string;
  createdAt: any;
}

export function ChatView() {
  const { user, setView, activeChatEscrowId } = useAuth();
  const [escrow, setEscrow] = useState<Escrow | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessageText, setNewMessageText] = useState('');
  const [isUploadingProof, setIsUploadingProof] = useState(false);
  const [counterparty, setCounterparty] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // If there is no active chat escrow context, safety fallback back to dashboard
  useEffect(() => {
    if (!activeChatEscrowId) {
      setView('dashboard');
    }
  }, [activeChatEscrowId, setView]);

  // Load Active Escrow Details
  useEffect(() => {
    if (!activeChatEscrowId) return;

    const escrowRef = doc(db, 'escrows', activeChatEscrowId);
    const unsub = onSnapshot(escrowRef, (snap) => {
      if (snap.exists()) {
        setEscrow({ id: snap.id, ...snap.data() } as Escrow);
      } else {
        console.warn("Escrow not found:", activeChatEscrowId);
        setView('dashboard');
      }
      setLoading(false);
    }, (err) => {
      console.error("Firestore error loading escrow:", err);
      setLoading(false);
      handleFirestoreError(err, OperationType.GET, `escrows/${activeChatEscrowId}`);
    });

    return () => unsub();
  }, [activeChatEscrowId, setView]);

  const isBuyer = escrow ? escrow.buyerId === user?.uid : false;

  // Load Counterparty profile info
  useEffect(() => {
    if (!escrow) return;

    const fetchCounterparty = async () => {
      const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
      if (!targetId) return;
      
      try {
        const docRef = doc(db, 'users', targetId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setCounterparty(docSnap.data());
        }
      } catch (err) {
        console.error("Error fetching counterparty:", err);
      }
    };
    fetchCounterparty();
  }, [escrow, isBuyer]);

  // Load Messages real-time stream
  useEffect(() => {
    if (!activeChatEscrowId) return;

    const messagesQuery = query(
      collection(db, 'chat_messages'),
      where('escrowId', '==', activeChatEscrowId),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        msgs.push({
          id: doc.id,
          senderId: data.senderId,
          senderPhone: data.senderPhone,
          text: data.text,
          proofUrl: data.proofUrl,
          createdAt: data.createdAt
        });
      });
      setMessages(msgs);
    }, (err) => {
      console.warn("Firestore error fetching chat messages:", err);
      handleFirestoreError(err, OperationType.LIST, `chat_messages/${activeChatEscrowId}`);
    });

    return () => unsubscribe();
  }, [activeChatEscrowId]);

  // Handle setting/updating chat last seen to clear red dot
  useEffect(() => {
    if (!activeChatEscrowId || messages.length === 0) return;
    const latestTime = messages[messages.length - 1].createdAt;
    const timeMs = latestTime ? new Date(latestTime).getTime() : Date.now();
    localStorage.setItem(`chat_last_seen_${activeChatEscrowId}`, String(timeMs));
  }, [activeChatEscrowId, messages]);

  const handleSendMessage = async (text: string, proofUrl: string = '') => {
    if (!user || !activeChatEscrowId || (!text.trim() && !proofUrl)) return;
    try {
      await addDoc(collection(db, 'chat_messages'), {
        escrowId: activeChatEscrowId,
        senderId: user.uid,
        senderPhone: user.phoneNumber || 'User',
        text: text.trim(),
        proofUrl: proofUrl,
        createdAt: new Date().toISOString()
      });
      setNewMessageText('');

      // Send alert to counterparty
      if (escrow) {
        const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
        if (targetId) {
          const displaySender = isBuyer ? 'Buyer' : 'Seller';
          const formattedMsg = text.trim() ? (text.trim().length > 40 ? text.trim().slice(0, 40) + '...' : text.trim()) : 'Sent an attachment';
          await sendNotification(
            targetId,
            'New Chat Message 💬',
            `"${displaySender}" regarding "${escrow.itemDescription}": ${formattedMsg}`,
            'INFO',
            escrow.id
          ).catch(e => console.warn('Failed to send chat notification:', e));
        }
      }
    } catch (err) {
      console.error("Error sending message:", err);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    
    setIsUploadingProof(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const rawBase64 = reader.result as string;
      try {
        const compressed = await compressImage(rawBase64, 1000, 0.72);
        handleSendMessage(`📎 Uploaded Media Proof: ${file.name}`, compressed);
      } catch (err) {
        console.error("Error compressing file:", err);
        handleSendMessage(`📎 Uploaded Media Proof: ${file.name}`, rawBase64); // fallback
      } finally {
        setIsUploadingProof(false);
      }
    };
    reader.onerror = () => {
      console.error("Failed to read file");
      setIsUploadingProof(false);
    };
    reader.readAsDataURL(file);
  };

  if (loading || !escrow) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center flex-col gap-4">
        <div className="bg-slate-900 p-3 rounded-2xl animate-bounce shadow-xl">
          <MessageSquare className="text-white w-10 h-10" />
        </div>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Loading secure chatroom...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Dynamic Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 px-4 py-4 md:py-5 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setView('dashboard')}
              id="back_to_dashboard_btn"
              className="p-2.5 bg-slate-50 hover:bg-slate-150 text-slate-700 hover:text-slate-950 rounded-full border border-slate-200/80 transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center shrink-0"
              title="Back to Dashboard"
            >
              <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
            </button>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${
                isBuyer 
                  ? 'bg-emerald-100 text-emerald-700 border border-emerald-200/50' 
                  : 'bg-indigo-100 text-indigo-700 border border-indigo-200/50'
              }`}>
                {isBuyer ? 'Buyer (You)' : 'Seller (You)'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-50 border border-slate-200/60 rounded-2xl px-4 py-2">
            <div className="hidden sm:flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-500" />
              <span className="text-xs font-black text-slate-800 font-mono">PKR {escrow.amount.toLocaleString()}</span>
            </div>
            <div className="h-4 w-px bg-slate-200 hidden sm:block"></div>
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className={`w-2 h-2 rounded-full ${
                escrow.status === 'COMPLETED' ? 'bg-emerald-500' :
                escrow.status === 'DISPUTED' ? 'bg-rose-500' :
                escrow.status === 'FUNDED' ? 'bg-blue-500' : 'bg-amber-500'
              } animate-pulse`} />
              <span className="font-extrabold uppercase text-[10px] tracking-wider">{escrow.status}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main chat workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col">
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden flex flex-col flex-1 shadow-sm relative min-h-[500px]">
          {/* Header metadata layout banner */}
          <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between flex-wrap gap-2 text-xs font-semibold">
            <div className="flex items-center gap-2 flex-wrap">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span className="font-extrabold uppercase tracking-wide text-[11px] text-white">Secure Live Chatroom</span>
              <span className="text-slate-600 hidden sm:inline">•</span>
              <span className="text-slate-400 font-semibold text-[11px]">
                Linked Deal: <span className="text-emerald-400 font-extrabold">{escrow.itemDescription}</span>
              </span>
            </div>
            {counterparty && (
              <span className="text-[10px] text-slate-400 font-mono bg-slate-800/80 px-2.5 py-0.5 rounded-full">
                Counterparty: {counterparty.phoneNumber}
              </span>
            )}
          </div>

          {/* Real-time Message log container scroll views */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/20">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 p-8 space-y-2 italic max-w-md mx-auto">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-xs text-slate-300">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 not-italic mt-2">Start the conversation</h3>
                <p className="text-[10px] text-slate-400 leading-normal">
                  Your chat logs are highly secure. Align delivery timelines, product verification, or document proof uploads safely!
                </p>
              </div>
            ) : (
              messages.map((m) => {
                const isMe = m.senderId === user?.uid;
                return (
                  <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fade-in`}>
                    <div className={`max-w-[75%] rounded-2xl p-4 shadow-sm space-y-1.5 break-words ${
                      isMe 
                        ? 'bg-slate-950 text-white rounded-tr-none shadow-black/5' 
                        : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
                    }`}>
                      <div className="flex items-center gap-3 justify-between">
                        <span className={`text-[9px] font-black uppercase tracking-wider ${isMe ? 'text-slate-400' : 'text-slate-500'}`}>
                          {isMe ? 'You' : (m.senderPhone ? m.senderPhone : 'Counterparty')}
                        </span>
                        {m.createdAt && (
                          <span className="text-[8px] opacity-65 font-mono">
                            {(() => {
                              const d = new Date(m.createdAt);
                              return isNaN(d.getTime()) ? '' : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                            })()}
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-semibold leading-relaxed whitespace-pre-wrap">{m.text}</p>
                      
                      {m.proofUrl && (
                        <div className="mt-3 border-t border-slate-100/20 pt-2 space-y-1.5">
                          <p className="text-[8.5px] font-extrabold uppercase tracking-tight text-emerald-500">📎 Attached Reference Artifact:</p>
                          <img 
                            src={m.proofUrl} 
                            alt="Uploaded Receipt Proof" 
                            referrerPolicy="no-referrer"
                            className="max-h-[180px] rounded-xl border border-slate-200/20 object-cover max-w-full cursor-pointer hover:opacity-95 transition-opacity"
                            onClick={() => {
                              const win = window.open();
                              if (win) win.document.write(`<img src="${m.proofUrl}" style="max-width:100%; max-height:100vh; display:block; margin:auto;"/>`);
                            }}
                          />
                          <a 
                            href={m.proofUrl} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-[9px] hover:underline block font-bold text-sky-400"
                          >
                            Open raw image resource in new tab ↗
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Text Message Entry Box */}
          <div className="bg-white border-t border-slate-200 p-4 shrink-0 flex items-center gap-3">
            <label className="cursor-pointer p-3 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors flex items-center justify-center shrink-0 text-slate-500 hover:text-slate-800" title="Attach media graphic/snapshot">
              <Paperclip className="w-5 h-5 text-slate-400 hover:text-slate-600" />
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleFileUpload}
                className="hidden" 
                disabled={isUploadingProof}
              />
            </label>

            <input 
              type="text"
              value={newMessageText}
              onChange={(e) => setNewMessageText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSendMessage(newMessageText);
                }
              }}
              disabled={isUploadingProof}
              placeholder={isUploadingProof ? "Converting attachment to secure container..." : "Type custom secure chat message..."}
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500/10 placeholder:text-slate-400"
            />

            <button
              type="button"
              onClick={() => handleSendMessage(newMessageText)}
              disabled={isUploadingProof || !newMessageText.trim()}
              className="p-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition-colors flex items-center justify-center shrink-0 disabled:opacity-40 cursor-pointer shadow-md shadow-slate-950/15 active:scale-95 text-xs font-bold gap-1.5"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ShieldCheck, ArrowRight, Lock, Clock, CheckCircle, Phone, KeyRound, Heart, MapPin, Key, UserPlus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, getDocs, limit, doc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { normalizePhoneNumber, getPhoneVariations } from '../lib/utils';

export function LoginView() {
  const { loginWithPhone, verifyOtp, loginWithExistingUser } = useAuth();
  const [step, setStep] = useState<'phone' | 'otp' | 'login_mpin' | 'reset_mpin' | 'set_new_mpin'>('phone');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [existingUser, setExistingUser] = useState<any | null>(null);
  const [loginMpin, setLoginMpin] = useState('');
  const [mpinError, setMpinError] = useState<string | null>(null);
  const mpinInputRef = useRef<HTMLInputElement>(null);


  // Security Questions State
  const [motherNameSec, setMotherNameSec] = useState('');
  const [birthPlaceSec, setBirthPlaceSec] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [accountNotFoundError, setAccountNotFoundError] = useState<string | null>(null);

  // New MPIN setting State
  const [newMpin, setNewMpin] = useState('');
  const newMpinInputRef = useRef<HTMLInputElement>(null);

  // One-time users count using getDocs to save query quota
  const [totalUsers, setTotalUsers] = useState<number>(0);

  useEffect(() => {
    const fetchUsersCount = async () => {
      try {
        const usersRef = collection(db, 'users');
        const snapshot = await getDocs(usersRef);
        setTotalUsers(snapshot.size);
        
        // Log user profiles in database securely to browser console for developer diagnostic of user accounts
        const databaseUsers = snapshot.docs.map(docSnap => ({
          uid: docSnap.id,
          phone: docSnap.data().phoneNumber || 'Unknown',
          onboardingStatus: docSnap.data().onboardingStatus || 'PENDING',
          isDeleted: docSnap.data().isDeleted || false,
          fullName: docSnap.data().displayName || docSnap.data().fullName || 'N/A'
        }));
        console.log("=== TOTAL USERS IN DATABASE DIAGNOSTIC ===");
        console.table(databaseUsers);
        console.log("==========================================");
      } catch (err) {
        console.warn("Failed to fetch users count in LoginView, setting default to 0:", err);
        // Do not crash the app for a decorative count display
        setTotalUsers(0);
      }
    };
    fetchUsersCount();
  }, []);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) return;
    setLoading(true);
    setMpinError(null);
    setPhoneError(null);
    setAccountNotFoundError(null);
    try {
      const variations = getPhoneVariations(phoneNumber);
      // Query user documents to find if there is an existing account with this number in any format
      const q = query(
        collection(db, 'users'),
        where('phoneNumber', 'in', variations)
      );
      const querySnapshot = await getDocs(q);
      
      // Look for an active (non-deleted) account associated with this phone number
      const activeUserDoc = querySnapshot.docs.find(docSnap => {
        const data = docSnap.data();
        return !data.isDeleted && data.onboardingStatus !== 'DELETED';
      });
      
      if (activeUserDoc) {
        // Active user document found
        const userData = activeUserDoc.data();
        
        // If they have an MPIN set up, show MPIN input field directly to log in
        if (userData.mpin) {
          setExistingUser({ uid: activeUserDoc.id, ...userData });
          await loginWithPhone(phoneNumber); // Sets tempPhone in context
          setStep('login_mpin');
          setLoading(false);
          return;
        } else {
          // If they have not completed onboarding, they still need to do OTP verification to proceed
          setExistingUser({ uid: activeUserDoc.id, ...userData });
          await loginWithPhone(phoneNumber);
          setStep('otp');
          setLoading(false);
          return;
        }
      }
      
      // No active user matches: this is NOT a login-capable account.
      // Since they are logging in, we show the requested error message.
      setExistingUser(null);
      setAccountNotFoundError("Account Not Found Please Create an Account");
    } catch (err) {
      console.error("Login verification failed:", err);
      handleFirestoreError(err, OperationType.GET, 'users/query');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterPhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) return;
    setLoading(true);
    setMpinError(null);
    setPhoneError(null);
    setAccountNotFoundError(null);
    try {
      const variations = getPhoneVariations(phoneNumber);
      const q = query(
        collection(db, 'users'),
        where('phoneNumber', 'in', variations)
      );
      const querySnapshot = await getDocs(q);
      
      const activeUserDoc = querySnapshot.docs.find(docSnap => {
        const data = docSnap.data();
        return !data.isDeleted && data.onboardingStatus !== 'DELETED';
      });

      if (activeUserDoc) {
        // Already registered active account found
        setPhoneError("An account already exists with this phone number. Please login. اس نمبر پر پہلے ہی اکاؤنٹ موجود ہے۔ برائے مہربانی لاگ ان کریں۔");
        setLoading(false);
        return;
      }

      // Safe to proceed with registering a new account: send OTP
      setExistingUser(null);
      await loginWithPhone(phoneNumber);
      setStep('otp');
    } catch (err) {
      console.error("Registration phone check failed:", err);
      handleFirestoreError(err, OperationType.GET, 'users/query');
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;
    setLoading(true);
    try {
      // If we have an existingUser from our lookup, we pass their existing uid to verifyOtp
      // so we use the same user profile document!
      await verifyOtp(otp, existingUser?.uid);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  const handleMpinChange = (val: string) => {
    if (val.length <= 4 && /^\d*$/.test(val)) {
      setLoginMpin(val);
      if (val.length === 4) {
        // Auto-submit when 4 digits are completed
        setLoading(true);
        setMpinError(null);
        setTimeout(async () => {
          try {
            if (existingUser?.mpin === val) {
              if (existingUser.onboardingStatus !== 'COMPLETED') {
                await updateDoc(doc(db, 'users', existingUser.uid), {
                  onboardingStatus: 'COMPLETED'
                });
              }
              await loginWithExistingUser(existingUser.uid, phoneNumber);
            } else {
              setMpinError("Incorrect MPIN! Please enter your correct 4-digit security PIN.");
              setLoginMpin('');
              setLoading(false);
            }
          } catch (error) {
            console.error("Mpin verification error:", error);
            setMpinError("System error. Please try again.");
            setLoading(false);
          }
        }, 500);
      }
    }
  };

  const handleMpinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loginMpin.length !== 4 || !existingUser) return;
    setLoading(true);
    setMpinError(null);
    try {
      if (existingUser.mpin === loginMpin) {
        if (existingUser.onboardingStatus !== 'COMPLETED') {
          await updateDoc(doc(db, 'users', existingUser.uid), {
            onboardingStatus: 'COMPLETED'
          });
        }
        await loginWithExistingUser(existingUser.uid, phoneNumber);
      } else {
        setMpinError("Incorrect MPIN! Please enter your correct 4-digit security PIN.");
        setLoginMpin('');
      }
    } catch (error) {
      console.error("Mpin verification error:", error);
      setMpinError("System error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSecurityVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    if (!existingUser) {
      setResetError("User data cannot be loaded. Please reload the page.");
      return;
    }

    const savedMother = (existingUser.motherName || '').trim().toLowerCase();
    const savedBirth = (existingUser.placeOfBirth || '').trim().toLowerCase();

    const inputMother = motherNameSec.trim().toLowerCase();
    const inputBirth = birthPlaceSec.trim().toLowerCase();

    if (savedMother && savedBirth && savedMother === inputMother && savedBirth === inputBirth) {
      setStep('set_new_mpin');
      setNewMpin('');
    } else {
      setResetError("Security answers are incorrect! Please double-check and enter the correct responses.");
    }
  };

  const handleNewMpinChange = (val: string) => {
    if (val.length <= 4 && /^\d*$/.test(val)) {
      setNewMpin(val);
      if (val.length === 4) {
        setLoading(true);
        setResetError(null);
        setTimeout(async () => {
          try {
            if (!existingUser) return;
            const userRef = doc(db, 'users', existingUser.uid);
            await updateDoc(userRef, {
              mpin: val
            });
            setExistingUser(prev => prev ? { ...prev, mpin: val } : null);
            await loginWithExistingUser(existingUser.uid, phoneNumber);
          } catch (err: any) {
            console.error("Failed to update MPIN:", err);
            setResetError("Failed to update MPIN. Please try again.");
            setLoading(false);
            handleFirestoreError(err, OperationType.UPDATE, `users/${existingUser?.uid}`);
          }
        }, 500);
      }
    }
  };

  const handleNewMpinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newMpin.length !== 4 || !existingUser) return;
    setLoading(true);
    setResetError(null);
    try {
      const userRef = doc(db, 'users', existingUser.uid);
      await updateDoc(userRef, {
        mpin: newMpin
      });
      setExistingUser(prev => prev ? { ...prev, mpin: newMpin } : null);
      await loginWithExistingUser(existingUser.uid, phoneNumber);
    } catch (err) {
      console.error("Failed to update MPIN:", err);
      setResetError("Failed to update MPIN. Please try again.");
      handleFirestoreError(err, OperationType.UPDATE, `users/${existingUser.uid}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row">
      {/* Left Pane - Branding */}
      <div className="w-full md:w-1/2 bg-emerald-600 p-8 md:p-16 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-96 h-96 bg-emerald-400 rounded-full blur-3xl opacity-30" />
        
        <div className="relative z-10 flex items-center gap-3">
          <div className="bg-white p-2.5 rounded-2xl shadow-xl shadow-emerald-900/20">
            <ShieldCheck className="text-emerald-600 w-8 h-8" />
          </div>
          <div>
            <span className="text-2xl font-black text-white tracking-tighter leading-none block">PK Escrow</span>
            <span className="text-emerald-300 text-[10px] font-black uppercase tracking-[0.3em]">Pakistan</span>
          </div>
        </div>

        <div className="relative z-10">
          <h1 className="text-5xl md:text-7xl font-black text-white leading-tight tracking-tighter">
            Digital Trust <br />
            <span className="text-emerald-200">Simplified.</span>
          </h1>
          <p className="text-emerald-100 mt-6 text-xl max-w-md font-medium">
            The most secure way to exchange money for services in Pakistan.
          </p>
        </div>

        <div className="relative z-10 flex gap-8">
            <div className="text-white">
                <p id="active-users-count" className="text-3xl font-black">{totalUsers.toLocaleString()}</p>
                <p className="text-emerald-200 text-xs font-bold uppercase tracking-widest">Active Users</p>
            </div>
            <div className="text-white">
                <p className="text-3xl font-black">0%</p>
                <p className="text-emerald-200 text-xs font-bold uppercase tracking-widest">Scam Rate</p>
            </div>
        </div>
      </div>

      {/* Right Pane - Auth */}
      <div className="w-full md:w-1/2 p-8 md:p-16 flex items-center justify-center">
        <div className="w-full max-w-sm">
          <AnimatePresence mode="wait">
            {step === 'phone' ? (
              <motion.div 
                key="phone-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                {mode === 'login' ? (
                  <>
                    <div className="mb-8">
                      <h2 className="text-3xl font-black text-slate-900 tracking-tight">Mobile Login</h2>
                      <p className="text-sm text-slate-500 mt-2 font-bold font-[Georgia] text-left">Enter your phone number to login your Account</p>
                    </div>

                    <form onSubmit={handlePhoneSubmit} className="space-y-6">
                      {phoneError && (
                        <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl flex gap-3 text-rose-650 text-xs font-bold leading-relaxed animate-shake">
                          <Lock className="w-5 h-5 shrink-0 text-rose-500 mt-0.5" />
                          <span>{phoneError}</span>
                        </div>
                      )}
                      <div>
                        <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Phone Number</label>
                        <div className="relative">
                          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                          <input 
                            type="tel"
                            required
                            placeholder="+92 3XX XXXXXXX"
                            value={phoneNumber}
                            onChange={(e) => {
                              setPhoneNumber(e.target.value);
                              setAccountNotFoundError(null);
                            }}
                            className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-lg font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                          />
                        </div>
                      </div>

                      {accountNotFoundError && (
                        <div className="text-rose-600 text-xs font-bold text-left animate-shake px-1">
                          ⚠️ {accountNotFoundError}
                        </div>
                      )}

                      <button 
                        type="submit"
                        disabled={loading || phoneNumber.length < 10}
                        className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-slate-900/10 group"
                      >
                        {loading ? 'Checking...' : 'Next'}
                        <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </button>

                      <div className="flex items-center my-4 py-1">
                        <div className="flex-1 border-t border-slate-100"></div>
                        <span className="px-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">or / یا</span>
                        <div className="flex-1 border-t border-slate-100"></div>
                      </div>

                      <button 
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          setMode('register');
                          setPhoneError(null);
                          setAccountNotFoundError(null);
                        }}
                        className="w-full bg-emerald-50 hover:bg-emerald-100 disabled:opacity-50 text-emerald-700 font-extrabold py-3.5 rounded-3xl flex items-center justify-center gap-2 border border-emerald-200 transition-all cursor-pointer text-xs active:scale-[0.98] shadow-sm group"
                      >
                        <UserPlus className="w-4 h-4 text-emerald-600 transition-transform group-hover:scale-110" />
                        <span>Create a New Account / نیا اکاؤنٹ بنائیں</span>
                      </button>
                    </form>
                  </>
                ) : (
                  <>
                    <div className="mb-8">
                      <h2 className="text-3xl font-black text-slate-900 tracking-tight">Create Account</h2>
                      <p className="text-sm text-slate-500 mt-2 font-bold font-[Georgia] text-left">Enter your phone number to start registration</p>
                    </div>

                    <form onSubmit={handleRegisterPhoneSubmit} className="space-y-6">
                      {phoneError && (
                        <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl flex gap-3 text-rose-650 text-xs font-bold leading-relaxed animate-shake">
                          <Lock className="w-5 h-5 shrink-0 text-rose-500 mt-0.5" />
                          <span>{phoneError}</span>
                        </div>
                      )}
                      <div>
                        <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Phone Number</label>
                        <div className="relative">
                          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                          <input 
                            type="tel"
                            required
                            placeholder="+92 3XX XXXXXXX"
                            value={phoneNumber}
                            onChange={(e) => {
                              setPhoneNumber(e.target.value);
                              setPhoneError(null);
                            }}
                            className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-lg font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                          />
                        </div>
                      </div>

                      <button 
                        type="submit"
                        disabled={loading || phoneNumber.length < 10}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-500/10 group"
                      >
                        {loading ? 'Processing...' : 'Next'}
                        <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </button>

                      <div className="pt-2 text-center">
                        <button 
                          type="button"
                          onClick={() => {
                            setMode('login');
                            setPhoneError(null);
                            setAccountNotFoundError(null);
                          }}
                          className="text-xs font-extrabold text-slate-500 hover:text-slate-800 transition-colors uppercase tracking-widest cursor-pointer"
                        >
                          ← Back to Login / واپس لاگ ان
                        </button>
                      </div>
                    </form>
                  </>
                )}
              </motion.div>
            ) : step === 'otp' ? (
              <motion.div 
                key="otp-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="mb-8">
                  <button 
                    onClick={() => {
                      setStep('phone');
                      setOtp('');
                    }}
                    className="text-emerald-600 font-bold text-sm mb-4 flex items-center gap-1 hover:underline"
                  >
                   ← Change Number
                  </button>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">Verify Code</h2>
                  <p className="text-slate-500 mt-2">We sent a 6-word (digit) code to {phoneNumber}</p>
                </div>

                <form onSubmit={handleOtpSubmit} className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">6-Digit Code</label>
                    <div className="relative">
                      <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                      <input 
                        type="text"
                        required
                        maxLength={6}
                        placeholder="XXXXXX"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-2xl font-black tracking-[0.5em] text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all placeholder:tracking-normal placeholder:font-normal placeholder:text-slate-200"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || otp.length !== 6}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-500/10 group"
                  >
                    {loading ? 'Verifying...' : 'Verify & Continue'}
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </form>
              </motion.div>
            ) : step === 'login_mpin' ? (
              <motion.div 
                key="mpin-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="mb-6 text-left">
                  <button 
                    onClick={() => {
                      setStep('phone');
                      setLoginMpin('');
                      setMpinError(null);
                    }}
                    className="text-emerald-600 font-bold text-sm mb-4 flex items-center gap-1 hover:underline"
                  >
                   ← Change Number
                  </button>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">Enter MPIN</h2>
                  <p className="text-slate-500 mt-2 font-medium">Welcome back! Account found for {phoneNumber}.</p>
                  <p className="text-slate-400 text-xs mt-1">Please enter your 4-digit security code to log in.</p>
                </div>

                <form onSubmit={handleMpinSubmit} className="space-y-6">
                  {mpinError && (
                    <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-xs font-bold text-center">
                      {mpinError}
                    </div>
                  )}

                  <div onClick={() => mpinInputRef.current?.focus()} className="cursor-pointer py-2">
                    <div className="flex justify-center gap-3 mb-3">
                      {[0, 1, 2, 3].map((i) => (
                        <div 
                          key={i}
                          className={`w-14 h-16 rounded-2xl border-2 flex items-center justify-center text-3xl font-black transition-all ${
                            loginMpin.length > i ? 'border-emerald-500 bg-emerald-50 text-emerald-600 shadow-lg shadow-emerald-500/10' : 'border-slate-200 bg-slate-50 text-slate-300'
                          } ${loginMpin.length === i ? 'ring-4 ring-emerald-500/10 border-emerald-300' : ''}`}
                        >
                          {loginMpin.length > i ? '•' : ''}
                        </div>
                      ))}
                    </div>
                    
                    <input 
                      ref={mpinInputRef}
                      type="tel"
                      inputMode="numeric"
                      autoFocus
                      maxLength={4}
                      value={loginMpin}
                      onChange={(e) => handleMpinChange(e.target.value)}
                      className="sr-only"
                    />

                    <div className="text-right px-1">
                      <button 
                        type="button"
                        onClick={() => {
                          setStep('reset_mpin');
                          setMotherNameSec('');
                          setBirthPlaceSec('');
                          setResetError(null);
                        }}
                        className="text-xs font-bold text-emerald-600 hover:text-emerald-700 active:text-emerald-800 transition-colors cursor-pointer hover:underline"
                      >
                        Forgot MPIN?
                      </button>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || loginMpin.length !== 4}
                    className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-colors shadow-xl"
                  >
                    {loading ? 'Logging in...' : 'Login & Continue'}
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </form>
              </motion.div>
            ) : step === 'reset_mpin' ? (
              <motion.div 
                key="reset-mpin-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="mb-6 text-left">
                  <button 
                    onClick={() => {
                      setStep('login_mpin');
                      setResetError(null);
                    }}
                    className="text-emerald-600 font-bold text-sm mb-4 flex items-center gap-1 hover:underline"
                  >
                   ← Back to Login
                  </button>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">Forget MPIN</h2>
                  <p className="text-slate-500 mt-2 font-medium">Verify identity with security questions.</p>
                </div>

                <form onSubmit={handleSecurityVerify} className="space-y-6">
                  {resetError && (
                    <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-xs font-bold text-center">
                      {resetError}
                    </div>
                  )}

                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Mother Name</label>
                      <div className="relative">
                        <Heart className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                        <input 
                          type="text" 
                          required
                          value={motherNameSec} 
                          onChange={(e) => setMotherNameSec(e.target.value)}
                          placeholder="Enter your mother's maiden name"
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Place of Birth</label>
                      <div className="relative">
                        <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                        <input 
                          type="text" 
                          required
                          value={birthPlaceSec} 
                          onChange={(e) => setBirthPlaceSec(e.target.value)}
                          placeholder="Enter your place of birth (City / Village)"
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || !motherNameSec || !birthPlaceSec}
                    className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-colors shadow-xl"
                  >
                    Verify & Continue
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </form>
              </motion.div>
            ) : (
              <motion.div 
                key="set-new-mpin-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="mb-6 text-left">
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">Set New MPIN</h2>
                  <p className="text-slate-500 mt-2 font-medium">Verification successful! Enter your new 4-digit security code.</p>
                </div>

                <form onSubmit={handleNewMpinSubmit} className="space-y-6">
                  {resetError && (
                    <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-xs font-bold text-center">
                      {resetError}
                    </div>
                  )}

                  <div onClick={() => newMpinInputRef.current?.focus()} className="cursor-pointer py-2">
                    <div className="flex justify-center gap-3">
                      {[0, 1, 2, 3].map((i) => (
                        <div 
                          key={i}
                          className={`w-14 h-16 rounded-2xl border-2 flex items-center justify-center text-3xl font-black transition-all ${
                            newMpin.length > i ? 'border-emerald-500 bg-emerald-50 text-emerald-600 shadow-lg shadow-emerald-500/10' : 'border-slate-200 bg-slate-50 text-slate-300'
                          } ${newMpin.length === i ? 'ring-4 ring-emerald-500/10 border-emerald-300' : ''}`}
                        >
                          {newMpin.length > i ? '•' : ''}
                        </div>
                      ))}
                    </div>
                    
                    <input 
                      ref={newMpinInputRef}
                      type="tel"
                      inputMode="numeric"
                      autoFocus
                      maxLength={4}
                      value={newMpin}
                      onChange={(e) => handleNewMpinChange(e.target.value)}
                      className="sr-only"
                    />
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || newMpin.length !== 4}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-colors shadow-xl"
                  >
                    {loading ? 'Updating & Logging In...' : 'Update & Log In'}
                    <Key className="w-5 h-5 animate-pulse" />
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <p className="text-center text-xs text-slate-400 mt-12 leading-relaxed">
            By continuing, you agree to our Terms of Service and <br />
            acknowledge our Escrow Protection Policy.
          </p>
        </div>
      </div>
    </div>
  );
}

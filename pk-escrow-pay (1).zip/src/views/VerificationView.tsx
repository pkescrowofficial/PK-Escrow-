import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Heart, MapPin, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export function VerificationView() {
  const { user } = useAuth();
  const [motherName, setMotherName] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        motherName: motherName,
        placeOfBirth: birthPlace,
        onboardingStatus: 'VERIFIED',
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden"
      >
        <div className="bg-emerald-600 p-8 text-white text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-2 mb-6">
            <Heart className="w-6 h-6 text-emerald-200" />
            <span className="font-black tracking-tighter text-sm uppercase">PK Escrow</span>
          </div>
          <h2 className="text-3xl font-black tracking-tight">Account Verification</h2>
          <p className="text-emerald-100 mt-2 font-medium">Step 2 of 3: Security Questions</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Mother Name</label>
              <div className="relative">
                <Heart className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="text" required
                  value={motherName} onChange={(e) => setMotherName(e.target.value)}
                  placeholder="Full name"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Place of Birth</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="text" required
                  value={birthPlace} onChange={(e) => setBirthPlace(e.target.value)}
                  placeholder="City / Village"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-slate-900/10 group mt-4"
          >
            {loading ? 'Verifying...' : 'Next Step'}
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>
      </motion.div>
    </div>
  );
}

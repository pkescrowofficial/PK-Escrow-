import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ShieldEllipsis, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export function MpinView() {
  const { user } = useAuth();
  const [mpin, setMpin] = useState('');
  const [confirmMpin, setConfirmMpin] = useState('');
  const [step, setStep] = useState<'create' | 'confirm'>('create');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    if (step === 'create') {
      if (mpin.length === 4) {
        setStep('confirm');
        return;
      }
    }

    if (step === 'confirm') {
      if (confirmMpin.length !== 4) return;
      if (mpin !== confirmMpin) {
        setError('PINs do not match. Please try again.');
        setConfirmMpin('');
        setStep('create');
        setMpin('');
        return;
      }

      setLoading(true);
      setError(null);
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          mpin: mpin, // In real app, hash this
          onboardingStatus: 'COMPLETED',
        });
      } catch (err: any) {
        console.error(err);
        setError(err.message || 'Verification failed. Please try again.');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleMpinChange = (val: string) => {
    if (val.length <= 4 && /^\d*$/.test(val)) {
      if (step === 'create') {
        setMpin(val);
        if (val.length === 4) {
          // Add a tiny delay for visual feedback before auto-advancing
          setTimeout(() => setStep('confirm'), 300);
        }
      } else {
        setConfirmMpin(val);
      }
    }
  };

  const goBack = () => {
    setStep('create');
    setConfirmMpin('');
    setMpin('');
    setError(null);
  };

  const focusInput = () => {
    inputRef.current?.focus();
  };

  const currentVal = step === 'create' ? mpin : confirmMpin;

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-xl w-full max-w-sm overflow-hidden text-center"
      >
        <div className="bg-emerald-600 p-8 text-white relative">
          <div className="flex items-center justify-center gap-2 mb-6">
            <ShieldEllipsis className="w-6 h-6 text-emerald-200" />
            <span className="font-black tracking-tighter text-sm uppercase">PK Escrow</span>
          </div>
          <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
            <ShieldEllipsis className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl font-black tracking-tight">
            {step === 'create' ? 'Create MPIN' : 'Confirm MPIN'}
          </h2>
          <p className="text-emerald-100 mt-2 font-medium">Step 3 of 3: Secure Access</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {error && (
            <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-sm font-bold">
              {error}
            </div>
          )}
          <div onClick={focusInput} className="cursor-pointer">
            <p className="text-slate-500 font-medium mb-6">
              {step === 'create' 
                ? 'Enter a 4-digit PIN for quick access to your account and transactions.' 
                : 'Please re-enter your 4-digit PIN to confirm.'}
            </p>

            {step === 'confirm' && (
              <button 
                type="button"
                onClick={goBack}
                className="mb-4 text-xs font-black text-emerald-600 uppercase tracking-widest hover:text-emerald-700 underline underline-offset-4"
              >
                ← Back to create
              </button>
            )}
            
            <div className="flex justify-center gap-3">
              {[0, 1, 2, 3].map((i) => (
                <div 
                  key={i}
                  className={`w-14 h-16 rounded-2xl border-2 flex items-center justify-center text-3xl font-black transition-all ${
                    currentVal.length > i ? 'border-emerald-500 bg-emerald-50 text-emerald-600 shadow-lg shadow-emerald-500/10' : 'border-slate-200 bg-slate-50 text-slate-300'
                  } ${currentVal.length === i ? 'ring-4 ring-emerald-500/10 border-emerald-300' : ''}`}
                >
                  {currentVal.length > i ? '•' : ''}
                </div>
              ))}
            </div>
            
            <input 
              ref={inputRef}
              type="tel"
              inputMode="numeric"
              autoFocus
              maxLength={4}
              value={currentVal}
              onChange={(e) => handleMpinChange(e.target.value)}
              className="sr-only"
            />
          </div>

          <button 
            type="submit"
            disabled={loading || currentVal.length !== 4}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-500/10"
          >
            {loading ? 'Processing...' : (
              <>
                {step === 'create' ? <ShieldEllipsis className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
                {step === 'create' ? 'Next' : 'Complete Setup'}
              </>
            )}
          </button>
        </form>
      </motion.div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { getTranslation } from '../lib/translations';
import { 
  Terminal as TerminalIcon, 
  ShieldAlert, 
  Database,
  Activity,
  Cpu,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  UserMinus,
  Eye,
  Settings,
  Layers,
  Lock,
  Unlock,
  FileText,
  Globe,
  Loader2,
  Sparkles,
  Search,
  Server,
  ArrowRight,
  ChevronRight,
  HelpCircle,
  XCircle,
  Plus,
  Scale,
  Users,
  TrendingUp,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  MapPin,
  Clipboard,
  ShieldCheck,
  Smartphone,
  Banknote,
  Send,
  Trash2,
  UserCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  getDocs, 
  doc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  serverTimestamp,
  getDoc,
  setDoc,
  increment,
  addDoc
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { sendNotification } from '../lib/notifications';

// Interfaces for Firebase documents
interface UserProfile {
  id: string;
  displayName?: string;
  fullName?: string;
  phoneNumber: string;
  email?: string;
  onboardingStatus?: string;
  verificationLevel?: number;
  cnicNumber?: string;
  ibanNumber?: string;
  bankName?: string;
  accountHolderName?: string;
  cnicFrontImage?: string | null;
  cnicBackImage?: string | null;
  completedDeals?: number;
  ratingSum?: number;
  ratingCount?: number;
  isDeleted?: boolean;
  createdAt?: any;
}

interface EscrowDocument {
  id: string;
  buyerId: string;
  buyerPhone: string;
  sellerId: string;
  sellerPhone: string;
  amount: number;
  escrowFee?: number;
  totalAmount?: number;
  status: string;
  itemDescription: string;
  deliveryMode: string;
  initiatorId: string;
  isChatOpen?: boolean;
  payoutStatus?: 'PENDING' | 'PAID';
  payoutTxId?: string;
  payoutProcessedAt?: any;
  projectDeadlines?: string;
  milestones?: string;
  trackingId?: string;
  courier?: string;
  isPhysical?: boolean;
  shippingAddress?: string;
  createdAt?: any;
  payment_status?: string;
  receipt_url?: string;
  paymentDetails?: {
    method: string;
    tid: string;
    senderAccount: string;
    senderName: string;
    receiptImage: string;
    submittedAt: string;
  };
}

interface DepositDocument {
  id: string;
  userId: string;
  amount: number;
  method: string;
  senderAccount: string;
  senderName: string;
  transactionId: string;
  bankName?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt?: string;
  receiptImage?: string | null;
}

export function AdminView() {
  const { view, setView, lang, profile } = useAuth();
  const t = getTranslation(lang);

  const isAdmin = profile?.isAdmin === true || profile?.phoneNumber === '+923000000001' || profile?.role === 'Admin' || profile?.role === 'admin';

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#090d16] flex items-center justify-center p-4">
        <div className="bg-[#0d1425] border border-red-500/20 max-w-md w-full p-8 rounded-3xl text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center text-red-400 mx-auto text-xl">
            🔒
          </div>
          <h2 className="text-lg font-black uppercase text-red-500 tracking-wider">Access Denied / غیر مجاز رسائی</h2>
          <p className="text-slate-400 text-xs leading-relaxed font-semibold">
            Only authorized platform administrators are allowed access to the Ledger Arbitration Cockpit.
          </p>
          <button
            onClick={() => setView('dashboard')}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  // Filter Tabs
  const [activeAdminTab, setActiveAdminTab] = useState<'escrows' | 'payouts' | 'disputes' | 'users' | 'deposits' | 'system'>('escrows');

  // System official bank account states
  const [adminEasypaisaNum, setAdminEasypaisaNum] = useState('');
  const [adminJazzcashNum, setAdminJazzcashNum] = useState('');
  const [adminBankName, setAdminBankName] = useState('');
  const [adminIbanNum, setAdminIbanNum] = useState('');
  const [adminHolderName, setAdminHolderName] = useState('');
  const [isSavingSystemDetails, setIsSavingSystemDetails] = useState(false);

  // Firebase Collections States
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [escrows, setEscrows] = useState<EscrowDocument[]>([]);
  const [deposits, setDeposits] = useState<DepositDocument[]>([]);

  // Fetch admin_wallet details on mount
  useEffect(() => {
    const fetchAdminWalletConfig = async () => {
      try {
        const snap = await getDoc(doc(db, 'users', 'admin_wallet'));
        if (snap.exists()) {
          const data = snap.data();
          setAdminEasypaisaNum(data.easypaisaNumber || '');
          setAdminJazzcashNum(data.jazzcashNumber || '');
          setAdminBankName(data.bankName || '');
          setAdminIbanNum(data.ibanNumber || '');
          setAdminHolderName(data.accountHolderName || '');
        }
      } catch (err) {
        console.warn("Failed loading admin_wallet configs:", err);
      }
    };
    fetchAdminWalletConfig();
  }, []);

  const handleSaveSystemDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSystemDetails(true);
    try {
      const adminWalletRef = doc(db, 'users', 'admin_wallet');
      await setDoc(adminWalletRef, {
        displayName: 'PK Escrow Admin (Platform)',
        phoneNumber: '+923000000001',
        easypaisaNumber: adminEasypaisaNum.trim(),
        jazzcashNumber: adminJazzcashNum.trim(),
        bankName: adminBankName.trim(),
        ibanNumber: adminIbanNum.trim(),
        accountHolderName: adminHolderName.trim(),
        isAdmin: true,
        onboardingStatus: 'APPROVED',
        isVerified: true,
        updatedAt: serverTimestamp()
      }, { merge: true });
      
      pushTelemetryLog("Official system holding account coordinates successfully locked.");
      alert("System coordinates updated successfully! (سسٹم اکاؤنٹ کی معلومات اپ ڈیٹ ہو گئیں)");
    } catch (err) {
      console.error("Failed saving admin_wallet details:", err);
      alert("Error saving: " + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsSavingSystemDetails(false);
    }
  };

  
  // Search / Selection states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEscrow, setSelectedEscrow] = useState<EscrowDocument | null>(null);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [selectedDeposit, setSelectedDeposit] = useState<DepositDocument | null>(null);

  // Processing triggers
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [telemetryLogs, setTelemetryLogs] = useState<string[]>([]);

  // Payout Form Modal
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
  const [payoutTargetEscrow, setPayoutTargetEscrow] = useState<EscrowDocument | null>(null);
  const [payoutTargetSeller, setPayoutTargetSeller] = useState<UserProfile | null>(null);
  const [payoutTxId, setPayoutTxId] = useState('');
  const [payoutNotes, setPayoutNotes] = useState('');

  // Dispute Arbitration Form States
  const [isDisputeModalOpen, setIsDisputeModalOpen] = useState(false);
  const [disputeNotes, setDisputeNotes] = useState('');

  // Lightbox Image viewer for direct P2P receipt audits
  const [lightboxImageUrl, setLightboxImageUrl] = useState<string | null>(null);

  // AI-Powered Receipt OCR Verification State
  const [aiAuditTarget, setAiAuditTarget] = useState<{
    id: string;
    type: 'escrow' | 'deposit';
    receiptUrl: string;
    expectedTid: string;
    expectedAmount: number;
    originalDoc: any;
  } | null>(null);
  const [isAiAuditing, setIsAiAuditing] = useState(false);
  const [aiReport, setAiReport] = useState<{
    isReceipt: boolean;
    detectedTid: string;
    detectedAmount: number;
    transactionDate: string;
    matchesTid: boolean;
    matchesAmount: boolean;
    confidence: 'high' | 'medium' | 'low';
    verdict: 'MATCH' | 'PARTIAL_MATCH' | 'MISMATCH';
    analysis: string;
  } | null>(null);
  const [aiAuditError, setAiAuditError] = useState<string | null>(null);

  const startAiAudit = async (
    id: string,
    type: 'escrow' | 'deposit',
    receiptUrl: string,
    expectedTid: string,
    expectedAmount: number,
    originalDoc: any
  ) => {
    setAiAuditTarget({ id, type, receiptUrl, expectedTid, expectedAmount, originalDoc });
    setAiReport(null);
    setAiAuditError(null);
    setIsAiAuditing(true);
    pushTelemetryLog(`[FAST_AUDIT_START] Triggered high-speed digital auditing on ${type} #${id}. Fetching report from PK Fast-Scan node...`);
    
    const payMethod = originalDoc?.paymentDetails?.method || 'easypaisa';
    const expectedRecipientAccount = payMethod === 'raast' ? '215400182600001' : '03054333292';
    const expectedRecipientName = 'PK ESCROW CENTRAL HOLDINGS';

    try {
      const response = await fetch('/api/verify-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: receiptUrl,
          expectedTid: expectedTid,
          expectedAmount: expectedAmount,
          expectedRecipientAccount,
          expectedRecipientName
        })
      });
      if (!response.ok) {
        throw new Error(`AI audit endpoint responded with status: ${response.status}`);
      }
      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setAiReport(data);
      pushTelemetryLog(`[AI_AUDIT_COMPLETED] Verification verdict: ${data.verdict} with ${data.confidence} confidence.`);
    } catch (err: any) {
      console.error("AI Audit error:", err);
      setAiAuditError(err.message || 'Verification connection failed.');
      pushTelemetryLog(`[AI_AUDIT_ERROR] Verification failed: ${err.message}`);
    } finally {
      setIsAiAuditing(false);
    }
  };

  const approveEscrowFromAi = async (escrow: EscrowDocument) => {
    setIsProcessing(true);
    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      await updateDoc(escrowRef, {
        status: 'FUNDED',
        payment_status: 'held',
        isPaymentSubmitted: true,
        updatedAt: serverTimestamp()
      });

      // Send notifications to buyer and seller
      await sendNotification(
        escrow.buyerId,
        'Payment APPROVED! 🛡️',
        `Your direct transfer receipt of Rs. ${escrow.amount.toLocaleString()} has been APPROVED by PK Escrow compliance! Funds are secure in holding.`,
        'SUCCESS',
        escrow.id
      ).catch(e => console.warn(e));

      await sendNotification(
        escrow.sellerId,
        'Direct Deposit Locked 🔒',
        `Compliance has verified the buyer's receipt and locked Rs. ${escrow.amount.toLocaleString()} in secure holding. Proceed to fulfill work!`,
        'SUCCESS',
        escrow.id
      ).catch(e => console.warn(e));

      // Add audit history to deal room chat
      const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
      await addDoc(msgsCollection, {
        text: `📢 COMPLIANCE AUDIT APPROVED via PK Escrow AI Smart Verification!\n• Status: Paid and Locked (Vault Holds Rs. ${escrow.amount.toLocaleString()})\n• Verification Reference TID: ${escrow.paymentDetails?.tid || 'N/A'}\n• Message: AI Compliance engine matching confirmed: ${aiReport?.analysis || ''}`,
        senderId: 'SYSTEM_BOT',
        senderName: 'Compliance Auditor',
        createdAt: new Date().toISOString()
      });

      pushTelemetryLog(`[AI_AUDIT_APPROVE] Approved Direct payment for escrow #${escrow.id}. Ledger funded.`);
      setAiAuditTarget(null);
      setAiReport(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] AI Verification approve failed: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const rejectEscrowFromAi = async (escrow: EscrowDocument) => {
    setIsProcessing(true);
    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      await updateDoc(escrowRef, {
        payment_status: 'failed_proof',
        updatedAt: serverTimestamp()
      });

      // Send notifications to buyer
      await sendNotification(
        escrow.buyerId,
        'Payment Proof REJECTED ❌',
        `The submitted transaction proof (TID: ${escrow.paymentDetails?.tid || 'N/A'}) was flagged as invalid by the AI Compliance auditor. Explanation: ${aiReport?.analysis || ''}`,
        'DANGER',
        escrow.id
      ).catch(e => console.warn(e));

      // Add to chat room
      const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
      await addDoc(msgsCollection, {
        text: `⚠️ PAYMENT AUDIT REJECTED!\n• Status: Payment Proof Rejected\n• Explanation: ${aiReport?.analysis || ''}`,
        senderId: 'SYSTEM_BOT',
        senderName: 'Compliance Auditor',
        createdAt: new Date().toISOString()
      });

      pushTelemetryLog(`[AI_AUDIT_REJECT] Rejected payment proof for escrow #${escrow.id}. Notification dispatched.`);
      setAiAuditTarget(null);
      setAiReport(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] AI Verification reject failed: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const approveDepositFromAi = async (dep: DepositDocument) => {
    setIsProcessing(true);
    try {
      await handleApproveDeposit(dep, true);
      pushTelemetryLog(`[AI_AUDIT_APPROVE] Approved deposit #${dep.id} via AI assist.`);
      setAiAuditTarget(null);
      setAiReport(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] AI deposit approve failed: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const rejectDepositFromAi = async (dep: DepositDocument) => {
    setIsProcessing(true);
    try {
      await handleApproveDeposit(dep, false);
      pushTelemetryLog(`[AI_AUDIT_REJECT] Rejected deposit #${dep.id} via AI assist.`);
      setAiAuditTarget(null);
      setAiReport(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] AI deposit reject failed: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Add Log Helper
  const pushTelemetryLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setTelemetryLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 40)]);
  };

  // Real-time Firestore Sync on Mount
  useEffect(() => {
    pushTelemetryLog("Handshaking with safe cloud Firebase Firestore...");
    setIsLoading(true);

    // 1. Sync Escrows
    const escrowsQuery = query(collection(db, 'escrows'), orderBy('createdAt', 'desc'), limit(100));
    const unsubEscrows = onSnapshot(escrowsQuery, (snapshot) => {
      const list: EscrowDocument[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as EscrowDocument);
      });
      setEscrows(list);
      pushTelemetryLog(`Parsed ${list.length} dynamic escrow agreements from ledger.`);
    }, (err) => {
      pushTelemetryLog(`[ERROR] Escrow sync rejected: ${err.message}`);
    });

    // 2. Sync Users
    const usersQuery = query(collection(db, 'users'), limit(150));
    const unsubUsers = onSnapshot(usersQuery, (snapshot) => {
      const list: UserProfile[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as UserProfile);
      });
      setUsers(list);
      pushTelemetryLog(`Secured profiles telemetry for ${list.length} network members.`);
    }, (err) => {
      pushTelemetryLog(`[ERROR] Profile sync rejected: ${err.message}`);
    });

    // 3. Sync Deposits (for old deposit verification if any exist)
    const depositsQuery = query(collection(db, 'deposits'), orderBy('createdAt', 'desc'), limit(50));
    const unsubDeposits = onSnapshot(depositsQuery, (snapshot) => {
      const list: DepositDocument[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as DepositDocument);
      });
      setDeposits(list);
      if (list.length > 0) {
        pushTelemetryLog(`Discovered ${list.length} physical payment gateway screenshots.`);
      }
    }, (err) => {
      pushTelemetryLog(`[ERROR] Deposits audit rejected: ${err.message}`);
    });

    // Timeout loading state
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1200);

    return () => {
      unsubEscrows();
      unsubUsers();
      unsubDeposits();
      clearTimeout(timer);
    };
  }, []);

  // Compute stats helper
  const totalSecuredVolume = escrows
    .filter(e => e.status === 'COMPLETED' || e.status === 'FUNDED' || e.status === 'SHIPPED' || e.status === 'DELIVERED')
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);

  const activeEscrowsCount = escrows.filter(e => e.status !== 'COMPLETED' && e.status !== 'CANCELLED').length;
  const pendingPayoutsCount = escrows.filter(e => e.status === 'COMPLETED' && e.payoutStatus !== 'PAID').length;
  const totalDisputesCount = escrows.filter(e => e.status === 'DISPUTED').length;
  const totalDepositsPending = deposits.filter(d => d.status === 'PENDING').length;

  // Handle Dispatch Payout Action
  const handleOpenPayoutModal = async (escrow: EscrowDocument) => {
    setPayoutTargetEscrow(escrow);
    setPayoutTxId('');
    setPayoutNotes('');
    
    pushTelemetryLog(`Loading payout configurations for Seller ID: ${escrow.sellerId}...`);
    try {
      const sellerSnap = await getDoc(doc(db, 'users', escrow.sellerId));
      if (sellerSnap.exists()) {
        const sellerProfile = { id: sellerSnap.id, ...sellerSnap.data() } as UserProfile;
        setPayoutTargetSeller(sellerProfile);
        pushTelemetryLog(`Successfully mapped seller payment details (IBAN: ${sellerProfile.ibanNumber || 'none'}).`);
      } else {
        setPayoutTargetSeller(null);
        pushTelemetryLog(`[WARNING] Seller profile document not found in directory.`);
      }
      setIsPayoutModalOpen(true);
    } catch (e: any) {
      pushTelemetryLog(`[ERROR] Failed to map seller details: ${e.message}`);
    }
  };

  const handleConfirmPayoutDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payoutTargetEscrow || !payoutTxId.trim()) return;

    setIsProcessing(true);
    pushTelemetryLog(`PROPOSING OUTBOUND SETTLEMENT for Escrow ID: ${payoutTargetEscrow.id}`);

    try {
      const escrowRef = doc(db, 'escrows', payoutTargetEscrow.id);
      await updateDoc(escrowRef, {
        payoutStatus: 'PAID',
        payoutTxId: payoutTxId.trim(),
        payoutNotes: payoutNotes.trim(),
        payoutProcessedAt: new Date().toISOString()
      });

      // Send automated notification explaining direct bank transfer TID info
      await sendNotification(
        payoutTargetEscrow.sellerId,
        'Payout Dispatched 💸',
        `Rs. ${(payoutTargetEscrow.amount * 0.99).toLocaleString()} (after 1% platform fee) was successfully dispatched to your secure external bank/wallet. TID: ${payoutTxId.trim()}`,
        'SUCCESS',
        payoutTargetEscrow.id
      );

      pushTelemetryLog(`[SUCCESS] Outbound payout verified & finalized under TID: ${payoutTxId}`);
      setIsPayoutModalOpen(false);
      setPayoutTargetEscrow(null);
      setPayoutTargetSeller(null);
    } catch (err: any) {
      pushTelemetryLog(`[CRITICAL] Payout Dispatch Failed: ${err.message}`);
      alert("Error processing payout log: " + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle Dispute Arbitration Settle Action
  const handleArbitrateDispute = async (escrow: EscrowDocument, decision: 'RELEASE_TO_SELLER' | 'REFUND_TO_BUYER') => {
    if (!window.confirm(`Are you absolutely sure you want to arbitrate this dispute?\nDecision: ${decision.replace(/_/g, ' ')}\nThis action is final, irreversible, and releases escrow holdings.`)) {
      return;
    }

    setIsProcessing(true);
    pushTelemetryLog(`ESTABLISHING ARBITRATION RESOLUTION for dispute: ${escrow.id}`);

    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      
      if (decision === 'RELEASE_TO_SELLER') {
        const commissionRate = 0.01;
        const commission = Math.round(escrow.amount * commissionRate);
        const netSellerPayout = escrow.amount - commission;

        await updateDoc(escrowRef, {
          status: 'COMPLETED',
          payoutStatus: 'PENDING',
          arbitrationDecision: 'RELEASE_TO_SELLER',
          arbitratedAt: new Date().toISOString(),
          arbitrationNotes: disputeNotes.trim() || 'Arbitrator ruled in favor of Seller after reviewing proof.'
        });

        // Add deal stats
        const sellerRef = doc(db, 'users', escrow.sellerId);
        await updateDoc(sellerRef, {
          completedDeals: increment(1)
        }).catch(err => console.warn(err));

        // Notify Buyer
        await sendNotification(
          escrow.buyerId,
          'Arbitration Completed ⚖️',
          `The dispute for "${escrow.itemDescription}" has been reviewed. Holdings were released to the seller. Case closed.`,
          'INFO',
          escrow.id
        );

        // Notify Seller
        await sendNotification(
          escrow.sellerId,
          'Dispute Resolved in Seller\'s Favor! 🎉',
          `Holdings for "${escrow.itemDescription}" released to you. Your direct checkout payout is pending dispatch.`,
          'SUCCESS',
          escrow.id
        );

        pushTelemetryLog(`[DECISION] Ruled in favor of Seller. Escrow completed, payout initialized.`);
      } else {
        // Refund Buyer
        await updateDoc(escrowRef, {
          status: 'CANCELLED',
          arbitrationDecision: 'REFUND_TO_BUYER',
          arbitratedAt: new Date().toISOString(),
          arbitrationNotes: disputeNotes.trim() || 'Arbitrator ruled to refund the Buyer.'
        });

        // Notify Buyer
        await sendNotification(
          escrow.buyerId,
          'Arbitration Refund Approved 💸',
          `The dispute was ruled in your favor. Payout of Rs. ${escrow.amount.toLocaleString()} is refunded.`,
          'SUCCESS',
          escrow.id
        );

        // Notify Seller
        await sendNotification(
          escrow.sellerId,
          'Arbitration Closed (Refunded) ⚠️',
          `Arbitrator ruled to cancel contract "${escrow.itemDescription}" and refund the buyer.`,
          'DANGER',
          escrow.id
        );

        pushTelemetryLog(`[DECISION] Ruled in favor of Buyer. Escrow cancelled & buyer refunded.`);
      }

      setIsDisputeModalOpen(false);
      setSelectedEscrow(null);
      setDisputeNotes('');
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] Arbitration ruling rejected: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Upgrades / modifies profile verification level directly
  const handleUpgradeUserRank = async (userProf: UserProfile, targetLevel: number) => {
    pushTelemetryLog(`MUTATING MEMBER RANK for UID: ${userProf.id} to Level ${targetLevel}`);
    try {
      const userRef = doc(db, 'users', userProf.id);
      await updateDoc(userRef, {
        verificationLevel: targetLevel,
        onboardingStatus: 'COMPLETED'
      });

      await sendNotification(
        userProf.id,
        'Account Verification Level Upgraded! 🛡️',
        `Congratulations! PK Escrow Security Council upgraded your status to Level ${targetLevel}. Your daily limits have increased.`,
        'SUCCESS'
      ).catch(e => console.warn(e));

      pushTelemetryLog(`[SUCCESS] UID: ${userProf.id} successfully updated to Verification Level ${targetLevel}.`);
      setSelectedUser(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] Verification upgrade rejected: ${err.message}`);
    }
  };

  // Ban/Reinstate member status
  const handleToggleMemberBan = async (userProf: UserProfile) => {
    const isBan = !userProf.isDeleted;
    const actionText = isBan ? 'BAN/ISOLATE' : 'REINSTATE';
    
    if (!window.confirm(`Are you sure you want to ${actionText} member: ${userProf.displayName || 'Offline User'} (${userProf.phoneNumber})?`)) {
      return;
    }

    pushTelemetryLog(`MUTATING DIRECTORY PRIVILEGES for phone: ${userProf.phoneNumber}`);
    try {
      const userRef = doc(db, 'users', userProf.id);
      await updateDoc(userRef, {
        isDeleted: isBan,
        onboardingStatus: isBan ? 'DELETED' : 'COMPLETED'
      });

      pushTelemetryLog(`[SUCCESS] User account ${actionText} successful. Secure tokens flushed.`);
      setSelectedUser(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] Directory mutate failed: ${err.message}`);
    }
  };

  // Approve manual deposit (for legacy wallet requests if any are pending)
  const handleApproveDeposit = async (dep: DepositDocument, isApprove: boolean) => {
    pushTelemetryLog(`MUTATING DEPOSIT TICKET ID: ${dep.id}`);
    try {
      const depRef = doc(db, 'deposits', dep.id);
      const targetState = isApprove ? 'APPROVED' : 'REJECTED';
      
      await updateDoc(depRef, {
        status: targetState,
        reviewedAt: new Date().toISOString()
      });

      if (isApprove) {
        // Increment their profile balance (if any legacy wallets are used)
        const userRef = doc(db, 'users', dep.userId);
        await updateDoc(userRef, {
          balance: increment(dep.amount)
        }).catch(e => console.warn(e));

        await sendNotification(
          dep.userId,
          'Deposit Receipt Confirmed! ✅',
          `Your upload of Rs. ${dep.amount.toLocaleString()} has been audited & credit loaded to your profile wallet. TID: ${dep.transactionId}`,
          'SUCCESS'
        ).catch(e => console.warn(e));

        pushTelemetryLog(`[AUDIT] Deposit validated. Credited Rs. ${dep.amount} to user.`);
      } else {
        await sendNotification(
          dep.userId,
          'Deposit Screenshot Rejected ❌',
          `The submitted transaction receipt proof was rejected by the admin panel. Please contact customer support.`,
          'DANGER'
        ).catch(e => console.warn(e));

        pushTelemetryLog(`[AUDIT] Receipt flagged false / rejected. Notification dispatched.`);
      }

      setSelectedDeposit(null);
    } catch (err: any) {
      pushTelemetryLog(`[ERROR] Deposit update failed: ${err.message}`);
    }
  };

  // Filter list by search query
  const filteredEscrows = escrows.filter(e => {
    const q = searchQuery.toLowerCase();
    const tid = (e.paymentDetails?.tid || '').toLowerCase();
    return (
      e.id.toLowerCase().includes(q) ||
      (e.itemDescription || '').toLowerCase().includes(q) ||
      (e.buyerPhone || '').toLowerCase().includes(q) ||
      (e.sellerPhone || '').toLowerCase().includes(q) ||
      tid.includes(q)
    );
  });

  const filteredPayouts = escrows.filter(e => e.status === 'COMPLETED').filter(e => {
    const q = searchQuery.toLowerCase();
    const tid = (e.paymentDetails?.tid || '').toLowerCase();
    return (
      e.id.toLowerCase().includes(q) ||
      (e.itemDescription || '').toLowerCase().includes(q) ||
      (e.buyerPhone || '').toLowerCase().includes(q) ||
      (e.sellerPhone || '').toLowerCase().includes(q) ||
      tid.includes(q)
    );
  });

  const filteredDisputes = escrows.filter(e => e.status === 'DISPUTED').filter(e => {
    const q = searchQuery.toLowerCase();
    const tid = (e.paymentDetails?.tid || '').toLowerCase();
    return (
      e.id.toLowerCase().includes(q) ||
      (e.itemDescription || '').toLowerCase().includes(q) ||
      (e.buyerPhone || '').toLowerCase().includes(q) ||
      (e.sellerPhone || '').toLowerCase().includes(q) ||
      tid.includes(q)
    );
  });

  const filteredDeposits = deposits.filter(dep => {
    const q = searchQuery.toLowerCase();
    const depId = dep.id || '';
    const name = (dep.senderName || '').toLowerCase();
    const phone = (dep.senderAccount || '').toLowerCase();
    const tid = (dep.transactionId || '').toLowerCase();
    return (
      depId.toLowerCase().includes(q) ||
      name.includes(q) ||
      phone.includes(q) ||
      tid.includes(q)
    );
  });

  const filteredUsers = users.filter(u => {
    const q = searchQuery.toLowerCase();
    const phone = u.phoneNumber || '';
    const name = (u.displayName || u.fullName || '').toLowerCase();
    const cnic = (u.cnicNumber || '').toLowerCase();
    return phone.includes(q) || name.includes(q) || cnic.includes(q);
  });

  return (
    <div id="admin-view-root" className="min-h-screen bg-[#090d16] text-slate-100 font-sans select-none antialiased relative overflow-x-hidden p-0">
      
      {/* CRT SCANLINE EFFECT */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,24,38,0)_50%,rgba(0,0,0,0.15)_50%)] bg-[size:100%_4px] opacity-10 z-30" />

      {/* HEADER BAR */}
      <header className="border-b border-indigo-500/20 bg-[#0d1425] sticky top-0 z-40 backdrop-blur shadow-md">
        <div className="max-w-7xl mx-auto px-6 h-18 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 bg-indigo-500/10 border border-indigo-500/30 rounded-xl flex items-center justify-center text-indigo-400">
              <Scale className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-slate-200 font-black tracking-wider text-sm uppercase">PK Escrow Solutions</span>
                <span className="bg-indigo-500/10 text-indigo-400 border border-indigo-400/20 text-[9px] uppercase font-bold px-2 py-0.5 rounded tracking-widest leading-none">
                  ADMIN HUB 👑
                </span>
              </div>
              <p className="text-[10px] text-slate-400">Arbiter Dashboard & External Settlement Dispatch Cockpit</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="back-btn"
              onClick={() => setView('dashboard')}
              className="px-4 py-2 border border-slate-700 hover:border-slate-500 text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer bg-slate-900/40 flex items-center gap-2 active:scale-95"
            >
              <ArrowRight className="w-3.5 h-3.5 rotate-180" /> Back to App
            </button>
          </div>
        </div>
      </header>

      {/* DYNAMIC TELEMETRY STATUS BANNER */}
      <div className="bg-indigo-950/20 border-b border-indigo-500/10 py-2.5 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] font-mono">
          <div className="flex items-center gap-2 text-indigo-400 font-bold">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
            <span>SECURED FIRESTORE AGENT ONLINE</span>
          </div>
          <p className="text-slate-400 font-medium">
            Verified Local Timestamp: {new Date().toLocaleTimeString()} | Platform: Cloud Run Sandboxed Node Environment
          </p>
        </div>
      </div>

      {/* CORE LAYOUT FRAME */}
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">

        {/* OVERVIEW STATS GRID */}
        <section className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-[#0e162a] border border-indigo-500/15 p-4.5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-[9px] font-black uppercase tracking-widest">Total Volume</span>
            </div>
            <p className="text-xl font-black text-white font-mono">Rs. {totalSecuredVolume.toLocaleString()}</p>
            <p className="text-[9px] text-emerald-400 font-semibold">Active & Completed sum</p>
          </div>

          <div className="bg-[#0e162a] border border-indigo-500/15 p-4.5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span className="text-[9px] font-black uppercase tracking-widest">Active Deals</span>
            </div>
            <p className="text-xl font-black text-white font-mono">{activeEscrowsCount}</p>
            <p className="text-[9px] text-slate-400 font-semibold">Escrows in progress</p>
          </div>

          <div className="bg-[#0e162a] border border-indigo-500/15 p-4.5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <Banknote className="w-4 h-4 text-rose-400 animate-pulse" />
              <span className="text-[9px] font-black uppercase tracking-widest">Owed Payouts</span>
            </div>
            <p className="text-xl font-black text-rose-400 font-mono">{pendingPayoutsCount}</p>
            <p className="text-[9px] text-rose-300 font-semibold">Requires dispatch</p>
          </div>

          <div className="bg-[#0e162a] border border-indigo-500/15 p-4.5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <AlertCircle className="w-4 h-4 text-amber-400 animate-bounce" />
              <span className="text-[9px] font-black uppercase tracking-widest font-sans">Active Disputes</span>
            </div>
            <p className="text-xl font-black text-amber-400 font-mono">{totalDisputesCount}</p>
            <p className="text-[9px] text-amber-300 font-semibold">Awaiting arbitration</p>
          </div>

          <div className="bg-[#0e162a] border border-indigo-500/15 p-4.5 rounded-2xl col-span-2 md:col-span-1 space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <Users className="w-4 h-4 text-indigo-400" />
              <span className="text-[9px] font-black uppercase tracking-widest">Total Users</span>
            </div>
            <p className="text-xl font-black text-white font-mono">{users.length}</p>
            <p className="text-[9px] text-indigo-400 font-semibold">Registered accounts</p>
          </div>
        </section>

        {/* PRIMARY CONTAINER BLOCK WITH TABBED Cockpit NAVIGATION */}
        <section className="bg-[#0d1425] border border-indigo-500/15 rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          
          {/* LEFT PANELS NAVIGATION TABS (Bilingual Styled) */}
          <div className="w-full lg:w-64 border-b lg:border-b-0 lg:border-r border-indigo-500/15 p-5 bg-[#0b101f] shrink-0 space-y-4">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block px-2">Navigation Panel</span>
            
            <div className="flex flex-row lg:flex-col gap-1.5 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0 scrollbar-none">
              <button 
                id="tab-escrows-btn"
                onClick={() => { setActiveAdminTab('escrows'); setSearchQuery(''); }}
                className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                  activeAdminTab === 'escrows' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Deals Ledger ({escrows.length})</span>
              </button>

              <button 
                id="tab-payouts-btn"
                onClick={() => { setActiveAdminTab('payouts'); setSearchQuery(''); }}
                className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                  activeAdminTab === 'payouts' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>Outbound Payouts ({pendingPayoutsCount})</span>
              </button>

              <button 
                id="tab-disputes-btn"
                onClick={() => { setActiveAdminTab('disputes'); setSearchQuery(''); }}
                className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                  activeAdminTab === 'disputes' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>Arbitration disputes ({totalDisputesCount})</span>
              </button>

              <button 
                id="tab-users-btn"
                onClick={() => { setActiveAdminTab('users'); setSearchQuery(''); }}
                className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                  activeAdminTab === 'users' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>User Directory ({users.length})</span>
              </button>

              <button 
                id="tab-system-btn"
                onClick={() => { setActiveAdminTab('system'); setSearchQuery(''); }}
                className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                  activeAdminTab === 'system' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Holding Accounts (مرکزی اکاؤنٹس)</span>
              </button>

              {deposits.length > 0 && (
                <button 
                  id="tab-deposits-btn"
                  onClick={() => { setActiveAdminTab('deposits'); setSearchQuery(''); }}
                  className={`flex-1 lg:flex-none flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left whitespace-nowrap cursor-pointer ${
                    activeAdminTab === 'deposits' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-900/40 hover:text-slate-200'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Manual Receipts ({totalDepositsPending})</span>
                </button>
              )}
            </div>

            <div className="border-t border-indigo-500/10 pt-4 hidden lg:block">
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest block px-2 mb-2">QUICK CONTROLS</span>
              <button
                id="force-sync-btn"
                onClick={() => pushTelemetryLog("Explicit system memory state synchronization completed successfully.")}
                className="w-full text-left flex items-center gap-2 px-2.5 py-1.5 text-[10px] text-slate-400 hover:text-slate-200 hover:bg-slate-950 font-bold font-mono rounded-lg transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5 text-indigo-400 animate-spin-slow" />
                <span>TELEMETRY_REFRESH</span>
              </button>
            </div>
          </div>

          {/* MAIN DYNAMIC CONTENT WORKSPACE */}
          <div className="flex-1 p-6 space-y-6">

            {/* HEADER BOX WITH SEARCH */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-indigo-500/10 pb-4">
              <div>
                <h2 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                  {activeAdminTab === 'escrows' && '🔒 ACTIVE DEALS LEDGER (CRYPTO CONTRACTS)'}
                  {activeAdminTab === 'payouts' && '💸 OUTBOUND MANUAL PAYOUT DISPATCHES'}
                  {activeAdminTab === 'disputes' && '⚖️ ARBITRATION TICKET ACTION DEPT'}
                  {activeAdminTab === 'users' && '👥 PLATFORM USER ROSTER & PRIVILEGES'}
                  {activeAdminTab === 'deposits' && '🟢 INBOUND SECURE RECEIPT CHECKS'}
                  {activeAdminTab === 'system' && '💼 CENTRAL ESCROW PAYMENT COORDINATES'}
                </h2>
                <p className="text-[11px] text-slate-400">
                  {activeAdminTab === 'escrows' && 'Audibly scan and interact with direct P2P contracts stored inside Firestore datastores.'}
                  {activeAdminTab === 'payouts' && 'Mark completions as paid. Retrieve seller outbound payment configurations directly for dispatch.'}
                  {activeAdminTab === 'disputes' && 'Resolve active transaction complaints by ruling in favor of either seller or buyer.'}
                  {activeAdminTab === 'users' && 'Monitor verification states (Level 1, 2, 3), reset user security settings or force-isolate accounts.'}
                  {activeAdminTab === 'deposits' && 'Approve uploaded receipts from EasyPaisa / JazzCash and verify transaction reference IDs.'}
                  {activeAdminTab === 'system' && 'Customize the official EasyPaisa, JazzCash, or Block bank account details displayed to checking out buyers.'}
                </p>
              </div>

              {/* SEARCH FILTER */}
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  id="admin-search-input"
                  type="text"
                  placeholder="Filter records..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-indigo-500/15 text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white font-mono placeholder:text-slate-600"
                />
              </div>
            </div>

            {/* TAB-SPECIFIC TABLES & VIEWS */}
            
            {/* VIEW A: ESCROWS LEDGER */}
            {activeAdminTab === 'escrows' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/60 text-slate-400 text-[10px] font-mono tracking-wider border-b border-indigo-500/10 uppercase">
                      <th className="py-3 px-4">Agreement ID</th>
                      <th className="py-3 px-4">Deal Description</th>
                      <th className="py-3 px-4">Parties</th>
                      <th className="py-3 px-4">Deal Value</th>
                      <th className="py-3 px-4">Direct Receipt (P2P)</th>
                      <th className="py-3 px-4 text-center">Status Badge</th>
                      <th className="py-3 px-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-indigo-500/5">
                    {filteredEscrows.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-500 font-mono">
                          ◆ NO MATCHING FIRESTORE ESCROWS FOUND ◆
                        </td>
                      </tr>
                    ) : (
                      filteredEscrows.map((escrow) => (
                        <tr key={escrow.id} className="hover:bg-slate-900/35 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-indigo-400">{escrow.id.slice(0, 8)}...</td>
                          <td className="py-3 px-4 max-w-sm truncate" title={escrow.itemDescription}>
                            <span className="font-bold text-slate-200">{escrow.itemDescription}</span>
                            <span className="block text-[10px] text-slate-500 capitalize">{escrow.deliveryMode} Contract</span>
                          </td>
                          <td className="py-3 px-4 text-[11px] font-medium text-slate-400 leading-tight">
                            <div className="text-slate-200 font-bold">Buyer: <span className="font-mono text-[10px] text-indigo-300">{escrow.buyerPhone}</span></div>
                            <div className="text-slate-350">Seller: <span className="font-mono text-[10px] text-slate-400">{escrow.sellerPhone}</span></div>
                          </td>
                          <td className="py-3 px-4 font-bold text-white">Rs. {escrow.amount.toLocaleString()}</td>
                          <td className="py-3 px-4 font-sans text-[11px]">
                            {escrow.receipt_url ? (
                              <div className="flex items-center gap-2">
                                <div 
                                  onClick={() => setLightboxImageUrl(escrow.receipt_url || null)}
                                  className="w-10 h-10 rounded border border-indigo-500/20 overflow-hidden bg-slate-950 cursor-zoom-in hover:border-indigo-500/60 transition-colors shrink-0 shadow-sm"
                                  title="Click to view full receipt"
                                >
                                  <img src={escrow.receipt_url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                </div>
                                <div className="font-mono text-[9px] leading-tight text-slate-400">
                                  <div className="font-black text-indigo-300">TID: {escrow.paymentDetails?.tid || 'N/A'}</div>
                                  <div className="text-slate-200 truncate max-w-[120px] font-bold">Ref: {escrow.paymentDetails?.senderName || 'N/A'}</div>
                                  <div>Num: {escrow.paymentDetails?.senderAccount || 'N/A'}</div>
                                </div>
                              </div>
                            ) : (
                              <span className="text-slate-600 font-bold italic">No Receipt Uploaded</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex flex-col gap-1 items-center justify-center">
                              <span className={`inline-block px-2.5 py-1 rounded-xl text-[9px] font-black uppercase text-center ${
                                escrow.status === 'COMPLETED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                                escrow.status === 'FUNDED' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse' :
                                escrow.status === 'DISPUTED' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30 font-bold animate-bounce' :
                                escrow.status === 'CANCELLED' ? 'bg-slate-800 text-slate-400' : 'bg-amber-500/10 text-amber-500 border border-amber-500/25'
                              }`}>
                                {escrow.status}
                              </span>
                              {escrow.payment_status === 'paid_pending_verification' && (
                                <span className="bg-orange-500/15 text-orange-400 border border-orange-550/30 text-[8px] font-black uppercase px-2 py-0.5 rounded-full animate-pulse tracking-wider shrink-0 mt-0.5">
                                  ⚠️ PENDING AUDIT
                                </span>
                              )}
                              {escrow.payment_status === 'held' && (
                                <span className="bg-emerald-500/15 text-emerald-450 border border-emerald-550/20 text-[8px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider shrink-0 mt-0.5">
                                  🔒 SECURED VAULT
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex flex-col gap-1.5 items-stretch max-w-[170px] mx-auto">
                              
                              {/* New Direct verifying approve action */}
                              {escrow.payment_status === 'paid_pending_verification' && (
                                <button
                                  onClick={async () => {
                                    if (window.confirm(`Approve Rs. ${escrow.amount.toLocaleString()} Direct Transaction Receipt (TID: ${escrow.paymentDetails?.tid || 'N/A'})?\n\nThis locks the funds into the secure PK Escrow ledger and releases the contract state to FUNDED.`)) {
                                      setIsProcessing(true);
                                      try {
                                        const escrowRef = doc(db, 'escrows', escrow.id);
                                        await updateDoc(escrowRef, {
                                          status: 'FUNDED',
                                          payment_status: 'held',
                                          isPaymentSubmitted: true,
                                          updatedAt: serverTimestamp()
                                        });

                                        // Send notifications to buyer and seller
                                        await sendNotification(
                                          escrow.buyerId,
                                          'Payment APPROVED! 🛡️',
                                          `Your direct transfer receipt of Rs. ${escrow.amount.toLocaleString()} has been APPROVED by PK Escrow compliance! Funds are secure in holding.`,
                                          'SUCCESS',
                                          escrow.id
                                        ).catch(e => console.warn(e));

                                        await sendNotification(
                                          escrow.sellerId,
                                          'Direct Deposit Locked 🔒',
                                          `Compliance has verified the buyer's receipt and locked Rs. ${escrow.amount.toLocaleString()} in secure holding. Proceed to fulfill work!`,
                                          'SUCCESS',
                                          escrow.id
                                        ).catch(e => console.warn(e));

                                        // Add audit history to deal room chat
                                        const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
                                        await addDoc(msgsCollection, {
                                          text: `📢 COMPLIANCE AUDIT APPROVED!\n• Status: Paid and Locked (Vault Holds Rs. ${escrow.amount.toLocaleString()})\n• Verification Reference TID: ${escrow.paymentDetails?.tid || 'N/A'}\n• Message: Ledger confirms receipt clears statement reconciliation. Seller, proceed with active deliveries.`,
                                          senderId: 'SYSTEM_BOT',
                                          senderName: 'Compliance Auditor',
                                          createdAt: new Date().toISOString()
                                        });

                                        pushTelemetryLog(`[AUDIT_SUCCESS] Verified Direct payment for agreement #${escrow.id}. Ledger funded.`);
                                      } catch (err: any) {
                                        pushTelemetryLog(`[ERROR] Verification rejected: ${err.message}`);
                                      } finally { 
                                        setIsProcessing(false); 
                                      }
                                    }
                                  }}
                                  className="px-2 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] uppercase tracking-widest font-black rounded-lg cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1 shadow shadow-emerald-600/10"
                                >
                                  <ShieldCheck className="w-3.5 h-3.5" /> Approve & Hold Funds
                                </button>
                              )}

                              {escrow.payment_status === 'paid_pending_verification' && escrow.receipt_url && (
                                <button
                                  onClick={() => startAiAudit(
                                    escrow.id,
                                    'escrow',
                                    escrow.receipt_url || '',
                                    escrow.paymentDetails?.tid || '',
                                    escrow.amount,
                                    escrow
                                  )}
                                  className="px-2 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[9px] uppercase tracking-widest font-black rounded-lg cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1 shadow shadow-indigo-600/20"
                                >
                                  <Sparkles className="w-3.5 h-3.5 text-amber-300 fill-amber-300 animate-pulse" />
                                  <span>✨ AI Auto-Verify</span>
                                </button>
                              )}

                              {escrow.status !== 'COMPLETED' && escrow.status !== 'CANCELLED' && (
                                <button
                                  onClick={async () => {
                                    if (window.confirm("Admin Rule: Force Release of this escrow? This bypasses buyer verification and issues a Completed status for Seller Payout.")) {
                                      setIsProcessing(true);
                                      try {
                                        await updateDoc(doc(db, 'escrows', escrow.id), { status: 'COMPLETED', updatedAt: serverTimestamp() });
                                        pushTelemetryLog(`[FORCE_RELEASE] Escrow ID # ${escrow.id} set to COMPLETED.`);
                                      } catch (err: any) {
                                        pushTelemetryLog(`[ERROR] Force release rejected: ${err.message}`);
                                      } finally { setIsProcessing(false); }
                                    }
                                  }}
                                  className="px-2 py-1 bg-indigo-950 hover:bg-indigo-900 border border-indigo-400/20 text-indigo-300 text-[9px] font-bold rounded-lg cursor-pointer"
                                >
                                  Force Release
                                </button>
                              )}
                              
                              {escrow.status !== 'COMPLETED' && escrow.status !== 'CANCELLED' && (
                                <button
                                  onClick={async () => {
                                    if (window.confirm("Admin Rule: Force Cancel of this contract? This refunds simulated deposits back to Buyer.")) {
                                      setIsProcessing(true);
                                      try {
                                        await updateDoc(doc(db, 'escrows', escrow.id), { status: 'CANCELLED', updatedAt: serverTimestamp() });
                                        pushTelemetryLog(`[FORCE_CANCEL] Escrow ID # ${escrow.id} cancelled.`);
                                      } catch (err: any) {
                                        pushTelemetryLog(`[ERROR] Force cancel failed: ${err.message}`);
                                      } finally { setIsProcessing(false); }
                                    }
                                  }}
                                  className="px-2 py-1 bg-red-950/30 border border-red-500/20 hover:bg-red-900/30 text-rose-450 text-[9px] font-bold rounded-lg cursor-pointer"
                                >
                                  Cancel Contract
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* VIEW B: OUTBOUND PAYOUTS */}
            {activeAdminTab === 'payouts' && (
              <div className="space-y-4">
                <div className="bg-amber-500/5 rounded-2xl border border-amber-500/10 p-4 font-mono text-[11px] text-amber-300 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <div>
                    <strong>SOCIOLOGICAL TRANSACTION SETTLEMENT POLICY (DIRECT DISPATCH):</strong>
                    <p className="mt-1 font-sans">
                      Our platform does not use internal stored wallets/credits. When an escrow is completed, funds must be dispatched manually to the Seller's physical EasyPaisa, JazzCash, or bank account. Copy details from the list below, dispatch payment through your banking app, then enter the Outbound Transaction ID to settle the record.
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-950/60 text-slate-400 text-[10px] font-mono tracking-wider border-b border-indigo-500/10 uppercase">
                        <th className="py-3 px-4">Deal Reference</th>
                        <th className="py-3 px-4">Seller Identifier</th>
                        <th className="py-3 px-4">Owed Amount (-1% Fee)</th>
                        <th className="py-3 px-4">Preferred Payment account</th>
                        <th className="py-3 px-4 text-center">Dispatch State</th>
                        <th className="py-3 px-4 text-center">Execution</th>
                      </tr>
                    </thead>
                    <tbody className="text-xs divide-y divide-indigo-500/5">
                      {filteredPayouts.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-12 text-center text-slate-500 font-mono">
                            ◆ NO COMPLETED/PAID OUT ESCROW EVENTS RECORDED ◆
                          </td>
                        </tr>
                      ) : (
                        filteredPayouts.map((escrow) => {
                          const netPayout = Math.round(escrow.amount * 0.99);
                          const isPaid = escrow.payoutStatus === 'PAID';
                          
                          return (
                            <tr key={escrow.id} className="hover:bg-slate-900/35 transition-colors">
                              <td className="py-3 px-4">
                                <span className="font-bold text-slate-200 block">{escrow.itemDescription}</span>
                                <span className="text-[10px] text-indigo-400 font-mono">Deal ID: #{escrow.id.slice(0,8)}</span>
                              </td>
                              <td className="py-3 px-4">
                                <span className="font-bold block text-slate-300">Seller Phone:</span>
                                <span className="text-slate-400 font-mono">{escrow.sellerPhone}</span>
                              </td>
                              <td className="py-3 px-4">
                                <span className="font-black text-emerald-400 block">Rs. {netPayout.toLocaleString()}</span>
                                <span className="text-[10px] text-slate-500">Gross: Rs. {escrow.amount.toLocaleString()}</span>
                              </td>
                              <td className="py-3 px-4 font-mono text-slate-300 max-w-xs truncate">
                                {/* Retrieve matching user payout accounts if available online */}
                                {(() => {
                                  const matchingUser = users.find(u => u.id === escrow.sellerId);
                                  if (matchingUser?.ibanNumber) {
                                    return (
                                      <div>
                                        <span className="font-bold text-[10px] text-slate-400 uppercase block">{matchingUser.bankName || 'HBL'}</span>
                                        <span className="text-xs font-black select-all text-white block">{matchingUser.ibanNumber}</span>
                                        <span className="text-[9px] text-cyan-400 block">Title: {matchingUser.accountHolderName || 'N/A'}</span>
                                      </div>
                                    );
                                  }
                                  return (
                                    <div className="text-amber-500 font-bold text-[10px] leading-relaxed">
                                      ⚠️ PROFILE DISPATCH SETTINGS NOT SET<br/>
                                      <span className="text-slate-500">Contact via secure Chat or phone</span>
                                    </div>
                                  );
                                })()}
                              </td>
                              <td className="py-3 px-4 text-center">
                                {isPaid ? (
                                  <div className="space-y-0.5">
                                    <span className="inline-block px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl text-[9px] uppercase font-black">
                                      🟢 Dispatched
                                    </span>
                                    {escrow.payoutTxId && (
                                      <span className="block text-[8px] font-mono text-slate-500 truncate" title={escrow.payoutTxId}>TID: {escrow.payoutTxId}</span>
                                    )}
                                  </div>
                                ) : (
                                  <span className="inline-block px-2.5 py-1 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-xl text-[9px] uppercase font-black">
                                    ⏳ Owed/Pending
                                  </span>
                                )}
                              </td>
                              <td className="py-3 px-4 text-center">
                                {isPaid ? (
                                  <button
                                    onClick={async () => {
                                      if(window.confirm("Revert dispatch state to PENDING? Used for payout corrections only.")) {
                                        await updateDoc(doc(db, 'escrows', escrow.id), {
                                          payoutStatus: 'PENDING',
                                          payoutTxId: '',
                                          payoutProcessedAt: ''
                                        });
                                        pushTelemetryLog(`[REVERT_DISPATCH] Reset payout for deal ID: # ${escrow.id}`);
                                      }
                                    }}
                                    className="px-2.5 py-1 bg-slate-800 text-slate-400 hover:text-red-400 hover:bg-slate-900 border border-slate-700 hover:border-red-900 text-[10px] font-black rounded-lg cursor-pointer whitespace-nowrap"
                                  >
                                    Revert Dispatch
                                  </button>
                                ) : (
                                  <button
                                    id={`payout-dispatch-btn-${escrow.id}`}
                                    onClick={() => handleOpenPayoutModal(escrow)}
                                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black rounded-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1 mx-auto shadow-md shadow-indigo-600/15"
                                  >
                                    <Send className="w-3 h-3" /> dispatch
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* VIEW C: DISPUTES & ARBITRATION */}
            {activeAdminTab === 'disputes' && (
              <div className="space-y-4">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-950/60 text-slate-400 text-[10px] font-mono tracking-wider border-b border-indigo-500/10 uppercase">
                        <th className="py-3 px-4">Deal Info</th>
                        <th className="py-3 px-4">Buyer Entity</th>
                        <th className="py-3 px-4">Seller Entity</th>
                        <th className="py-3 px-4">Amount Ruled</th>
                        <th className="py-3 px-4 text-center">State</th>
                        <th className="py-3 px-4 text-center">Arbitrate Docket</th>
                      </tr>
                    </thead>
                    <tbody className="text-xs divide-y divide-indigo-500/5">
                      {filteredDisputes.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-12 text-center text-slate-500 font-mono">
                            ◆ ZERO ACTIVE TRANSACTION DISPUTES DETECTED ◆
                          </td>
                        </tr>
                      ) : (
                        filteredDisputes.map((escrow) => (
                          <tr key={escrow.id} className="hover:bg-slate-900/35 transition-colors">
                            <td className="py-3 px-4">
                              <span className="font-bold text-slate-200 block">{escrow.itemDescription}</span>
                              <span className="text-[10px] text-rose-400 font-mono">ID: #{escrow.id.slice(0, 8)}</span>
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-400">{escrow.buyerPhone}</td>
                            <td className="py-3 px-4 font-mono text-slate-400">{escrow.sellerPhone}</td>
                            <td className="py-3 px-4 font-black text-rose-400">Rs. {escrow.amount.toLocaleString()}</td>
                            <td className="py-3 px-4 text-center">
                              <span className="inline-block px-2.5 py-1 bg-rose-500/15 text-rose-400 border border-rose-500/25 rounded-xl text-[9px] uppercase font-black animate-pulse">
                                ⚖️ FRAUD ALERT
                              </span>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                id={`arbitrate-btn-${escrow.id}`}
                                onClick={() => {
                                  setSelectedEscrow(escrow);
                                  setDisputeNotes('');
                                  setIsDisputeModalOpen(true);
                                }}
                                className="px-3 py-1.5 bg-rose-950/30 border border-rose-500/30 text-rose-400 hover:bg-rose-900/35 hover:border-rose-500 text-[10px] font-black rounded-lg cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1.5 mx-auto"
                              >
                                <Scale className="w-3.5 h-3.5" /> Ruled ruling
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* VIEW D: USERS DIRECTORY */}
            {activeAdminTab === 'users' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/60 text-slate-400 text-[10px] font-mono tracking-wider border-b border-indigo-500/10 uppercase">
                      <th className="py-3 px-4">Member Info</th>
                      <th className="py-3 px-4">Phone Number</th>
                      <th className="py-3 px-4">CNIC Account Verification</th>
                      <th className="py-3 px-4">Verification Rank</th>
                      <th className="py-3 px-4 text-center">Operational Status</th>
                      <th className="py-3 px-4 text-center">Administration Rank Upgrades</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-indigo-500/5">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-500 font-mono">
                          ◆ NO PLATFORM USERS MATCHED YOUR CRITERIA ◆
                        </td>
                      </tr>
                    ) : (
                      filteredUsers.map((userProf) => (
                        <tr key={userProf.id} className="hover:bg-slate-900/35 transition-colors">
                          <td className="py-3 px-4">
                            <span className="font-bold text-slate-100 block">{userProf.displayName || 'Offline User'}</span>
                            <span className="text-[10px] text-slate-500 font-mono block">{userProf.email || 'No email shared'}</span>
                          </td>
                          <td className="py-3 px-4 font-mono text-slate-300">{userProf.phoneNumber}</td>
                          <td className="py-3 px-4 font-mono text-slate-400">
                            {userProf.cnicNumber ? (
                              <div className="space-y-0.5">
                                <span className="font-bold block text-slate-300">CNIC ID: {userProf.cnicNumber}</span>
                                {userProf.cnicFrontImage && (
                                  <span className="text-[9px] text-emerald-400 bg-emerald-500/5 px-1 rounded block w-max">Has Upload Document</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-500 italic block">None registered</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span className={`inline-block px-2.5 py-1 rounded-xl text-[9px] font-black uppercase tracking-wider ${
                              userProf.verificationLevel === 3 ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 
                              userProf.verificationLevel === 2 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                              'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                            }`}>
                              Level {userProf.verificationLevel || 1}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                              userProf.isDeleted || userProf.onboardingStatus === 'DELETED' 
                                ? 'bg-red-950 text-red-400 border border-red-900/20' 
                                : 'bg-emerald-950 text-emerald-400 border border-emerald-900/20'
                            }`}>
                              {userProf.isDeleted || userProf.onboardingStatus === 'DELETED' ? 'ISOLATED/BANNED' : 'ONLINE/ACTIVE'}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => handleUpgradeUserRank(userProf, 2)}
                                disabled={userProf.verificationLevel === 2}
                                className="px-2 py-1 bg-emerald-950/40 hover:bg-emerald-900/55 text-emerald-400 text-[10px] font-bold rounded-lg border border-emerald-900/40 cursor-pointer disabled:opacity-40"
                              >
                                Level 2
                              </button>
                              <button
                                onClick={() => handleUpgradeUserRank(userProf, 3)}
                                disabled={userProf.verificationLevel === 3}
                                className="px-2 py-1 bg-indigo-950/40 hover:bg-indigo-900/55 text-indigo-400 text-[10px] font-bold rounded-lg border border-indigo-900/40 cursor-pointer disabled:opacity-40"
                              >
                                Level 3
                              </button>
                              <button
                                onClick={() => handleToggleMemberBan(userProf)}
                                className={`px-2 py-1 text-[10px] font-bold rounded-lg cursor-pointer border ${
                                  userProf.isDeleted || userProf.onboardingStatus === 'DELETED'
                                    ? 'bg-emerald-900/20 border-emerald-500/30 text-emerald-400 hover:bg-emerald-800/30'
                                    : 'bg-red-950/20 border-red-500/30 text-red-400 hover:bg-red-800/30'
                                }`}
                              >
                                {userProf.isDeleted || userProf.onboardingStatus === 'DELETED' ? 'Reinstate' : 'Ban'}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* VIEW E: INBOUND MANUAL PAYMENTS RECEIPTS */}
            {activeAdminTab === 'deposits' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/60 text-slate-400 text-[10px] font-mono tracking-wider border-b border-indigo-500/10 uppercase">
                      <th className="py-3 px-4">Receipt Proof ID</th>
                      <th className="py-3 px-4">Sender Profile</th>
                      <th className="py-3 px-4">Amount Secured</th>
                      <th className="py-3 px-4">Transaction ID (TID)</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center font-mono">Approve/Reject Code</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-indigo-500/5">
                    {filteredDeposits.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-500 font-mono">
                          ◆ ZERO COMPLETED INBOUND WALLET SCRIPTS DETECTED ◆
                        </td>
                      </tr>
                    ) : (
                      filteredDeposits.map((dep) => (
                        <tr key={dep.id} className="hover:bg-slate-900/35 transition-colors">
                          <td className="py-3 px-4">
                            <span className="font-mono text-slate-300 block">{dep.id.slice(0, 8)}...</span>
                            {dep.receiptImage && (
                              <button 
                                onClick={() => setSelectedDeposit(dep)}
                                className="text-[10px] text-cyan-400 underline font-semibold flex items-center gap-1 mt-1 cursor-pointer"
                              >
                                <Eye className="w-3 h-3" /> Inspect Screenshot Image
                              </button>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <strong className="block text-slate-200">{dep.senderName}</strong>
                            <span className="text-slate-500 font-mono block">{dep.senderAccount}</span>
                          </td>
                          <td className="py-3 px-4 font-black text-emerald-400">Rs. {dep.amount.toLocaleString()}</td>
                          <td className="py-3 px-4 font-mono text-indigo-400 select-all font-bold">{dep.transactionId}</td>
                          <td className="py-3 px-4 text-center">
                            <span className={`inline-block px-2.5 py-1 rounded-xl text-[9px] font-black uppercase tracking-wider ${
                              dep.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                              dep.status === 'REJECTED' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                              'bg-amber-500/10 text-amber-500 border border-amber-500/20 animate-pulse'
                            }`}>
                              {dep.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            {dep.status === 'PENDING' ? (
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  onClick={() => handleApproveDeposit(dep, true)}
                                  className="px-2 py-1 bg-emerald-600 text-slate-950 font-black hover:bg-emerald-500 text-[10px] rounded-lg transition-all cursor-pointer active:scale-95"
                                >
                                  APPROVE
                                </button>
                                <button
                                  onClick={() => handleApproveDeposit(dep, false)}
                                  className="px-2 py-1 bg-rose-950/20 border border-rose-500/30 text-rose-400 font-bold hover:bg-rose-900 text-[10px] rounded-lg transition-all cursor-pointer active:scale-95"
                                >
                                  REJECT
                                </button>
                                {dep.receiptImage && (
                                  <button
                                    onClick={() => startAiAudit(
                                      dep.id,
                                      'deposit',
                                      dep.receiptImage || '',
                                      dep.transactionId || '',
                                      dep.amount,
                                      dep
                                    )}
                                    className="px-2 py-1 bg-indigo-600 text-white font-black hover:bg-indigo-500 text-[10px] rounded-lg transition-all cursor-pointer active:scale-95 flex items-center gap-1"
                                  >
                                    <Sparkles className="w-3 h-3 text-amber-300 fill-amber-300 animate-pulse" />
                                    <span>AI Verify</span>
                                  </button>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-500 italic block">Audited & Verified</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {activeAdminTab === 'system' && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#0b101f] border border-indigo-500/10 p-6 sm:p-8 rounded-3xl space-y-6"
              >
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2 mb-1">
                    💼 Setup Central Holding Accounts (مرکزی پیمنٹ اکاؤنٹس)
                  </h3>
                  <p className="text-slate-400 text-[11px] leading-relaxed font-semibold">
                    Set up the official system credentials. Buyers will be directed to send their hold deposits (escrow amounts) directly to these coordinates before the seller delivers.
                  </p>
                </div>

                <form onSubmit={handleSaveSystemDetails} className="space-y-4 text-xs font-semibold text-slate-350">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5 text-left">
                      <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">Account Holder Title (اکاؤنٹ ٹائٹل)</label>
                      <input 
                        type="text"
                        value={adminHolderName}
                        onChange={(e) => setAdminHolderName(e.target.value)}
                        placeholder="e.g. PK ESCROW SYSTEMS / ADMINISTRATOR"
                        className="w-full bg-[#070b13] border border-indigo-500/15 focus:border-indigo-500/40 outline-none rounded-xl px-4 py-3 text-white font-black"
                        required
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">Raast / Direct Bank Name (بینک کا نام)</label>
                      <input 
                        type="text"
                        value={adminBankName}
                        onChange={(e) => setAdminBankName(e.target.value)}
                        placeholder="e.g. Bank Alfalah / HBL Bank"
                        className="w-full bg-[#070b13] border border-indigo-500/15 focus:border-indigo-500/40 outline-none rounded-xl px-4 py-3 text-white font-black"
                        required
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">Raast IBAN / Account Number (اکاؤنٹ نمبر)</label>
                      <input 
                        type="text"
                        value={adminIbanNum}
                        onChange={(e) => setAdminIbanNum(e.target.value)}
                        placeholder="e.g. PK72ALFH000109284758"
                        className="w-full bg-[#070b13] border border-indigo-500/15 focus:border-indigo-500/40 outline-none rounded-xl px-4 py-3 text-white font-mono font-bold"
                        required
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">Official EasyPaisa Number</label>
                      <input 
                        type="tel"
                        value={adminEasypaisaNum}
                        onChange={(e) => setAdminEasypaisaNum(e.target.value)}
                        placeholder="e.g. 03001234567"
                        className="w-full bg-[#070b13] border border-indigo-500/15 focus:border-indigo-500/40 outline-none rounded-xl px-4 py-3 text-white font-mono font-bold"
                      />
                    </div>

                    <div className="space-y-1.5 md:col-span-2 text-left">
                      <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider">Official JazzCash Number</label>
                      <input 
                        type="tel"
                        value={adminJazzcashNum}
                        onChange={(e) => setAdminJazzcashNum(e.target.value)}
                        placeholder="e.g. 03121234567"
                        className="w-full bg-[#070b13] border border-indigo-500/15 focus:border-indigo-500/40 outline-none rounded-xl px-4 py-3 text-white font-mono font-bold"
                      />
                    </div>
                  </div>

                  <div className="pt-2 text-left">
                    <button
                      type="submit"
                      disabled={isSavingSystemDetails}
                      className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-black py-4 rounded-xl transition-all uppercase tracking-widest cursor-pointer shadow-lg shadow-indigo-600/10 text-center text-xs animate-pulse"
                    >
                      {isSavingSystemDetails ? 'Saving Central Coordinates...' : '🔒 SAVE OFFICIAL ACCOUNTS (سیو کریں)'}
                    </button>
                  </div>
                </form>
              </motion.div>
            )}

          </div>
        </section>

        {/* BOTTOM REAL-TIME TELEMETRY LOG SHELL ACCENTS */}
        <section className="bg-black/90 border border-indigo-500/15 rounded-2xl overflow-hidden shadow-xl">
          <div className="bg-slate-950/80 border-b border-indigo-500/15 p-4 flex items-center justify-between">
            <h3 className="text-xs uppercase font-bold tracking-widest text-indigo-400 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-400" /> Administrative Telemetry Diagnostics Console
            </h3>
            <button
              onClick={() => setTelemetryLogs(['[SYSTEM] Logger reset. Ready for connections.'])}
              className="text-[10px] uppercase font-bold text-slate-500 hover:text-indigo-400"
            >
              Flush Diagnostic Console
            </button>
          </div>
          <div className="p-4.5 h-44 overflow-y-auto font-mono text-[11px] text-emerald-400/90 space-y-1 bg-black/50 flex flex-col-reverse">
            {telemetryLogs.map((log, i) => {
              let cl = 'text-emerald-400/80';
              if (log.includes('[ERROR]') || log.includes('[CRITICAL]')) cl = 'text-rose-400 font-bold';
              else if (log.includes('[SUCCESS]')) cl = 'text-emerald-300 font-bold';
              else if (log.includes('[DECISION]') || log.includes('[FORCE_')) cl = 'text-cyan-300 font-black';
              else if (log.includes('[WARNING]')) cl = 'text-amber-400 font-bold';
              return <div key={i} className={cl}>{log}</div>;
            })}
            {telemetryLogs.length === 0 && (
              <div className="text-slate-600">[Telemetry buffer initialized. Waiting for admin mutations...]</div>
            )}
          </div>
        </section>

      </main>

      {/* MODAL 1: OUTBOUND PAYOUT SETTLEMENT DETAILS */}
      <AnimatePresence>
        {isPayoutModalOpen && payoutTargetEscrow && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { if(!isProcessing) setIsPayoutModalOpen(false); }}
              className="absolute inset-0 bg-black/85 backdrop-blur-xs"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0e162a] border border-indigo-400/30 rounded-3xl max-w-lg w-full overflow-hidden relative z-1 z-50 shadow-2xl p-6 space-y-5"
            >
              <div className="flex justify-between items-center border-b border-indigo-500/10 pb-3">
                <div className="flex items-center gap-2">
                  <Banknote className="w-5 h-5 text-indigo-400" />
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">Outbound Direct Payout Settle Form</h3>
                </div>
                <button
                  onClick={() => setIsPayoutModalOpen(false)}
                  className="text-slate-500 hover:text-white font-bold"
                  disabled={isProcessing}
                >
                  ✕
                </button>
              </div>

              <div className="bg-indigo-950/20 p-4 rounded-2xl border border-indigo-500/10 space-y-2.5 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">Deal:</span>
                  <span className="font-bold text-slate-200 truncate max-w-[280px]">{payoutTargetEscrow.itemDescription}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Original Amount:</span>
                  <span className="font-bold">Rs. {payoutTargetEscrow.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-large font-black border-t border-indigo-500/10 pt-2">
                  <span>DISPATCH Owed (after 1% commission):</span>
                  <span>Rs. {Math.round(payoutTargetEscrow.amount * 0.99).toLocaleString()}</span>
                </div>
              </div>

              {/* SELLER DISPATCH ADDRESS INFO */}
              <div className="bg-[#0b101f] rounded-2xl p-4.5 border border-indigo-500/5 space-y-3">
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block">Seller Target Payment account</span>
                
                {payoutTargetSeller ? (
                  <div className="grid grid-cols-2 gap-3.5 text-xs">
                    <div>
                      <span className="block text-[10px] text-slate-500 font-bold uppercase">Account Holder Title</span>
                      <span className="font-black text-slate-200 block mt-0.5 select-all">{payoutTargetSeller.accountHolderName || payoutTargetSeller.displayName || 'N/A'}</span>
                    </div>

                    <div>
                      <span className="block text-[10px] text-slate-500 font-bold uppercase">Bank / Wallet Name</span>
                      <span className="font-black text-slate-200 block mt-0.5">{payoutTargetSeller.bankName || 'Not configured'}</span>
                    </div>

                    <div className="col-span-2 bg-slate-950 p-2.5 rounded-xl border border-indigo-500/10">
                      <span className="block text-[9px] text-indigo-400 font-black uppercase">IBAN / Account Link Number</span>
                      <span className="font-black text-rose-300 font-mono text-sm block mt-1 select-all">{payoutTargetSeller.ibanNumber || 'N/A'}</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">Reading directory profile... Ensure seller completed profile.</p>
                )}
              </div>

              <form onSubmit={handleConfirmPayoutDispatch} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider mb-1 px-1">
                    Enter outbound Dispatch TID / Transaction reference
                  </label>
                  <input
                    id="payout-tid-input"
                    type="text"
                    required
                    value={payoutTxId}
                    onChange={(e) => setPayoutTxId(e.target.value)}
                    placeholder="e.g. 50928271032 Meezan / SADA ID"
                    className="w-full bg-slate-950 border border-indigo-500/20 focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white uppercase font-mono"
                  />
                  <p className="text-[9px] text-slate-500 mt-1 px-1">
                    Execute the transfer in your EasyPaisa, HBL, or JazzCash app first, then copy the Transaction ID reference here to close payout.
                  </p>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-indigo-400 uppercase tracking-wider mb-1 px-1">
                    Dispatched Notes (Optional)
                  </label>
                  <input
                    id="payout-notes-input"
                    type="text"
                    value={payoutNotes}
                    onChange={(e) => setPayoutNotes(e.target.value)}
                    placeholder="Fast settled by arbitration council."
                    className="w-full bg-slate-950 border border-indigo-500/20 focus:outline-none focus:border-indigo-400 rounded-xl px-3.5 py-2.5 text-xs font-medium text-slate-200"
                  />
                </div>

                <div className="flex gap-2.5 pt-2 border-t border-indigo-500/10">
                  <button
                    type="button"
                    onClick={() => setIsPayoutModalOpen(false)}
                    className="flex-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-400 text-xs font-black py-3 rounded-2xl cursor-pointer"
                    disabled={isProcessing}
                  >
                    Cancel
                  </button>
                  <button
                    id="payout-confirm-submit"
                    type="submit"
                    className="flex-1 bg-[#10b981] hover:bg-[#05a371] text-slate-950 text-xs font-black py-3 rounded-2xl cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1"
                    disabled={isProcessing || !payoutTxId.trim()}
                  >
                    {isProcessing ? <Loader2 className="w-4 h-4 animate-spin text-slate-950" /> : 'Confirm Dispatched'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: DISPUTE ARBITRATION CASE VERDICT */}
      <AnimatePresence>
        {isDisputeModalOpen && selectedEscrow && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { if(!isProcessing) setIsDisputeModalOpen(false); }}
              className="absolute inset-0 bg-black/85 backdrop-blur-xs"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0e162a] border border-red-500/30 rounded-3xl max-w-lg w-full overflow-hidden relative z-50 shadow-2xl p-6 space-y-5"
            >
              <div className="flex justify-between items-center border-b border-red-500/10 pb-3">
                <div className="flex items-center gap-2">
                  <Scale className="w-5 h-5 text-rose-400" />
                  <h3 className="text-sm font-black text-rose-400 uppercase tracking-wider">Arbitration Verdict Docket Panel</h3>
                </div>
                <button
                  onClick={() => setIsDisputeModalOpen(false)}
                  className="text-slate-500 hover:text-white font-bold"
                  disabled={isProcessing}
                >
                  ✕
                </button>
              </div>

              <div className="bg-red-950/10 p-4 rounded-2xl border border-red-500/10 space-y-2 text-xs text-slate-300">
                <p className="font-bold text-slate-100 uppercase text-[10px] tracking-wider text-rose-400">FRAUD ALERT DETAILS</p>
                <div>
                  <span className="text-slate-500 block">Deal:</span>
                  <span className="font-bold text-slate-200">{selectedEscrow.itemDescription}</span>
                </div>
                <div className="flex justify-between text-sm py-1 font-bold">
                  <span>Holdings sum:</span>
                  <span className="text-rose-400 font-black">Rs. {selectedEscrow.amount.toLocaleString()}</span>
                </div>
              </div>

              {/* ARBITRATION INPUT FOR STATEMENT */}
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1 px-1">
                    Arbitration Ruling Notes & Core Verdict Reasons
                  </label>
                  <textarea
                    id="dispute-judgment-notes"
                    value={disputeNotes}
                    onChange={(e) => setDisputeNotes(e.target.value)}
                    placeholder="Enter ruling notes. This ledger report note is made transparently public and accessible to both Buyer and Seller on their Completed/Cancelled card displays."
                    className="w-full bg-slate-950 border border-slate-800 text-xs rounded-xl px-3.5 py-2.5 h-20 text-slate-200 focus:outline-none focus:border-indigo-400 font-sans"
                  />
                </div>

                <div className="bg-[#0b101f] rounded-xl p-3 text-[10px] text-slate-400 font-medium">
                  ⚖️ <strong>Arbitration Ruling Rule:</strong> Once verified, selecting the transfer releases payouts to the seller (direct payout queue). Selecting the refund cancels the deal and issues credit logs to refund the buyer.
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-slate-900">
                  <button
                    id="rule-to-seller-btn"
                    onClick={() => handleArbitrateDispute(selectedEscrow, 'RELEASE_TO_SELLER')}
                    className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-[11px] font-black py-3 rounded-2xl cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1"
                    disabled={isProcessing}
                  >
                    Settle: Release to Seller
                  </button>
                  <button
                    id="rule-to-buyer-btn"
                    onClick={() => handleArbitrateDispute(selectedEscrow, 'REFUND_TO_BUYER')}
                    className="bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-black py-3 rounded-2xl cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-1"
                    disabled={isProcessing}
                  >
                    Settle: Refund Buyer
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 3: INBOUND MANUAL RECEIPT VIEW DETAILS */}
      <AnimatePresence>
        {selectedDeposit && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedDeposit(null)}
              className="absolute inset-0 bg-black/90 backdrop-blur-xs"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0e162a] border border-indigo-500/25 rounded-3xl max-w-sm w-full overflow-hidden relative z-50 shadow-2xl p-5 space-y-4"
            >
              <div className="flex justify-between items-center border-b border-indigo-500/10 pb-2">
                <h3 className="text-xs font-black text-white uppercase tracking-wider">Inspect Payment Screenshot Proof</h3>
                <button
                  onClick={() => setSelectedDeposit(null)}
                  className="text-slate-500 hover:text-white text-xs"
                >
                  ✕
                </button>
              </div>

              {selectedDeposit.receiptImage ? (
                <div className="flex items-center justify-center bg-slate-950 p-3 rounded-2xl border border-indigo-500/10">
                  <img 
                    src={selectedDeposit.receiptImage} 
                    alt="Receipt Screen proof upload" 
                    className="max-h-80 max-w-full rounded-lg object-contain selection:bg-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : (
                <p className="text-xs text-slate-550 italic text-center py-6">Image screenshot load failure.</p>
              )}

              <div className="text-xs space-y-1 bg-slate-950/40 p-3 rounded-xl border border-indigo-500/5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Sender:</span>
                  <span className="font-bold text-slate-200">{selectedDeposit.senderName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Claimed Amount:</span>
                  <span className="font-bold text-emerald-400 font-mono text-sm">Rs. {selectedDeposit.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Transaction TID:</span>
                  <span className="font-bold text-indigo-400 font-mono select-all font-black">{selectedDeposit.transactionId}</span>
                </div>
              </div>

              <div className="flex gap-2.5">
                <button
                  onClick={() => {
                    handleApproveDeposit(selectedDeposit, true);
                    setSelectedDeposit(null);
                  }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black py-2.5 rounded-xl cursor-pointer"
                >
                  APPROVE RECEIPT
                </button>
                <button
                  onClick={() => {
                    handleApproveDeposit(selectedDeposit, false);
                    setSelectedDeposit(null);
                  }}
                  className="flex-1 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black py-2.5 rounded-xl cursor-pointer"
                >
                  REJECT RECEIPT
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI-POWERED RECEIPT AUTO-VERIFICATION PORTAL */}
      <AnimatePresence>
        {aiAuditTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-950/90 backdrop-blur-md"
              onClick={() => { if (!isAiAuditing) { setAiAuditTarget(null); setAiReport(null); } }}
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-[#0b0e1a] border border-indigo-500/25 rounded-3xl max-w-xl w-full overflow-hidden relative z-50 shadow-2xl flex flex-col max-h-[92vh]"
            >
              <div className="flex justify-between items-center bg-slate-950 px-6 py-4 border-b border-indigo-500/10 font-sans">
                <span className="text-xs font-black text-indigo-300 uppercase tracking-widest flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                  🧠 PK Escrow Smart AI Compliance Auditor
                </span>
                <button
                  type="button"
                  id="close-ai-audit"
                  onClick={() => { if (!isAiAuditing) { setAiAuditTarget(null); setAiReport(null); } }}
                  disabled={isAiAuditing}
                  className="bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-400 hover:text-white rounded-full p-1.5 text-xs transition-colors cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="flex-1 p-6 overflow-y-auto space-y-6">
                {/* 1. Loading State */}
                {isAiAuditing && (
                  <div className="py-12 flex flex-col items-center justify-center text-center space-y-6">
                    <div className="relative w-16 h-16 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full border-t-2 border-b-2 border-indigo-500 animate-spin" />
                      <Sparkles className="w-6 h-6 text-indigo-400 animate-bounce" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-sm font-black text-white uppercase tracking-wider">Analyzing Payment Proof...</h3>
                      <p className="text-xs text-slate-400 max-w-md font-mono leading-relaxed px-4">
                        Scanning JazzCash/Easypaisa screenshot statement hashes, reconstructing receipts OCR, and running compliance reconciliation algorithms...
                      </p>
                    </div>
                  </div>
                )}

                {/* 2. Error State */}
                {aiAuditError && (
                  <div className="py-8 text-center space-y-4">
                    <div className="w-12 h-12 bg-rose-500/10 border border-rose-500/30 text-rose-450 rounded-full flex items-center justify-center mx-auto text-xl">
                      ⚠
                    </div>
                    <div>
                      <h4 className="text-sm font-extrabold text-white">AI OCR Extraction Failed</h4>
                      <p className="text-xs text-slate-400 mt-1 px-4 max-w-sm mx-auto">{aiAuditError}</p>
                    </div>
                    <button
                      onClick={() => startAiAudit(
                        aiAuditTarget.id,
                        aiAuditTarget.type,
                        aiAuditTarget.receiptUrl,
                        aiAuditTarget.expectedTid,
                        aiAuditTarget.expectedAmount,
                        aiAuditTarget.originalDoc
                      )}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer font-sans"
                    >
                      Retry Smart Audit
                    </button>
                  </div>
                )}

                {/* 3. Success Report Panel */}
                {aiReport && (
                  <div className="space-y-6">
                    {/* Verdict Banner */}
                    <div className={`p-4 rounded-2xl border text-center font-bold tracking-wider space-y-1 ${
                      aiReport.verdict === 'MATCH' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' :
                      aiReport.verdict === 'PARTIAL_MATCH' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' :
                      'bg-rose-500/10 border-rose-500/30 text-rose-400'
                    }`}>
                      <div className="text-xs uppercase font-black font-mono">
                        {aiReport.verdict === 'MATCH' && '✓ AUDIT_PASSED: LEDGER TRANSACTION CONFIRMED'}
                        {aiReport.verdict === 'PARTIAL_MATCH' && '⚠ AUDIT_WARNING: MINOR DISCREPANCY REPORTED'}
                        {aiReport.verdict === 'MISMATCH' && '✗ AUDIT_FAILED: TRANSACTION LEDGER MISMATCH'}
                      </div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        Confidence Factor: <span className="font-bold underline uppercase">{aiReport.confidence}</span>
                      </div>
                    </div>

                    {/* Image Preview & side details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Image Frame */}
                      <div className="bg-slate-950 p-2 rounded-2xl border border-indigo-500/10 flex items-center justify-center h-44 overflow-hidden relative">
                        <img 
                          src={aiAuditTarget.receiptUrl} 
                          alt="Receipt Audit Target" 
                          className="max-h-full max-w-full object-contain rounded-lg"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Extracted Details Table */}
                      <div className="bg-slate-950/60 p-4 rounded-2xl border border-indigo-500/5 space-y-3 flex flex-col justify-center">
                        <h4 className="text-[10px] font-black tracking-widest text-slate-400 uppercase font-mono border-b border-indigo-500/5 pb-1">AI Extracted Statement</h4>
                        
                        <div className="space-y-2 text-xs">
                          <div className="flex justify-between items-center">
                            <span className="text-slate-500">TID Detected:</span>
                            <span className={`font-mono font-bold ${aiReport.matchesTid ? 'text-emerald-400' : 'text-rose-450'}`}>
                              {aiReport.detectedTid || 'N/A'}
                            </span>
                          </div>
                          
                          <div className="flex justify-between items-center">
                            <span className="text-slate-500">Amount Extracted:</span>
                            <span className={`font-mono font-black ${aiReport.matchesAmount ? 'text-emerald-400' : 'text-rose-450'}`}>
                              Rs. {aiReport.detectedAmount?.toLocaleString() || 0}
                            </span>
                          </div>

                          <div className="flex justify-between items-center text-[11px]">
                            <span className="text-slate-500">Receipt Stamp:</span>
                            <span className="text-slate-300 font-mono text-right max-w-[120px] truncate leading-none">
                              {aiReport.transactionDate || 'N/A'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Side-by-Side Match Status Cards */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                        aiReport.matchesTid ? 'bg-emerald-500/5 border-emerald-500/10' : 'bg-rose-500/5 border-rose-500/10'
                      }`}>
                        <div className="text-[10px] text-slate-500 uppercase font-bold font-mono">TID Verification</div>
                        <div className="mt-1 font-mono text-xs font-bold text-white truncate max-w-full" title={aiAuditTarget.expectedTid}>
                          Expected: {aiAuditTarget.expectedTid || 'N/A'}
                        </div>
                        <div className="mt-2.5 flex items-center gap-1">
                          <span className={`w-2 h-2 rounded-full ${aiReport.matchesTid ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          <span className="text-[10px] font-black uppercase text-slate-400">
                            {aiReport.matchesTid ? 'TID MATCH' : 'TID MISMATCH'}
                          </span>
                        </div>
                      </div>

                      <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                        aiReport.matchesAmount ? 'bg-emerald-500/5 border-emerald-500/10' : 'bg-rose-500/5 border-rose-500/10'
                      }`}>
                        <div className="text-[10px] text-slate-500 uppercase font-bold font-mono">Amount Verification</div>
                        <div className="mt-1 font-mono text-xs font-bold text-white">
                          Expected: Rs. {aiAuditTarget.expectedAmount?.toLocaleString() || 0}
                        </div>
                        <div className="mt-2.5 flex items-center gap-1">
                          <span className={`w-2 h-2 rounded-full ${aiReport.matchesAmount ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          <span className="text-[10px] font-black uppercase text-slate-400">
                            {aiReport.matchesAmount ? 'AMOUNT MATCH' : 'AMOUNT MISMATCH'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Comprehensive Report */}
                    <div className="bg-slate-950/90 rounded-2xl border border-indigo-500/10 overflow-hidden">
                      <div className="bg-indigo-950/20 px-4 py-2 text-[10px] text-indigo-300 font-black uppercase tracking-widest border-b border-indigo-500/5 font-mono">
                        📋 PK Fast-Scan Compliance Narrative Analysis
                      </div>
                      <div className="p-4 text-xs leading-relaxed text-slate-350 font-medium whitespace-pre-wrap font-mono">
                        {aiReport.analysis}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Footer */}
              {!isAiAuditing && aiAuditTarget && (
                <div className="bg-slate-950 px-6 py-4 border-t border-indigo-500/10 flex gap-2 font-sans">
                  <button
                    type="button"
                    onClick={() => { setAiAuditTarget(null); setAiReport(null); }}
                    className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-white/5 text-slate-400 hover:text-white text-xs font-bold rounded-xl transition-all cursor-pointer active:scale-95"
                  >
                    Bypass & Close
                  </button>

                  {aiReport && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          if (aiAuditTarget.type === 'escrow') {
                            approveEscrowFromAi(aiAuditTarget.originalDoc);
                          } else {
                            approveDepositFromAi(aiAuditTarget.originalDoc);
                          }
                        }}
                        className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black rounded-xl transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-1"
                      >
                        <ShieldCheck className="w-4 h-4 shrink-0" />
                        <span>APPROVE VIA AI</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (aiAuditTarget.type === 'escrow') {
                            rejectEscrowFromAi(aiAuditTarget.originalDoc);
                          } else {
                            rejectDepositFromAi(aiAuditTarget.originalDoc);
                          }
                        }}
                        className="px-4 py-2.5 bg-rose-950 text-rose-450 border border-rose-500/30 hover:bg-rose-900 text-xs font-bold rounded-xl transition-all cursor-pointer active:scale-95 text-center"
                      >
                        FLAG REJECT
                      </button>
                    </>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FULLSCREEN RECEIPT PROOF AUDIT LIGHTBOX */}
      <AnimatePresence>
        {lightboxImageUrl && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/95 backdrop-blur-md"
              onClick={() => setLightboxImageUrl(null)}
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0e162a] border border-indigo-500/25 rounded-3xl max-w-2xl w-full overflow-hidden relative z-50 shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex justify-between items-center bg-slate-950/80 px-6 py-4 border-b border-indigo-500/10">
                <span className="text-xs font-black text-indigo-300 uppercase tracking-widest flex items-center gap-1.5">
                  🔍 DIRECT PAYMENT PROOF AUDIT
                </span>
                <button
                  onClick={() => setLightboxImageUrl(null)}
                  className="bg-slate-800 hover:bg-slate-700 text-white rounded-full p-1.5 text-[10px] font-bold transition-all width-6 height-6 flex items-center justify-center cursor-pointer"
                >
                  ✕
                </button>
              </div>
              <div className="flex-1 p-6 overflow-auto flex items-center justify-center bg-black/40">
                <img 
                  src={lightboxImageUrl} 
                  alt="Full verification proof" 
                  className="max-h-[60vh] max-w-full rounded-xl border border-white/5 shadow-2xl object-contain selection:bg-none"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="bg-slate-950/85 px-6 py-4 border-t border-indigo-500/10 text-center text-xs text-slate-400 font-bold leading-relaxed">
                Review this buyer transaction receipt against your associated JazzCash or bank statement balance locks.<br />
                <span className="text-amber-400 text-[10px] mt-1 block">💡 Close this zoom overlay using ✖ or click anywhere outside the popup card</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

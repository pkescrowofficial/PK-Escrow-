import React, { useState, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { User, Mail, CreditCard, Calendar, CheckSquare, ArrowRight, Camera, Image as ImageIcon, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { TermsModal } from '../components/TermsModal';
import { watermarkImage } from '../lib/watermark';

export function RegistrationView() {
  const { user, profile } = useAuth();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [cnic, setCnic] = useState('');
  const [issueDate, setIssueDate] = useState('');
  const [cnicFront, setCnicFront] = useState<string | null>(null);
  const [cnicBack, setCnicBack] = useState<string | null>(null);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const frontInputRef = useRef<HTMLInputElement>(null);
  const backInputRef = useRef<HTMLInputElement>(null);

  const handleOcr = async (base64Image: string) => {
    setIsScanning(true);
    setError(null);
    try {
      const resp = await fetch('/api/ocr-cnic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Image }),
      });
      const data = await resp.json();
      
      if (data.fullName) setFullName(data.fullName);
      if (data.cnicNumber) setCnic(data.cnicNumber);
      if (data.issueDate) {
        // Try to normalize date format for input[type="date"]
        let d = data.issueDate;
        if (d.includes('.')) {
          const p = d.split('.');
          if (p.length === 3) d = `${p[2]}-${p[1]}-${p[0]}`;
        }
        setIssueDate(d);
      }
      
      if (!data.fullName && !data.cnicNumber) {
        setError("Could not extract info. Please enter manually or try a clearer photo.");
      }
    } catch (err) {
      console.error("OCR Error:", err);
      setError("Failed to scan CNIC. Please enter details manually.");
    } finally {
      setIsScanning(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !agreed) return;
    
    if (!cnicFront || !cnicBack) {
      alert("Please upload both Front and Back pictures of your CNIC to proceed.");
      return;
    }

    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName: fullName,
        email: email || null,
        cnicNumber: cnic,
        cnicDateOfIssue: issueDate,
        cnicFrontImage: cnicFront,
        cnicBackImage: cnicBack,
        onboardingStatus: 'REGISTERED',
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden"
      >
        <div className="bg-emerald-600 p-8 text-white">
          <div className="flex items-center gap-2 mb-6">
            <User className="w-6 h-6 text-emerald-200" />
            <span className="font-black tracking-tighter text-sm uppercase">PK Escrow</span>
          </div>
          <h2 className="text-3xl font-black tracking-tight">Account Registration</h2>
          <p className="text-emerald-100 mt-2 font-medium">Step 1 of 3: Personal Details</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-600 text-xs font-bold">
              {error}
            </div>
          )}
          
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Full Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="text" required
                  value={fullName} onChange={(e) => setFullName(e.target.value)}
                  placeholder="As per CNIC"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Email Address (Optional)</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="email"
                  value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">CNIC Number</label>
                <div className="relative">
                  <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                  <input 
                    type="text" required
                    value={cnic} onChange={(e) => setCnic(e.target.value)}
                    placeholder="42XXX-XXXXXXX-X"
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">CNIC Date of Issue</label>
                <div className="relative">
                  <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                  <input 
                    type="date" required
                    value={issueDate} onChange={(e) => setIssueDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Secureshield Badge */}
            <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-2xl p-3.5 flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 animate-pulse" />
              <div className="text-left font-sans">
                <span className="block text-[10.5px] font-black text-slate-800 uppercase tracking-tight">Secureshield™ ID Protection Active</span>
                <span className="block text-[9.5px] text-slate-500 font-semibold leading-relaxed">To safeguard your identity from document reuse, our secure watermarker stamps a permanent diagonal visual protection overlay directly on the raw image canvas.</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">CNIC Front</label>
                <div 
                  className="relative group aspect-[1.6/1] bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500/50 hover:bg-emerald-50/30 transition-all overflow-hidden"
                  onClick={() => frontInputRef.current?.click()}
                >
                  {cnicFront ? (
                    <img src={cnicFront} alt="CNIC Front" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <Camera className="w-6 h-6 text-slate-300 mb-2 group-hover:text-emerald-500 transition-colors" />
                      <span className="text-[10px] font-bold text-slate-400 group-hover:text-emerald-600 transition-colors uppercase tracking-widest">Upload Front</span>
                    </>
                  )}
                  <input 
                    ref={frontInputRef}
                    type="file" accept="image/*" className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = async () => {
                          const base64 = reader.result as string;
                          try {
                            const stamped = await watermarkImage(base64, {
                              text: "PK ESCROW VERIFICATION ONLY",
                              subtext: fullName ? `IDENTITY: ${fullName}` : "REGISTERING ACCOUNT"
                            });
                            setCnicFront(stamped);
                            handleOcr(stamped);
                          } catch (err) {
                            setCnicFront(base64);
                            handleOcr(base64);
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                  {isScanning && (
                    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-5 h-5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                        <span className="text-[8px] font-black text-emerald-600 uppercase tracking-widest">Scanning...</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">CNIC Back</label>
                <div 
                  className="relative group aspect-[1.6/1] bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500/50 hover:bg-emerald-50/30 transition-all overflow-hidden"
                  onClick={() => backInputRef.current?.click()}
                >
                  {cnicBack ? (
                    <img src={cnicBack} alt="CNIC Back" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <ImageIcon className="w-6 h-6 text-slate-300 mb-2 group-hover:text-emerald-500 transition-colors" />
                      <span className="text-[10px] font-bold text-slate-400 group-hover:text-emerald-600 transition-colors uppercase tracking-widest">Upload Back</span>
                    </>
                  )}
                  <input 
                    ref={backInputRef}
                    type="file" accept="image/*" className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = async () => {
                          const base64 = reader.result as string;
                          try {
                            const stamped = await watermarkImage(base64, {
                              text: "PK ESCROW VERIFICATION ONLY",
                              subtext: fullName ? `IDENTITY: ${fullName}` : "REGISTERING ACCOUNT"
                            });
                            setCnicBack(stamped);
                          } catch (err) {
                            setCnicBack(base64);
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-2xl cursor-pointer" onClick={() => setAgreed(!agreed)}>
            <div className={`mt-0.5 rounded flex-shrink-0 transition-colors ${agreed ? 'bg-emerald-600 text-white' : 'bg-white border-2 border-slate-200 text-transparent'}`}>
              <CheckSquare className="w-5 h-5 p-0.5" />
            </div>
            <p className="text-sm font-medium text-slate-600 leading-snug">
              I hereby acknowledge that I have read the{' '}
              <span 
                onClick={(e) => {
                  e.stopPropagation();
                  setIsTermsOpen(true);
                }}
                className="text-emerald-600 font-bold underline hover:text-emerald-700 cursor-pointer"
              >
                Terms and Conditions
              </span>{' '}
              and agree to comply with them.
            </p>
          </div>

          <button 
            type="submit"
            disabled={!agreed || loading}
            className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold py-4 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-slate-900/10 group mt-4"
          >
            {loading ? 'Saving...' : 'Next Step'}
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>
      </motion.div>

      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
    </div>
  );
}

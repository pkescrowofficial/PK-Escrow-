import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { collection, query, where, onSnapshot, doc, getDoc, setDoc, updateDoc, arrayUnion, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Navbar } from '../components/Navbar';
import { Escrow } from '../components/EscrowCard';
import { compressImage } from '../lib/watermark';
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  Search, 
  PlusCircle, 
  FileText, 
  HelpCircle, 
  ChevronRight, 
  Lock, 
  ShieldAlert, 
  X, 
  Send, 
  User, 
  Check, 
  BookOpen, 
  CornerDownRight, 
  Image as ImageIcon 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function DisputesView() {
  const { user, profile, lang } = useAuth();
  const [buyingTx, setBuyingTx] = useState<Escrow[]>([]);
  const [sellingTx, setSellingTx] = useState<Escrow[]>([]);
  const [disputableEscrows, setDisputableEscrows] = useState<Escrow[]>([]);
  const [activeDisputedEscrows, setActiveDisputedEscrows] = useState<Escrow[]>([]);
  const [selectedEscrow, setSelectedEscrow] = useState<Escrow | null>(null);
  const [selectedDispute, setSelectedDispute] = useState<any>(null);
  
  // Form states for creating a dispute
  const [disputeReason, setDisputeReason] = useState('');
  const [disputeCategory, setDisputeCategory] = useState('credentials_mismatch');
  const [disputeNote, setDisputeNote] = useState('');
  const [evidenceScreenshot, setEvidenceScreenshot] = useState<string | null>(null);
  const [errorNote, setErrorNote] = useState<string | null>(null);
  const [successNote, setSuccessNote] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form states for adding evidence to existing dispute
  const [additionalNote, setAdditionalNote] = useState('');
  const [additionalScreenshot, setAdditionalScreenshot] = useState<string | null>(null);

  // Active sub-tab inside Dispute view
  const [activeTab, setActiveTab] = useState<'active' | 'eligible' | 'policy'>('active');

  const isUrdu = lang === 'ur';

  // Fetch all user escrows where they are buyer or seller
  useEffect(() => {
    if (!user?.uid) return;

    const q1 = query(collection(db, 'escrows'), where('buyerId', '==', user.uid));
    const unsub1 = onSnapshot(q1, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as Escrow));
      setBuyingTx(list || []);
    }, (err) => {
      console.warn("Failed to query buying escrows for disputes:", err);
      setBuyingTx([]);
    });

    const q2 = query(collection(db, 'escrows'), where('sellerId', '==', user.uid));
    const unsub2 = onSnapshot(q2, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as Escrow));
      setSellingTx(list || []);
    }, (err) => {
      console.warn("Failed to query selling escrows for disputes:", err);
      setSellingTx([]);
    });

    return () => {
      unsub1();
      unsub2();
    };
  }, [user?.uid]);

  // Sync escrows into categories
  useEffect(() => {
    const all = [...buyingTx, ...sellingTx];
    
    // De-duplicate
    const unique = Array.from(new Map(all.map(item => [item.id, item])).values());

    // Active disputed
    const disputed = unique.filter(e => e.status === 'DISPUTED');
    setActiveDisputedEscrows(disputed);

    // Eligible to be disputed: must be FUNDED, SHIPPED, or DELIVERED status and not yet completed
    const eligible = unique.filter(e => ['FUNDED', 'SHIPPED', 'DELIVERED'].includes(e.status));
    setDisputableEscrows(eligible);
  }, [buyingTx, sellingTx]);

  // Fetch dispute information when selectedEscrow updates
  useEffect(() => {
    if (!selectedEscrow) {
      setSelectedDispute(null);
      return;
    }

    if (selectedEscrow.status === 'DISPUTED') {
      const unsub = onSnapshot(doc(db, 'disputes', selectedEscrow.id), (snap) => {
        if (snap.exists()) {
          setSelectedDispute(snap.data());
        } else {
          setSelectedDispute(null);
        }
      }, (err) => {
        console.warn("Failed to listen to dispute status details:", err);
        setSelectedDispute(null);
      });
      return () => unsub();
    } else {
      setSelectedDispute(null);
    }
  }, [selectedEscrow]);

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>, isAdditional = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        try {
          const compressed = await compressImage(rawBase64, 1000, 0.72);
          if (isAdditional) {
            setAdditionalScreenshot(compressed);
          } else {
            setEvidenceScreenshot(compressed);
          }
        } catch (err) {
          console.error("Error compressing dispute screenshot:", err);
          if (isAdditional) {
            setAdditionalScreenshot(rawBase64);
          } else {
            setEvidenceScreenshot(rawBase64);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileDispute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEscrow || !user) return;
    if (!disputeReason.trim()) {
      setErrorNote(isUrdu ? "تبصرہ لازمی درج کریں" : "Please enter a valid dispute reason/note.");
      return;
    }

    setSubmitting(true);
    setErrorNote(null);
    setSuccessNote(null);

    const disputeId = selectedEscrow.id;
    const isBuyer = selectedEscrow.buyerId === user.uid;
    const counterpartyId = isBuyer ? selectedEscrow.sellerId : selectedEscrow.buyerId;

    const evidenceItem = {
      userId: user.uid,
      userName: profile?.displayName || 'User',
      note: disputeReason.trim(),
      attachments: evidenceScreenshot ? [evidenceScreenshot] : [],
      createdAt: new Date().toISOString()
    };

    try {
      // Create new dispute case in disputes collection
      await setDoc(doc(db, 'disputes', disputeId), {
        escrowId: disputeId,
        initiatorId: user.uid,
        initiatorName: profile?.displayName || 'User',
        reason: disputeReason.trim(),
        category: disputeCategory,
        evidence: [evidenceItem],
        status: 'OPEN',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      // Update escrow status in Firestore
      await updateDoc(doc(db, 'escrows', disputeId), {
        status: 'DISPUTED',
        updatedAt: serverTimestamp()
      });

      // Send automated PK notification to counterparty
      const notificationTitle = isUrdu ? 'تنازعہ درج کر دیا گیا ⚠️' : 'Dispute Raised ⚠️';
      const notificationMsg = isUrdu 
        ? `${profile?.displayName || 'دوسرے صارف'} نے ضامنی ڈیل پر تنازعہ شروع کیا ہے۔ برائے مہربانی اپنے پینل میں تنازعہ کے ثبوت چیک کریں۔`
        : `${profile?.displayName || 'Counterparty'} has disputed the escrow transaction for "${selectedEscrow.itemDescription}". Please provide counter evidence.`;

      await addDoc(collection(db, 'notifications'), {
        userId: counterpartyId,
        title: notificationTitle,
        message: notificationMsg,
        type: 'DANGER',
        link: 'disputes',
        createdAt: serverTimestamp(),
        isRead: false
      }).catch(e => console.warn("Failed to generate notify:", e));

      // Append real-time message to secure room chat
      await addDoc(collection(db, 'escrows', disputeId, 'messages'), {
        text: `🚨 SYSTEM ALERT: [${profile?.displayName || 'User'}] has initiated an official Dispute Claim.\n• Category: ${disputeCategory.toUpperCase().replace('_', ' ')}\n• Reason: ${disputeReason.trim()}\n• Status: Locked under arbitration review. Moderator audit will commence.`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString(),
        mediaUrl: evidenceScreenshot || null
      });

      setSuccessNote(isUrdu ? "تنازعہ کا کیس کامیابی سے رجسٹر ہو گیا ہے!" : "Dispute case registered successfully!");
      setDisputeReason('');
      setEvidenceScreenshot(null);
      // Wait a bit, then reload/unselect or keep selected to see status
      setTimeout(() => {
        setSelectedEscrow(prev => prev ? { ...prev, status: 'DISPUTED' } : null);
      }, 500);

    } catch (err: any) {
      console.error(err);
      setErrorNote(err.message || "Failed to initiate dispute");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEscrow || !selectedDispute || !user) return;
    if (!additionalNote.trim() && !additionalScreenshot) return;

    setSubmitting(true);
    setErrorNote(null);

    const evidenceItem = {
      userId: user.uid,
      userName: profile?.displayName || 'User',
      note: additionalNote.trim() || (isUrdu ? "نیا ثبوت اٹیچمنٹ" : "Added file attachment as supplementary evidence."),
      attachments: additionalScreenshot ? [additionalScreenshot] : [],
      createdAt: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'disputes', selectedEscrow.id), {
        evidence: arrayUnion(evidenceItem),
        updatedAt: new Date().toISOString()
      });

      // Send message in the chat
      await addDoc(collection(db, 'escrows', selectedEscrow.id, 'messages'), {
        text: `📎 SYSTEM: [${profile?.displayName || 'User'}] has uploaded additional screenshot evidence for the Dispute claim.`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString(),
        mediaUrl: additionalScreenshot || null
      });

      setAdditionalNote('');
      setAdditionalScreenshot(null);
    } catch (err: any) {
      console.error(err);
      setErrorNote(err.message || "Failed to append evidence");
    } finally {
      setSubmitting(false);
    }
  };

  // Direct Amicable Resolution options for absolute fast settlement!
  const handleAmicableSettle = async (decision: 'RELEASE_TO_SELLER' | 'REFUND_TO_BUYER') => {
    if (!selectedEscrow) return;

    const confirmMsg = decision === 'RELEASE_TO_SELLER'
      ? (isUrdu 
          ? "کیا آپ سچ میں رقم بیچنے والے کو ٹرانسفر کرنا چاہتے ہیں؟ یہ واپسی کے قابل نہیں ہوگی۔"
          : "Are you sure you want to release full escrow funds to the Seller? This will close the dispute and is irreversible.")
      : (isUrdu
          ? "کیا آپ سچ میں رقم خریدار کو واپس لوٹانا چاہتے ہیں؟"
          : "Are you sure you want to refund full escrow funds back to the Buyer? This will close the dispute.");

    if (!confirm(confirmMsg)) return;

    setSubmitting(true);
    try {
      const finalStatus = decision === 'RELEASE_TO_SELLER' ? 'COMPLETED' : 'CANCELLED';
      
      // 1. Update Escrow status
      await updateDoc(doc(db, 'escrows', selectedEscrow.id), {
        status: finalStatus,
        resolvedBy: 'AMICABLE_AGREEMENT',
        resolvedAt: new Date().toISOString(),
        updatedAt: serverTimestamp()
      });

      // 2. Update Dispute doc status
      await updateDoc(doc(db, 'disputes', selectedEscrow.id), {
        status: 'RESOLVED',
        decision: decision,
        resolutionNotes: `Resolved amicably by mutual consent. Funds allocated: ${decision}`,
        updatedAt: new Date().toISOString()
      });

      // 3. System message to Chat
      await addDoc(collection(db, 'escrows', selectedEscrow.id, 'messages'), {
        text: `🤝 AMICABLE SETTLEMENT REACHED: Dispute closed by mutual agreement! System processed action: [${decision.replace(/_/g, ' ')}]. Trust funds distributed cleanly.`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString()
      });

      // 4. Update ledger balances if refunding/releasing
      if (decision === 'RELEASE_TO_SELLER') {
        const sellerRef = doc(db, 'users', selectedEscrow.sellerId);
        const sellerSnap = await getDoc(sellerRef);
        if (sellerSnap.exists()) {
          const curBal = sellerSnap.data().balance || 0;
          await updateDoc(sellerRef, {
            balance: curBal + selectedEscrow.amount
          });
        }
      } else {
        // Refund to Buyer
        const buyerRef = doc(db, 'users', selectedEscrow.buyerId);
        const buyerSnap = await getDoc(buyerRef);
        if (buyerSnap.exists()) {
          const curBal = buyerSnap.data().balance || 0;
          await updateDoc(buyerRef, {
            balance: curBal + selectedEscrow.amount
          });
        }
      }

      setSuccessNote(isUrdu ? "ڈیل کا مسئلہ خوش اسلوبی سے حل ہو گیا ہے!" : "Dispute resolved amicably!");
      setSelectedEscrow(null);
    } catch (e: any) {
      console.error(e);
      setErrorNote(e.message || "Failed to settle dispute");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Urdu/English Header Title Block */}
        <div className="bg-gradient-to-tr from-slate-900 via-rose-950 to-slate-900 text-white rounded-[2rem] p-6 sm:p-8 mb-8 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2 text-left">
              <span className="bg-rose-500 text-white text-[9px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full inline-block">
                🛡️ {isUrdu ? "سیکیور کلیمز اور کورٹ روم" : "PK Escrow Arbitration Court"}
              </span>
              <h1 className="text-2xl sm:text-3.5xl font-black tracking-tight leading-tight">
                {isUrdu ? "اپنے مسالم اور شکایات کا تیز حل" : "Instant P2P Dispute Resolution Center"}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-xl leading-relaxed">
                {isUrdu 
                  ? "اگر خریدار یا بیچنے والے کے درمیان کسی قسم کا اختلاف پیش آئے یا دھوکہ دہی کی کوشش ہو، تو یہاں اپنا ثبوت پیش کریں۔ ہماری فریقین کی ضمانتی فیس اور رقم آپ کے کیس کے حل تک محفوظ رکھتے ہیں۔"
                  : "If you experience description mismatch, credential change, or fraud, lock the transaction immediately under dispute. Funds are held safely until resolved."
                }
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Listings panel (7 cols on large desktop) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Page Toggles/Filters */}
            <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm gap-2">
              <button
                onClick={() => { setActiveTab('active'); setSelectedEscrow(null); }}
                className={`flex-1 py-3 text-[10px] sm:text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'active' 
                    ? 'bg-rose-500 text-white shadow-md' 
                    : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <ShieldAlert className="w-4 h-4" />
                <span>{isUrdu ? "🚨 جاری تنازعات" : "🚨 Active Disputes"}</span>
                {activeDisputedEscrows.length > 0 && (
                  <span className="bg-white text-rose-600 rounded-full text-[9px] w-5 h-5 flex items-center justify-center font-black">
                    {activeDisputedEscrows.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => { setActiveTab('eligible'); setSelectedEscrow(null); }}
                className={`flex-1 py-3 text-[10px] sm:text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'eligible' 
                    ? 'bg-rose-500 text-white shadow-md' 
                    : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <PlusCircle className="w-4 h-4" />
                <span>{isUrdu ? "➕ شکایت درج کریں" : "➕ File New Dispute"}</span>
                {disputableEscrows.length > 0 && (
                  <span className="bg-slate-100 text-slate-700 rounded-full text-[9px] w-5 h-5 flex items-center justify-center font-black">
                    {disputableEscrows.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => { setActiveTab('policy'); setSelectedEscrow(null); }}
                className={`flex-1 py-3 text-[10px] sm:text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'policy' 
                    ? 'bg-rose-500 text-white shadow-md' 
                    : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>{isUrdu ? "📜 سیکیورٹی پالیسی" : "📜 Security Policy"}</span>
              </button>
            </div>

            {/* TAB CONTENT: ACTIVE DISPUTES */}
            {activeTab === 'active' && (
              <div className="space-y-4">
                {activeDisputedEscrows.length === 0 ? (
                  <div className="bg-white border rounded-[2rem] p-10 text-center space-y-3">
                    <div className="w-14 h-14 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">{isUrdu ? "سب ٹھیک ہے!" : "No Active Disputes"}</h3>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                      {isUrdu
                        ? "آپ کی تمام ڈیلز بالکل نارمل چل رہی ہیں۔ فی الحال کوئی ڈیل تنازعہ یا ویریفکیشن کلیمز میں مقفل نہیں ہے۔"
                        : "All your P2P trades are healthy! There are no transactions currently locked under controversy or legal lock."
                      }
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {activeDisputedEscrows.map((escrow) => {
                      const isBuyerObj = escrow.buyerId === user?.uid;
                      return (
                        <div 
                          key={escrow.id}
                          onClick={() => setSelectedEscrow(escrow)}
                          className={`bg-white border text-left p-5 rounded-[1.75rem] transition-all hover:shadow-lg cursor-pointer flex justify-between items-center ${
                            selectedEscrow?.id === escrow.id ? 'border-rose-500 ring-4 ring-rose-50' : 'border-slate-200'
                          }`}
                        >
                          <div className="space-y-1.5 flex-1 min-w-0 pr-4">
                            <div className="flex items-center gap-2">
                              <span className="bg-rose-550/10 text-rose-700 text-[8px] font-black uppercase tracking-wider px-2 py-1 rounded">
                                🚨 {isUrdu ? "زیر التواء فیصلہ" : "Under Investigation"}
                              </span>
                              <span className="text-[10px] font-black font-mono text-slate-400">TX ID: {escrow.id.substring(0, 8).toUpperCase()}...</span>
                            </div>
                            <h3 className="text-sm font-black text-slate-900 truncate">{escrow.itemDescription}</h3>
                            <div className="flex items-center gap-4 text-[10px] font-bold text-slate-500">
                              <span>{isUrdu ? "کردار:" : "Role:"} <strong className="text-slate-800">{isBuyerObj ? (isUrdu ? "خریدار" : "Buyer") : (isUrdu ? "بیچنے والا" : "Seller")}</strong></span>
                              <span>•</span>
                              <span>{isUrdu ? "فریق:" : "Counterparty:"} <strong className="text-indigo-650">{isBuyerObj ? escrow.sellerName : escrow.buyerName}</strong></span>
                            </div>
                          </div>
                          
                          <div className="text-right shrink-0 flex items-center gap-4">
                            <div className="space-y-0.5">
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{isUrdu ? "رقم" : "LOCKED AMOUNT"}</p>
                              <p className="text-base font-black text-rose-600 font-mono">Rs. {escrow.amount.toLocaleString()}</p>
                            </div>
                            <ChevronRight className="w-5 h-5 text-slate-350" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: ELIGIBLE TRANSACTION LIST (Create Dispute Form Launcher) */}
            {activeTab === 'eligible' && (
              <div className="space-y-4">
                {disputableEscrows.length === 0 ? (
                  <div className="bg-white border rounded-[2rem] p-10 text-center space-y-3">
                    <div className="w-14 h-14 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400">
                      <Lock className="w-6 h-6" />
                    </div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">{isUrdu ? "کوئی اہل ڈیل دستیاب نہیں ہے" : "No Disputes Eligible"}</h3>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                      {isUrdu
                        ? "تنازعہ قائم کرنے کے لیے ڈیل کا فنڈڈ ہونا یعنی خریدار کی طرف سے ضامن رقم جمع کروانا لازمی شرط ہے۔"
                        : "Only transactions where funds are currently secured ('Locked & Funded', 'Shipped', or 'Delivered' states) can be disputed."
                      }
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-[11px] font-extrabold text-slate-500 uppercase tracking-widest text-left pl-1">
                      {isUrdu ? "👇 ایک ڈیل منتخب کریں جس کے خلاف آپ تنازعہ درج کرنا چاہتے ہیں:" : "👇 Select a trade to unlock Dispute Verification for:"}
                    </p>
                    <div className="grid grid-cols-1 gap-3">
                      {disputableEscrows.map((escrow) => {
                        const isBuyerObj = escrow.buyerId === user?.uid;
                        return (
                          <div 
                            key={escrow.id}
                            onClick={() => {
                              setSelectedEscrow(escrow);
                              setErrorNote(null);
                              setSuccessNote(null);
                            }}
                            className={`bg-white border text-left p-5 rounded-[1.75rem] transition-all hover:border-indigo-400 active:scale-99/100 cursor-pointer flex justify-between items-center ${
                              selectedEscrow?.id === escrow.id ? 'border-indigo-600 ring-4 ring-indigo-50' : 'border-slate-200'
                            }`}
                          >
                            <div className="space-y-1.5 flex-1 min-w-0 pr-4">
                              <div className="flex items-center gap-2">
                                <span className="bg-emerald-50 text-emerald-700 text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded border border-emerald-100">
                                  🏦 {escrow.status}
                                </span>
                                <span className="text-[10px] font-black font-mono text-slate-400">TX ID: {escrow.id.substring(0, 8).toUpperCase()}...</span>
                              </div>
                              <h3 className="text-sm font-black text-slate-900 truncate">{escrow.itemDescription}</h3>
                              <p className="text-[10px] font-semibold text-slate-500">
                                {isUrdu ? "فریق صارف:" : "Counterparty:"} <strong className="text-slate-700">{isBuyerObj ? escrow.sellerName : escrow.buyerName}</strong>
                              </p>
                            </div>
                            
                            <div className="text-right shrink-0 flex items-center gap-3">
                              <div className="space-y-0.5">
                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider">{isUrdu ? "ضامنی فنڈ" : "Funds Locked"}</p>
                                <p className="text-sm font-extrabold text-indigo-700 font-mono">Rs. {escrow.amount.toLocaleString()}</p>
                              </div>
                              <ArrowRight className="w-5 h-5 text-indigo-400" />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: DISPUTE & AUDIT POLICY DECK */}
            {activeTab === 'policy' && (
              <div className="bg-white border border-slate-200 rounded-[2rem] p-6 sm:p-8 text-left space-y-6">
                <div>
                  <h3 className="text-lg font-black text-indigo-950 uppercase tracking-tight flex items-center gap-2">
                    🛡️ {isUrdu ? "پی کے ایسکرو صارف کی سیکیورٹی گائیڈ لائنز" : "PK Escrow Legal Resolution Guidelines"}
                  </h3>
                  <p className="text-xs text-slate-500 font-bold mt-1 leading-relaxed">
                    {isUrdu
                      ? "ہماری مصالحتی کمیٹی آپ کی دائر کردہ ہر درخواست اور ثبوتوں پر مکمل تحقیق کرتی ہے۔"
                      : "Our moderation team acts as an impartial third-party agent to verify screenshots, receipts, and credential proofs."
                    }
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                  <div className="border border-slate-100 p-4 rounded-2.5xl bg-slate-50/50 space-y-2">
                    <h4 className="text-xs font-black text-rose-600 uppercase tracking-wider flex items-center gap-1.5">
                      🔒 {isUrdu ? "رقم کا لاک ہونا" : "1. Instant Balance Freezing"}
                    </h4>
                    <p className="text-[11px] font-bold text-slate-600 leading-relaxed text-left">
                      {isUrdu
                        ? "جیسے ہی آپ تنازعہ درج کرتے ہیں، خریدار کے پیسے عارضی فریز بیلنس میں چلے جاتے ہیں، جسے فریقین میں سے کوئی بھی بلا منظوری نہیں نکال سکتا۔"
                        : "Once a dispute begins, full platform withdrawal is completely locked for that specific transaction. Funds cannot move."
                      }
                    </p>
                  </div>

                  <div className="border border-slate-100 p-4 rounded-2.5xl bg-slate-50/50 space-y-2">
                    <h4 className="text-xs font-black text-rose-600 uppercase tracking-wider flex items-center gap-1.5">
                      📸 {isUrdu ? "تصویر اور اسکرین شاٹ کا اپ لوڈ" : "2. Valid Visual Evidence"}
                    </h4>
                    <p className="text-[11px] font-bold text-slate-600 leading-relaxed text-left">
                      {isUrdu
                        ? "ہمیشہ واضح رسید ایزی پیسہ/جازکیش والٹ کی تاریخ، ٹرانزیکشن آئی ڈی (TID)، اور واٹس ایپ چٹ چیٹ لاگ اسکرین شاٹس اپ لوڈ کریں۔"
                        : "Upload original full-screen pictures consisting of Wallet Transaction TID, mobile SMS logs, and WhatsApp conversation screenshots."
                      }
                    </p>
                  </div>

                  <div className="border border-slate-100 p-4 rounded-2.5xl bg-slate-50/50 space-y-2">
                    <h4 className="text-xs font-black text-indigo-700 uppercase tracking-wider flex items-center gap-1.5">
                      🤝 {isUrdu ? "خوش اسلوبی سے براہ راست حل" : "3. Direct Amicable Settle"}
                    </h4>
                    <p className="text-[11px] font-bold text-slate-600 leading-relaxed text-left">
                      {isUrdu
                        ? "فریقین آپس میں سمجھوتہ کر کے براہ راست 'ریلیز' یا 'ریفنڈ' چن سکتے ہیں، جس سے کمشنر کی مداخلت کے بغیر فورا فیصلہ ہو جاتا ہے۔"
                        : "You can reach out in chat and complete amicable resolution. If both consent, values can be released or refunded within seconds."
                      }
                    </p>
                  </div>

                  <div className="border border-slate-100 p-4 rounded-2.5xl bg-slate-50/50 space-y-2">
                    <h4 className="text-xs font-black text-indigo-700 uppercase tracking-wider flex items-center gap-1.5">
                      ⏳ {isUrdu ? "حل کا متوقع دورانیہ" : "4. Resolution Timeline"}
                    </h4>
                    <p className="text-[11px] font-bold text-slate-600 leading-relaxed text-left">
                      {isUrdu
                        ? "کیس کا فیصلہ عام طور پر جمع کرائے گئے سیکیور رسید لاگز کی تصدیق کے بعد 6 سے 24 گھنٹے کے اندر کر دیا جاتا ہے۔"
                        : "Most dispute reviews conclude within 6-24 hours depending on the clarity and verification of submitted receipts."
                      }
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT: Detail Visual Workspace (4 cols on large desktop) */}
          <div className="lg:col-span-4">
            
            {/* If no escrow is selected, show general help guide card */}
            {!selectedEscrow ? (
              <div className="bg-white border border-slate-200 rounded-[2.5rem] p-6 text-left space-y-4 shadow-sm">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center font-black text-lg">🛡️</div>
                <div className="space-y-1">
                  <h3 className="text-xs font-black text-indigo-950 uppercase tracking-widest">{isUrdu ? "مسائل کا حل کا ورک اسپیس" : "Dispute Workspace"}</h3>
                  <h4 className="text-sm font-black text-slate-900 leading-tight">
                    {isUrdu ? "تفصیل دریافت کرنے کے لیے کوئی ٹرانزیکشن منتخب کریں" : "Select a Transaction to Begin Resolution"}
                  </h4>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                  {isUrdu
                    ? "بائیں جانب دی گئی کسی بھی ڈیل پر کلک کر کے اس کے بارے میں مکمل تنازعہ کا فارم کھولیں، نئے ثبوت اپ لوڈ کریں یا باہمی شراکت سے مسئلہ دور کریں۔"
                    : "Click on any active controversy or eligible safe transaction to load forms, append images, or execute mutual refunds."
                  }
                </p>
                
                <div className="border-t border-slate-100 pt-4 space-y-3.5">
                  <div className="flex items-start gap-2 text-[11px] font-bold text-slate-600">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{isUrdu ? "فاسٹ مینوئل ایزی پیسہ ٹرانسفر کلیمز" : "EasyPaisa direct transaction claims"}</span>
                  </div>
                  <div className="flex items-start gap-2 text-[11px] font-bold text-slate-600">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{isUrdu ? "محفوظ جاز کیش ٹرانزیکشن آڈٹ لاگ" : "JazzCash verified receiver checking"}</span>
                  </div>
                </div>
              </div>
            ) : (
              
              /* RENDER: Selected Escrow Workspace */
              <div className="bg-white border border-slate-150 rounded-[2.5rem] p-6 text-left space-y-5 shadow-xl relative animate-fade-in">
                
                {/* Header Close Button */}
                <button 
                  onClick={() => setSelectedEscrow(null)}
                  className="absolute top-4 right-4 w-7 h-7 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Escrow Brief details */}
                <div className="space-y-1">
                  <span className="text-[9px] font-black text-indigo-600 uppercase tracking-widest block">{isUrdu ? "منتخب کردہ سودا" : "Selected Escrow Unit"}</span>
                  <h3 className="text-sm font-black text-slate-900 leading-tight">{selectedEscrow.itemDescription}</h3>
                  <span className="text-[10px] font-extrabold text-slate-500 font-mono block">TX ID: {selectedEscrow.id.toUpperCase()}</span>
                </div>

                <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex justify-between items-center text-xs">
                  <div>
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">{isUrdu ? "ضامنی رقم" : "Funds Escrowed"}</span>
                    <strong className="text-slate-800 text-sm">Rs. {selectedEscrow.amount.toLocaleString()}</strong>
                  </div>
                  <div className="text-right">
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">{isUrdu ? "موجودہ اسٹیٹس" : "State"}</span>
                    <strong className="text-rose-550 uppercase tracking-widest text-[10px] bg-rose-50 border border-rose-100 px-2 py-0.5 rounded font-black inline-block">
                      {selectedEscrow.status}
                    </strong>
                  </div>
                </div>

                {/* CASE A: Escrow is NOT currently disputed -> RENDER FILE DISPUTE FORM */}
                {selectedEscrow.status !== 'DISPUTED' ? (
                  <form onSubmit={handleFileDispute} className="space-y-4 pt-2 border-t border-slate-100">
                    <div className="p-3 bg-rose-50 border border-rose-100/60 rounded-2xl text-[11px] text-rose-800 font-bold leading-relaxed">
                      ⚠️ {isUrdu 
                        ? "یہ ٹرانزیکشن فی الحال متبادل حالت میں ہے۔ اگر خریدار یا بیچنے والے نے اصولوں کی خلاف ورزی کی ہے تو نیا تنازعہ شروع کریں۔"
                        : "Secured funds will be locked until the moderator audits current claims and statements. Fill the report below."
                      }
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest px-0.5">{isUrdu ? "تنازعہ کا زمرہ / نوعیت" : "Dispute Category"}</label>
                      <select 
                        value={disputeCategory}
                        onChange={(e) => setDisputeCategory(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/10 cursor-pointer"
                      >
                        <option value="credentials_mismatch">{isUrdu ? "غلط معلومات یا پاس ورڈ" : "Credentials/Item mismatch"}</option>
                        <option value="not_received">{isUrdu ? "سامان نہیں ملا / نو ڈلیوری" : "Item not received / Dispatched"}</option>
                        <option value="seller_scam_intent">{isUrdu ? "دھوکہ دہی یا من مانی تبدیلی" : "Seller scam intent / profile fraud"}</option>
                        <option value="payment_clearing_mismatch">{isUrdu ? "رقم موصول نہیں ہوئی (موبائل والٹ)" : "Seller wallet payment balance clearance issues"}</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest px-0.5">{isUrdu ? "مسئلے کی تفصیل (تفصیلی وضاحت)" : "Explain Issue Details"}</label>
                      <textarea
                        required
                        value={disputeReason}
                        onChange={(e) => setDisputeReason(e.target.value)}
                        placeholder={isUrdu ? "مثال کے طور پر: بیچنے والے نے غلط پاس ورڈ مہیا کیا ہے اور اب رابطہ نہیں کر رہا۔ براہ کرم میرے پیسے ریفنڈ کریں..." : "Describe exactly what went wrong. Provide credential details or communication history facts."}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/10 min-h-[90px] placeholder:text-slate-350"
                      />
                    </div>

                    {/* Screenshot file upload */}
                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest px-0.5">{isUrdu ? "ثبوت کی تصویر / رسید کا اسکرین شاٹ" : "Upload Proof Attachment"}</label>
                      <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-2.5">
                        <input 
                          type="file" 
                          id="sc-dispute-file"
                          accept="image/*"
                          onChange={(e) => handleScreenshotChange(e, false)}
                          className="hidden" 
                        />
                        <label 
                          htmlFor="sc-dispute-file"
                          className="bg-white border border-slate-200 hover:bg-slate-100 px-3 py-1.5 rounded-xl text-[10px] font-black text-slate-700 cursor-pointer shadow-sm flex items-center gap-1 shrink-0"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-slate-500" /> {isUrdu ? "فوٹو منتخب کریں" : "Choose Image"}
                        </label>
                        <span className="text-[10px] font-bold text-slate-400 truncate flex-1">
                          {evidenceScreenshot ? '🟢 Loaded Successfully' : 'No folder picked'}
                        </span>
                      </div>
                      {evidenceScreenshot && (
                        <div className="relative rounded-xl overflow-hidden border bg-slate-100/50 aspect-[1.4/1] max-w-[130px] mt-2 shadow-sm">
                          <img src={evidenceScreenshot} alt="Evidence preview" className="w-full h-full object-cover" />
                          <button 
                            type="button" 
                            onClick={() => setEvidenceScreenshot(null)}
                            className="absolute top-1 right-1 bg-slate-900/80 text-white rounded-full w-5 h-5 flex items-center justify-center text-[8px] font-bold"
                          >
                            ✕
                          </button>
                        </div>
                      )}
                    </div>

                    {errorNote && <p className="text-[9px] font-black text-rose-500 bg-rose-50 p-2.5 rounded-xl border border-rose-100">{errorNote}</p>}
                    {successNote && <p className="text-[9px] font-black text-emerald-600 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">{successNote}</p>}

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full bg-rose-650 hover:bg-rose-700 text-white py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-rose-600/10 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                      style={{ backgroundColor: '#e11d48' }}
                    >
                      {submitting ? (isUrdu ? "فارغ ہو رہا ہے..." : "Submitting Claim...") : (isUrdu ? "🔥 تنازعہ درج کریں" : "🔥 Unlock & Lodge Dispute")}
                    </button>
                  </form>
                ) : (
                  
                  /* CASE B: Escrow is ALREADY disputed -> SHOW DISPUTE TIMELINE & ADD EVIDENCE */
                  <div className="space-y-4 pt-2 border-t border-slate-100">
                    
                    {/* Resolution Status Header */}
                    <div className="bg-amber-50 border border-amber-200/50 p-3.5 rounded-2xl">
                      <h4 className="text-[10px] font-black text-amber-800 uppercase tracking-widest leading-none">
                        ⚖️ {isUrdu ? "کیس کی حالت: تصدیق جاری ہے" : "Case Status: Under Moderation"}
                      </h4>
                      <p className="text-[11px] font-bold text-slate-600 mt-2 leading-relaxed">
                        {isUrdu
                          ? "ہماری مصالحتی ٹیم دونوں فریقوں کے اپ لوڈ کردہ والٹ ثبوت چیک کر رہی ہے۔ آپ کا فنڈ مکمل طور پر لاک ہے۔"
                          : "Audit index holds secure locks. Provide extra files or initiate direct client refund settlement options."
                        }
                      </p>
                    </div>

                    {/* Evidence history timeline logs */}
                    {selectedDispute && selectedDispute.evidence && (
                      <div className="space-y-3">
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-0.5">{isUrdu ? "پیش کردہ ثبوتوں کی لاگز:" : "Submitted Evidence Logs"}</h4>
                        <div className="space-y-2.5 max-h-[160px] overflow-y-auto pr-1 divide-y divide-slate-100">
                          {selectedDispute.evidence.map((ev: any, i: number) => (
                            <div key={i} className="pt-2 text-[11px] text-slate-705 space-y-1">
                              <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-wide">
                                <span className={ev.userId === user?.uid ? 'text-indigo-600' : 'text-slate-500'}>
                                  👤 {ev.userName || 'Counterparty'}
                                </span>
                                <span className="text-slate-400 font-mono">
                                  {new Date(ev.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="font-bold text-slate-700 text-left text-[11px] pl-1">{ev.note}</p>
                              {ev.attachments && ev.attachments[0] && (
                                <div className="pl-1 max-w-[100px] aspect-[1.4/1] rounded-xl overflow-hidden border border-slate-200 mt-1 relative group cursor-pointer">
                                  <img 
                                    src={ev.attachments[0]} 
                                    alt="Ev snapshot" 
                                    className="w-full h-full object-cover" 
                                    referrerPolicy="no-referrer"
                                    onClick={() => {
                                      const w = window.open();
                                      if(w) w.document.write(`<img src="${ev.attachments[0]}" style="max-width:100%; display:block; margin:auto;" />`);
                                    }}
                                  />
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Append evidence Form */}
                    <form onSubmit={handleAddEvidence} className="space-y-3.5 pt-3 border-t border-slate-100">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest px-0.5">{isUrdu ? "مزید ثبوت یا اپیل درج کریں" : "Append Evidence / Appeal Note"}</label>
                        <input 
                          type="text"
                          value={additionalNote}
                          onChange={(e) => setAdditionalNote(e.target.value)}
                          placeholder={isUrdu ? "مثال کے طور پر: فیزیکل بینک اسٹیٹمنٹ اپ ڈیٹ..." : "e.g. Added high-res transfer receipt screenshot"}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/10 placeholder:text-slate-350"
                        />
                      </div>

                      <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl p-2">
                        <input 
                          type="file" 
                          id="additional-evidence-file" 
                          accept="image/*"
                          onChange={(e) => handleScreenshotChange(e, true)}
                          className="hidden" 
                        />
                        <label 
                          htmlFor="additional-evidence-file"
                          className="bg-white border text-[10px] font-black text-slate-700 px-3 py-1.5 rounded-xl cursor-pointer hover:bg-slate-100 shadow-sm flex items-center gap-1"
                        >
                          📎 {isUrdu ? "منسلک کریں" : "Attach Image"}
                        </label>
                        <span className="text-[10px] font-bold text-slate-400 truncate ... flex-1">
                          {additionalScreenshot ? '🟢 Ready' : 'No folder picked'}
                        </span>
                      </div>

                      <button
                        type="submit"
                        disabled={submitting || (!additionalNote.trim() && !additionalScreenshot)}
                        className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all cursor-pointer disabled:opacity-40"
                      >
                        {isUrdu ? "📤 متبادل ثبوت بھیجیں" : "📤 Send Extra Proof"}
                      </button>
                    </form>

                    {/* AMICABLE DIRECT MUTUAL SETTLEMENT ACTIONS FOR USERS */}
                    <div className="border-t border-slate-200/60 pt-4 mt-4 space-y-3">
                      <h4 className="text-[10px] font-black text-indigo-750 uppercase tracking-widest px-0.5">
                        🤝 {isUrdu ? "براہ راست باہمی سمجھوتہ" : "Direct Fast Resolution Portal"}
                      </h4>
                      <p className="text-[10px] font-bold text-slate-400 leading-relaxed -mt-1 pl-0.5 text-left">
                        {isUrdu 
                          ? "آپس میں صلح ہو جانے پر آپ کیس فورا براہ راست ختم کر سکتے ہیں۔"
                          : "In case of mutual consent, close this controversy instantly without waiting for commission decisions."
                        }
                      </p>

                      <div className="grid grid-cols-2 gap-2.5">
                        <button
                          type="button"
                          onClick={() => handleAmicableSettle('RELEASE_TO_SELLER')}
                          className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 py-3 rounded-2xl text-[10px] font-black uppercase tracking-wider text-center transition-all cursor-pointer active:scale-95"
                        >
                          💸 {isUrdu ? "بیچنے والے کو رقم دیں" : "Release to Seller"}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleAmicableSettle('REFUND_TO_BUYER')}
                          className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 py-3 rounded-2xl text-[10px] font-black uppercase tracking-wider text-center transition-all cursor-pointer active:scale-95"
                        >
                          🔄 {isUrdu ? "خریدار کو ریفنڈ کریں" : "Refund to Buyer"}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
}

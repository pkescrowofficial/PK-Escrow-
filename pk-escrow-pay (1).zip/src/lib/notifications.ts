import { collection, addDoc, serverTimestamp, doc, updateDoc, writeBatch } from 'firebase/firestore';
import { db } from './firebase';

export interface AppNotification {
  id?: string;
  userId: string;
  title: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'DANGER';
  isRead: boolean;
  link?: string;
  createdAt: any;
}

/**
 * Creates and delivers a real-time notification to a specific user.
 * @param userId - Target user's UID
 * @param title - Notification title
 * @param message - Notification message details
 * @param type - Notification priority or styling style
 * @param link - Optional reference link (e.g. escrow ID or transaction link)
 */
export async function sendNotification(
  userId: string,
  title: string,
  message: string,
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'DANGER' = 'INFO',
  link?: string
) {
  if (!userId) return;
  try {
    await addDoc(collection(db, 'notifications'), {
      userId,
      title,
      message,
      type,
      isRead: false,
      link: link || '',
      createdAt: serverTimestamp()
    });
  } catch (err) {
    console.error('Failed to create notification document in Firestore:', err);
  }
}

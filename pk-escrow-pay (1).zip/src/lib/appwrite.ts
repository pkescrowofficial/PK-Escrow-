import { Client, Databases, Storage } from 'appwrite';

const client = new Client();

try {
  client
    .setEndpoint('https://cloud.appwrite.io/v1') // Public cloud API endpoint
    .setProject('pk-escrow-pay');                // Fallback default project ID
} catch (e) {
  console.warn('Appwrite client configuration warning:', e);
}

export const databases = new Databases(client);
export const storage = new Storage(client);
export { client };

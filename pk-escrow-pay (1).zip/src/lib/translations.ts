export type Language = 'en' | 'ur';

export const translations = {
  en: {
    brand: "PK Escrow",
    activeEscrows: "Active Escrows",
    history: "History",
    dashboard: "Dashboard",
    walletBalance: "Wallet Balance",
    addMoney: "Add Money",
    moneyTransfer: "Create Escrow",
    manageSecureP2P: "Manage your secure peer-to-peer payments.",
    all: "All",
    buying: "Buying",
    selling: "Selling",
    noTransactions: "No transactions found",
    startFirst: "Start your first secure transaction by inviting a seller or buyer.",
    proposeFirst: "Propose your first escrow",
    loggedAs: "Logged as",
    
    // EscrowCard translations
    buyer: "Buyer",
    seller: "Seller",
    amount: "Amount",
    status: "Status",
    role: "Role",
    type: "Type",
    category: "Category",
    securingFunds: "Securing Funds",
    
    // Statuses
    PROPOSED: "Proposed/Requested",
    FUNDED: "Locked & Funded",
    SHIPPED: "Dispatched/Shipped",
    DELIVERED: "Delivered",
    COMPLETED: "Released/Completed",
    DISPUTED: "Disputed/Under Review",
    CANCELLED: "Cancelled/Voided",

    // Action buttons
    depositFunds: "Deposit & Secure Funds",
    dispatchedGoods: "Mark as Despatched",
    verifyDelivery: "Accept and Release Money",
    raiseDispute: "Raise Dispute / Claim",
    resolved: "Resolved by Moderator",

    // Fee Calculator
    feeCalculator: "Interactive Escrow Fee Calculator",
    feesCoveredPromo: "🎉 Promo Offer: 0% Platform Fees Active!",
    calcAmount: "Deal Amount (Rs.)",
    calcFeeSplit: "Platform Fee Split",
    buyerPays: "Buyer Pays (100%)",
    sellerPays: "Seller Pays (100%)",
    split50: "Split 50 / 50",
    escrowFee: "Escrow Fee (Standard 1.5%)",
    youPay: "Buyer Pays Extra",
    youReceive: "Seller Receives",
    actualPlatformFee: "Platform Service Charges (Promo: Rs. 0)",
    totalTaxWarn: "FBR tax is not charged for peer-to-peer personal deals.",

    // Bank transfer details
    localPaymentChannels: "Pakistani Payment Channels",
    easyPaisa: "EasyPaisa Wallet",
    jazzCash: "JazzCash Wallet",
    nayapay: "NayaPay Digital Wallet",
    sadapay: "SadaPay Card",
    meezan: "Meezan Bank Shariah",
    hbl: "HBL Bank",
    ubl: "UBL Bank",
    alfalah: "Bank Alfalah",
    
    // Verification
    cnicVerification: "CNIC Smart Verification",
    motherName: "Mother's Birth Name",
    placeOfBirth: "District / City of Birth",
    verifyNow: "Submit Verification Data",
    cnicScanTitle: "NADRA CNIC OCR Auto-Scanner"
  },
  ur: {
    brand: "پی کے ایسکرو",
    activeEscrows: "اوپن امانتیں / ڈیلز",
    history: "پچھلی ہسٹری",
    dashboard: "ڈیش بورڈ",
    walletBalance: "کیش بیلنس",
    addMoney: "رقم جمع کریں",
    moneyTransfer: "نیا معاہدہ کریں",
    manageSecureP2P: "اپنی خریدو فروخت کی ادائیگیوں کو ضامن کے ذریعے محفوظ کریں۔",
    all: "تمام ڈیلز",
    buying: "خریداری کی ڈیلز",
    selling: "بیچنے کی ڈیلز",
    noTransactions: "کوئی معاہدہ نہیں ملا",
    startFirst: "خریدار یا بیچنے والے کو شامل کر کے اپنی پہلی محفوظ ڈیل شروع کریں۔",
    proposeFirst: "پہلی ڈیل کی پیشکش کریں",
    loggedAs: "موبائل اکاؤنٹ",

    // EscrowCard translations
    buyer: "خریدار",
    seller: "بیچنے والا",
    amount: "رقم (روپے)",
    status: "حالت/اسٹیٹس",
    role: "آپ کا کردار",
    type: "ڈیل کی قسم",
    category: "کیٹیگری",
    securingFunds: "امانتی رقم کی حفاظت",

    // Statuses
    PROPOSED: "مجوزہ / غیر منظور شدہ",
    FUNDED: "رقم جمع ہے (محفوظ)",
    SHIPPED: "سامان بھیج دیا گیا ہے",
    DELIVERED: "سامان مل چکا ہے",
    COMPLETED: "رقم ریلیز / مکمل ہو گئی",
    DISPUTED: "تنازعہ / شکایت درج ہے",
    CANCELLED: "منسوخ کر دیا گیا",

    // Action buttons
    depositFunds: "پیسے جمع کروائیں (ضمانت)",
    dispatchedGoods: "میں نے سامان بھیج دیا ہے",
    verifyDelivery: "مجھے سامان مل گیا (پیسے ریلیز کریں)",
    raiseDispute: "شکایت درج کریں (تنازعہ)",
    resolved: "فیصلہ ہو گیا ہے",

    // Fee Calculator
    feeCalculator: "ایسکرو فیس کیلکولیٹر (اندازہ)",
    feesCoveredPromo: "🎉 خوشخبری: پلیٹ فارم فیس فی الحال بالکل مفت (0٪) ہے!",
    calcAmount: "ڈیل کی کل رقم (روپے)",
    calcFeeSplit: "فیس کون ادا کرے گا؟",
    buyerPays: "صرف خریدار دے (100٪)",
    sellerPays: "صرف بیچنے والا دے (100٪)",
    split50: "آدھا آدھا (50 / 50)",
    escrowFee: "ایسکرو فیس (معیاری 1.5٪)",
    youPay: "خریدار کی کل ادائیگی",
    youReceive: "بیچنے والے کو ملنے والی رقم",
    actualPlatformFee: "سروس چارجز (پرومو ڈسکاؤنٹ: 0 روپے)",
    totalTaxWarn: "ذاتی خریدو فروخت کی ڈیلز پر کسی قسم کا ٹیکس لاگو نہیں ہوتا۔",

    // Bank transfer details
    localPaymentChannels: "پاکستانی ادائیگیاں (والٹس و بینک)",
    easyPaisa: "ایزی پیسہ والٹ",
    jazzCash: "جاز کیش والٹ",
    nayapay: "نیا پے ڈیجیٹل والٹ",
    sadapay: "سادہ پے کارڈ",
    meezan: "میزان بینک",
    hbl: "ایچ بی ایل بینک",
    ubl: "یو بی ایل بینک",
    alfalah: "بینک الفلاح",

    // Verification
    cnicVerification: "شناختی کارڈ نمبر ویریفکیشن",
    motherName: "والدہ کا نام",
    placeOfBirth: "پیدائش کا ضلع / شہر",
    verifyNow: "ویریفکیشن فارم جمع کروائیں",
    cnicScanTitle: "نادرہ کارڈ اسکینر"
  }
};

export function getTranslation(lang: Language) {
  return translations[lang] || translations['en'];
}

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Normalizes Pakistani phone numbers to a consistent format (+92XXXXXXXXXX)
 */
export function normalizePhoneNumber(phone: string): string {
  if (!phone || phone === 'Unknown') return '';
  // Remove all non-digit characters including spaces, dashes, etc.
  let digits = phone.replace(/\D/g, '');
  if (!digits) return '';
  
  // Pakistan specific logic
  if (digits.startsWith('0') && digits.length === 11) {
    return '+92' + digits.slice(1);
  }
  if (digits.startsWith('92') && digits.length === 12) {
    return '+' + digits;
  }
  if (digits.length === 10) {
    return '+92' + digits;
  }
  
  // For international or other formats, just ensure it has a +
  return phone.startsWith('+') ? phone.replace(/\s/g, '') : `+${digits}`;
}

/**
 * Returns a list of possible variations of a phone number to search in the database
 * for backward compatibility with un-normalized data.
 */
export function getPhoneVariations(phone: string): string[] {
  const normalized = normalizePhoneNumber(phone);
  const digits = phone.replace(/\D/g, '');
  
  const variations = new Set<string>();
  variations.add(normalized);
  variations.add(phone.trim());
  variations.add(digits);
  
  if (digits.length >= 10) {
    const last10 = digits.slice(-10);
    variations.add(`0${last10}`); // 03XXXXXXXXX
    variations.add(`92${last10}`); // 923XXXXXXXXX
    variations.add(`+92${last10}`); // +923XXXXXXXXX
  }

  return Array.from(variations).filter(v => v.length > 0);
}

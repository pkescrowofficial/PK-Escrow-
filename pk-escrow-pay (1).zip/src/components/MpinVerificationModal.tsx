import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, X, AlertCircle, Sparkles } from 'lucide-react';
import { getTranslation } from '../lib/translations';

interface MpinVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerifySuccess: () => Promise<void>;
  escrowAmount: number;
  itemDescription: string;
}

export function MpinVerificationModal({
  isOpen,
  onClose,
  onVerifySuccess,
  escrowAmount,
  itemDescription
}: MpinVerificationModalProps) {
  const { user, profile, lang } = useAuth();
  const t = getTranslation(lang);

  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  // Setup MPIN state in case user doesn't have one
  const [isSettingNewMpin, setIsSettingNewMpin] = useState<boolean>(false);
  const [newMpin, setNewMpin] = useState<string>('');
  const [confirmNewMpin, setConfirmNewMpin] = useState<string>('');
  
  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(null);
      setIsSubmitting(false);
      // If profile exists and doesn't have an mpin, we allow setting one of 4 digits
      if (profile && !profile.mpin) {
        setIsSettingNewMpin(true);
        setNewMpin('');
        setConfirmNewMpin('');
      } else {
        setIsSettingNewMpin(false);
      }
    }
  }, [isOpen, profile]);

  const handleKeyPress = (num: string) => {
    setError(null);
    if (isSettingNewMpin) {
      if (newMpin.length < 4) {
        setNewMpin(prev => prev + num);
      } else if (confirmNewMpin.length < 4) {
        setConfirmNewMpin(prev => prev + num);
      }
    } else {
      if (pin.length < 4) {
        setPin(prev => prev + num);
      }
    }
  };

  const handleBackspace = () => {
    setError(null);
    if (isSettingNewMpin) {
      if (confirmNewMpin.length > 0) {
        setConfirmNewMpin(prev => prev.slice(0, -1));
      } else if (newMpin.length > 0) {
        setNewMpin(prev => prev.slice(0, -1));
      }
    } else {
      if (pin.length > 0) {
        setPin(prev => prev.slice(0, -1));
      }
    }
  };

  const handleClear = () => {
    setError(null);
    if (isSettingNewMpin) {
      setNewMpin('');
      setConfirmNewMpin('');
    } else {
      setPin('');
    }
  };

  // Keyboard support for convenience
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key >= '0' && e.key <= '9') {
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'Enter') {
        handleVerifySubmit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, pin, isSettingNewMpin, newMpin, confirmNewMpin]);

  const handleSetupMpin = async () => {
    if (newMpin.length !== 4) {
      setError(lang === 'ur' ? 'برائے مہربانی 4 ہندسوں کا پن درج کریں' : 'Please choose a 4-digit MPIN.');
      return;
    }
    if (newMpin !== confirmNewMpin) {
      setError(lang === 'ur' ? 'درج کردہ پن آپس میں نہیں ملتے!' : 'MPIN choices do not match!');
      return;
    }

    setIsSubmitting(true);
    try {
      if (user?.uid) {
        await updateDoc(doc(db, 'users', user.uid), {
          mpin: newMpin
        });
        setIsSettingNewMpin(false);
        setError(null);
        setPin('');
      } else {
        throw new Error('User not logged in');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to register MPIN.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifySubmit = async () => {
    if (isSettingNewMpin) {
      await handleSetupMpin();
      return;
    }

    if (pin.length !== 4) {
      setError(lang === 'ur' ? 'برائے مہربانی پورا 4 ہندسوں کا سیکیورٹی پن درج کریں۔' : 'Please input a full 4-digit MPIN.');
      return;
    }

    const savedMpin = profile?.mpin;
    if (!savedMpin) {
      setError(lang === 'ur' ? 'سیکیورٹی پن ریکارڈ میں نہیں ملا۔ برائے مہربانی پہلے نیا پن بنائیں۔' : 'Security MPIN is not found in your profile records.');
      return;
    }

    if (pin !== savedMpin) {
      setError(lang === 'ur' ? 'غلط سیکیورٹی پن (MPIN)! دوبارہ کوشش کریں یا اپنے نجی سوالات سے ری سیٹ کریں۔' : 'Incorrect Security MPIN! Authorization rejected.');
      setPin('');
      return;
    }

    setIsSubmitting(true);
    try {
      await onVerifySuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authorization release failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isUrdu = lang === 'ur';

  // Modal Title & Label Translations
  const titleText = isUrdu ? 'ادائیگی جاری کرنے کی تصدیق' : 'Authorize Escrow Release';
  const subtitleText = isUrdu 
    ? 'محفوظ معاہدے کی رقم بیچنے والے کو منتقل کرنے کے لیے اپنا 4 ہندسوں کا سیکیورٹی پن درج کریں۔' 
    : 'Enter your 4-digit secure MPIN to immediately authorize the release of locked escrow funds directly to the seller\'s balance.';
  const amountToReleaseLabel = isUrdu ? 'ریلیز ہونے والی کل رقم:' : 'Transaction Amount to Release:';
  const itemLabel = isUrdu ? 'معاہدہ فارم / آئٹم:' : 'Secure Escrow Contract:';
  const setupTitle = isUrdu ? 'نیا سیکیورٹی پن (MPIN) بنائیں' : 'Setup Transaction Security MPIN';
  const setupSubtitle = isUrdu
    ? 'ادائیگیوں کو ریلیز کرنے اور نکالنے کی حفاظت کے لیے اپنا 4 ہندسوں کا سیکیورٹی امانتی پن بنائیں۔'
    : 'Before authorizing payouts, please choose a 4-digit transaction validation pin to secure future transfers.';
  const firstPinLabel = isUrdu ? 'نیا 4 ہندسوں کا پن درج کریں:' : 'Choose 4-Digit Security PIN:';
  const confirmPinLabel = isUrdu ? 'دوبارہ تصدیق کے لیے لکھیں:' : 'Confirm 4-Digit Security PIN:';
  const registerBtnLabel = isUrdu ? 'سیکیورٹی اکاؤنٹ فعال کریں' : 'Initialize Security Access & Continue';
  const mpinErrorText = isUrdu ? 'غلط سیکیورٹی امانتی پن (MPIN)' : 'Incorrect Security Authorization PIN';

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="mpin-verify-modal-overlay" className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md">
          <motion.div
            id="mpin-verify-modal-container"
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col border border-slate-100"
          >
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-indigo-950 text-white text-left">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-900/50 rounded-xl text-emerald-400 border border-indigo-800/60">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[8px] bg-emerald-500/25 text-emerald-300 px-2 py-0.5 rounded font-black tracking-widest uppercase block w-max border border-emerald-500/30">
                    {isUrdu ? 'امانتی سیکیورٹی' : 'SECURE VAULT AUTH'}
                  </span>
                  <h3 className="text-lg font-black tracking-tight mt-0.5">{isSettingNewMpin ? setupTitle : titleText}</h3>
                </div>
              </div>
              <button
                id="close-mpin-modal-btn"
                type="button"
                onClick={onClose}
                className="p-1 px-2.5 py-1.5 text-xs font-black text-slate-300 hover:text-white bg-slate-900/40 hover:bg-slate-900/60 transition-colors rounded-xl cursor-pointer"
              >
                {isUrdu ? 'بند کریں' : 'Cancel'}
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-5 text-left">
              {isSettingNewMpin ? (
                /* Registration Screen for missing MPIN */
                <div className="space-y-4">
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">
                    {setupSubtitle}
                  </p>

                  <div className="space-y-3.5 bg-slate-50 border border-slate-150 p-4 rounded-2xl">
                    <div className="space-y-1">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                        {firstPinLabel}
                      </span>
                      <div className="flex gap-2 justify-center py-1">
                        {[0, 1, 2, 3].map((idx) => (
                          <div
                            key={idx}
                            className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all duration-200 ${
                              newMpin.length > idx
                                ? 'bg-indigo-900 border-indigo-900 text-white shadow font-black'
                                : 'bg-white border-slate-200'
                            }`}
                          >
                            {newMpin.length > idx ? '⬤' : ''}
                          </div>
                        ))}
                      </div>
                    </div>

                    {newMpin.length === 4 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="space-y-1 pt-2 border-t border-slate-100"
                      >
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                          {confirmPinLabel}
                        </span>
                        <div className="flex gap-2 justify-center py-1">
                          {[0, 1, 2, 3].map((idx) => (
                            <div
                              key={idx}
                              className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all duration-200 ${
                                confirmNewMpin.length > idx
                                  ? 'bg-emerald-600 border-emerald-600 text-white shadow font-black'
                                  : 'bg-white border-slate-200'
                              }`}
                            >
                              {confirmNewMpin.length > idx ? '⬤' : ''}
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              ) : (
                /* Authorization Verification screen */
                <div className="space-y-4">
                  {/* Ledger Detail summary */}
                  <div className="bg-slate-50 border border-slate-150 p-4.5 rounded-2xl space-y-2.5">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{amountToReleaseLabel}</span>
                      <span className="text-sm font-black text-emerald-700 font-mono">Rs. {escrowAmount.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-slate-200/60 pt-2.5">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">{itemLabel}</span>
                      <span className="text-xs font-black text-slate-700 block truncate">{itemDescription}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-505 font-medium leading-relaxed">
                    {subtitleText}
                  </p>

                  {/* MPIN Visual Bubbles */}
                  <div className="flex justify-center items-center py-3">
                    <div className="flex gap-4">
                      {[0, 1, 2, 3].map((idx) => (
                        <div
                          key={idx}
                          className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all duration-200 ${
                            pin.length > idx
                              ? 'bg-slate-900 border-slate-900 shadow-md shadow-slate-900/10 text-white font-black'
                              : 'bg-white border-slate-200 text-slate-300'
                          }`}
                        >
                          {pin.length > idx ? (
                            <motion.span initial={{ scale: 0.6 }} animate={{ scale: 1 }}>⬤</motion.span>
                          ) : (
                            ''
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Error Warning Box */}
              {error && (
                <div className="bg-rose-50 border border-rose-100 p-3.5 rounded-xl flex items-start gap-2.5 text-rose-700 text-xs">
                  <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="font-bold flex-1">
                    <span>{error}</span>
                  </div>
                </div>
              )}

              {/* Secure Physical Dialpad */}
              <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4 grid grid-cols-3 gap-2.5 select-none touch-manipulation">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleKeyPress(num)}
                    className="h-12 bg-white hover:bg-indigo-50 border border-slate-200/80 hover:border-indigo-300 rounded-xl flex items-center justify-center text-base font-black text-slate-800 hover:text-indigo-900 transition-all active:scale-95 cursor-pointer shadow-sm"
                  >
                    {num}
                  </button>
                ))}
                
                <button
                  type="button"
                  onClick={handleClear}
                  className="h-12 bg-rose-50 hover:bg-rose-100 border border-rose-100 text-rose-600 rounded-xl flex items-center justify-center text-xs font-black transition-all active:scale-95 cursor-pointer"
                >
                  {isUrdu ? 'صاف کریں' : 'Clear'}
                </button>

                <button
                  type="button"
                  onClick={() => handleKeyPress('0')}
                  className="h-12 bg-white hover:bg-indigo-50 border border-slate-200/80 hover:border-indigo-300 rounded-xl flex items-center justify-center text-base font-black text-slate-800 hover:text-indigo-900 transition-all active:scale-95 cursor-pointer shadow-sm"
                >
                  0
                </button>

                <button
                  type="button"
                  onClick={handleBackspace}
                  className="h-12 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 rounded-xl flex items-center justify-center text-lg font-black transition-all active:scale-95 cursor-pointer"
                >
                  ⌫
                </button>
              </div>

              {/* Authorization Buttons */}
              <div className="pt-2">
                <button
                  id="mpin-vault-verify-btn"
                  type="button"
                  disabled={isSubmitting || (isSettingNewMpin ? newMpin.length !== 4 || confirmNewMpin.length !== 4 : pin.length !== 4)}
                  onClick={handleVerifySubmit}
                  className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white disabled:text-slate-400 font-black py-3.5 px-4 rounded-xl text-xs transition-all active:scale-98 shadow-lg shadow-emerald-600/10 disabled:shadow-none cursor-pointer"
                >
                  {isSubmitting ? (
                    <div className="w-4.5 h-4.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>{isSettingNewMpin ? registerBtnLabel : (isUrdu ? 'ادائیگی جاری کریں 💸' : 'Verify & Release Payout ✈️')}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

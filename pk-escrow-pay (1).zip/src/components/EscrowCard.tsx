import React, { useState, useEffect } from 'react';
import { doc, updateDoc, serverTimestamp, getDoc, setDoc, collection, addDoc, query, where, orderBy, onSnapshot, increment } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { StatusBadge, EscrowStatus } from './StatusBadge';
import { Package, ArrowRight, Wallet, CheckCircle2, AlertCircle, ShieldCheck, Truck, ThumbsUp, Building2, User as UserIcon, CreditCard, Clock, MessageSquare, Send, Paperclip, Image, Loader2, Sparkles, Star, ExternalLink, ChevronDown, ChevronUp, FileDown } from 'lucide-react';
import { motion } from 'motion/react';

import { useAuth } from '../hooks/useAuth';
import { DisputeModal } from './DisputeModal';
import { sendNotification } from '../lib/notifications';
import { TrustProfileModal } from './TrustProfileModal';
import { MpinVerificationModal } from './MpinVerificationModal';
import { generateReceiptPDF } from '../utils/receiptGenerator';
import { getQRBase64 } from '../utils/qrHelper';
import { compressImage } from '../lib/watermark';

export interface Escrow {
  id: string;
  buyerId: string;
  sellerId: string;
  amount: number;
  escrowFee?: number;
  totalAmount?: number;
  itemDescription: string;
  status: EscrowStatus;
  createdAt: any;
  buyerPhone: string;
  sellerPhone: string;
  initiatorId: string;
  dismissedBy?: string[];
  trackingId?: string;
  courier?: string;
  proofOfWorkLink?: string;
  proofOfWorkNote?: string;
  proofOfWorkSubmittedAt?: any;
  isChatOpen?: boolean;
  reviewedByBuyer?: boolean;
  reviewedBySeller?: boolean;
  isPhysical?: boolean;
  recipientName?: string;
  recipientPhone?: string;
  shippingCity?: string;
  shippingAddress?: string;
  transitStep?: number;
  type?: 'Digital_Asset';
  deliveryMode?: 'digital' | 'physical' | 'freelance' | 'digital_asset';
  assetType?: 'YouTube' | 'Facebook' | 'TikTok' | 'Gaming_ID';
  assetLoginCredentials?: string;
  escrowStatus?: 'Funds_Pending' | 'Funds_Secured' | 'Credentials_Delivered' | 'Under_Inspection' | 'Completed' | 'Disputed' | string;
  inspectionTimer?: string | null;
  projectDeadlines?: string;
  milestones?: string;
}

interface Message {
  id: string;
  senderId: string;
  senderPhone: string;
  text: string;
  proofUrl?: string;
  createdAt: any;
}

const getTimelineStep = (status: EscrowStatus) => {
  if (status === 'PROPOSED' || status === 'ACCEPTED') return 1;
  if (status === 'FUNDED') return 2;
  if (status === 'SHIPPED') return 3;
  if (status === 'DELIVERED') return 4;
  if (status === 'COMPLETED') return 5;
  return 1;
};

export const EscrowCard: React.FC<{ escrow: Escrow; isBuyer: boolean }> = ({ escrow, isBuyer }) => {
  const { user, setView, setActiveChatEscrowId, profile, lang } = useAuth();
  const isUrdu = lang === 'ur';
  const isDigitalAsset = escrow.type === 'Digital_Asset' || escrow.deliveryMode === 'digital_asset';
  const isVirtual = escrow.deliveryMode === 'digital' || escrow.deliveryMode === 'freelance' || escrow.deliveryMode === 'digital_asset' || escrow.type === 'Digital_Asset';
  const [isDisputeOpen, setIsDisputeOpen] = useState(false);
  const [isMpinOpen, setIsMpinOpen] = useState(false);
  const [counterparty, setCounterparty] = useState<any>(null);
  const [showBankInfo, setShowBankInfo] = useState(false);
  const [trackingIdInput, setTrackingIdInput] = useState('');
  const [courierInput, setCourierInput] = useState('TCS');
  const [proofLinkInput, setProofLinkInput] = useState('');
  const [proofNoteInput, setProofNoteInput] = useState('');
  const [isAddingTracking, setIsAddingTracking] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isPdfLoading, setIsPdfLoading] = useState(false);

  // Safepay integration state variables
  const [fundingMode, setFundingMode] = useState<'safepay' | 'p2p'>('safepay');
  const [safepayChoice, setSafepayChoice] = useState<'card' | 'wallet'>('card');
  const [safepayCardNumber, setSafepayCardNumber] = useState('');
  const [safepayCardExpiry, setSafepayCardExpiry] = useState('');
  const [safepayCardCvv, setSafepayCardCvv] = useState('');
  const [safepayCardName, setSafepayCardName] = useState('');
  const [safepayMobile, setSafepayMobile] = useState('');
  const [safepayWalletProvider, setSafepayWalletProvider] = useState<'easypaisa' | 'jazzcash'>('easypaisa');
  const [safepaySimulationStep, setSafepaySimulationStep] = useState<'idle' | 'init' | 'verifying' | 'processing' | 'success'>('idle');
  const [safepayStatusMsg, setSafepayStatusMsg] = useState('');

  // Shipping details custom editing states
  const [isEditingShipping, setIsEditingShipping] = useState(false);
  const [editRecipientName, setEditRecipientName] = useState(escrow.recipientName || '');
  const [editRecipientPhone, setEditRecipientPhone] = useState(escrow.recipientPhone || '');
  const [editShippingCity, setEditShippingCity] = useState(escrow.shippingCity || 'Karachi');
  const [editShippingAddress, setEditShippingAddress] = useState(escrow.shippingAddress || '');
  const [isSavingShipping, setIsSavingShipping] = useState(false);

  // Logistics simulation animation state
  const [isQueryingLogs, setIsQueryingLogs] = useState(false);
  const [showLogsDetails, setShowLogsDetails] = useState(false);
  const [isSimulatingTransit, setIsSimulatingTransit] = useState(false);

  // Trust Profiles states
  const [isTrustModalOpen, setIsTrustModalOpen] = useState(false);
  const [ratingStars, setRatingStars] = useState(5);
  const [ratingComment, setRatingComment] = useState('');
  const [selectedRatingTags, setSelectedRatingTags] = useState<string[]>([]);
  const [ratingSubmittedLocal, setRatingSubmittedLocal] = useState(false);
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);

  // checkout/funding modal states (SadaPay, JazzCash, Raast)
  const [isFundingOpen, setIsFundingOpen] = useState(false);
  const [selectedPayMethod, setSelectedPayMethod] = useState<'easypaisa' | 'jazzcash' | 'raast'>('easypaisa');
  const [payAccountNum, setPayAccountNum] = useState('');
  const [payTransactionId, setPayTransactionId] = useState('');
  const [paySenderAccount, setPaySenderAccount] = useState('');
  const [paySenderName, setPaySenderName] = useState('');
  const [payReceiptImage, setPayReceiptImage] = useState<string | null>(null);
  const [isSimulatingState, setIsSimulatingState] = useState(false);
  const [simulationStep, setSimulationStep] = useState(0);
  const [simulationError, setSimulationError] = useState('');

  const [copiedField, setCopiedField] = useState<string | null>(null);
  const handleCopyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 1500);
  };

  const [adminWalletData, setAdminWalletData] = useState<any>(null);

  useEffect(() => {
    const fetchAdminWallet = async () => {
      try {
        const snap = await getDoc(doc(db, 'users', 'admin_wallet'));
        if (snap.exists()) {
          setAdminWalletData(snap.data());
        }
      } catch (err) {
        console.warn("Failed fetching admin wallet for checkout display:", err);
      }
    };
    fetchAdminWallet();
  }, []);


  // Digital Asset Custom States & Verification Timers
  const [assetCredentialsInput, setAssetCredentialsInput] = useState('');
  const [assetBackupsInput, setAssetBackupsInput] = useState('');
  const [isSubmittingCredentials, setIsSubmittingCredentials] = useState(false);
  const [inspectionCountdown, setInspectionCountdown] = useState<string>('24:00:00');

  useEffect(() => {
    if (!escrow.inspectionTimer) return;

    const updateTimer = () => {
      const endTime = new Date(escrow.inspectionTimer!).getTime();
      const now = Date.now();
      const difference = endTime - now;

      if (difference <= 0) {
        setInspectionCountdown('EXPIRED / SECURED');
      } else {
        const hours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        const format = (num: number) => num < 10 ? `0${num}` : num;
        setInspectionCountdown(`${format(hours)}h ${format(minutes)}m ${format(seconds)}s`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [escrow.inspectionTimer]);

  // in-app chat states
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessageText, setNewMessageText] = useState('');
  const [isUploadingProof, setIsUploadingProof] = useState(false);

  const [chatLastSeen, setChatLastSeen] = useState<number>(() => {
    return Number(localStorage.getItem(`chat_last_seen_${escrow.id}`) || '0');
  });

  // Automatically update last seen time when-ever synchronized chat is active
  useEffect(() => {
    if (escrow.isChatOpen && messages.length > 0) {
      const latestTime = messages[messages.length - 1].createdAt;
      const timeMs = latestTime ? new Date(latestTime).getTime() : Date.now();
      setChatLastSeen(timeMs);
      localStorage.setItem(`chat_last_seen_${escrow.id}`, String(timeMs));
    }
  }, [escrow.isChatOpen, messages]);

  const hasUnread = messages.some(msg => {
    if (msg.senderId === user?.uid) return false;
    const msgTime = msg.createdAt ? new Date(msg.createdAt).getTime() : 0;
    return msgTime > chatLastSeen;
  });

  useEffect(() => {
    const fetchCounterparty = async () => {
      const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
      if (!targetId) return;
      
      try {
        const docRef = doc(db, 'users', targetId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setCounterparty(docSnap.data());
        }
      } catch (err) {
        console.error("Error fetching counterparty:", err);
      }
    };
    fetchCounterparty();
    
    if (profile) {
      setPaySenderName(profile.displayName || '');
      setPaySenderAccount(profile.phoneNumber || '');
    }
  }, [escrow.id, isBuyer, profile]);

  const handleDeliverCredentials = async () => {
    if (!assetCredentialsInput.trim() || !assetBackupsInput.trim()) {
      alert("Please fill in both the Login ID and password/backup details.");
      return;
    }
    setIsSubmittingCredentials(true);
    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      await updateDoc(escrowRef, {
        status: 'SHIPPED',
        escrowStatus: 'Credentials_Delivered',
        assetLoginCredentials: `${assetCredentialsInput.trim()} | ${assetBackupsInput.trim()}`,
        updatedAt: serverTimestamp()
      });
      await sendNotification(
        escrow.buyerId,
        '🔑 Login Credentials Delivered!',
        `Seller disclosed login details for your high-risk Digital Asset transaction. Begin the 24h inspection phase now!`,
        'SUCCESS',
        escrow.id
      ).catch(e => console.warn(e));
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingCredentials(false);
    }
  };

  const handleStartInspection = async () => {
    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      const timerVal = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      await updateDoc(escrowRef, {
        status: 'DELIVERED',
        escrowStatus: 'Under_Inspection',
        inspectionTimer: timerVal,
        updatedAt: serverTimestamp()
      });
      await sendNotification(
        escrow.sellerId,
        '⌛ Asset Inspection Initiated!',
        `Buyer initiated the 24-hour verification countdown timer for the digital account. Check logs.`,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));
    } catch (err) {
      console.error(err);
    }
  };

  const handleRaiseFraudAlert = async (reason: string) => {
    if (!reason.trim()) return;
    try {
      // 1. Create dispute record
      await setDoc(doc(db, 'disputes', escrow.id), {
        escrowId: escrow.id,
        reason: `FRAUD ALERT: ${reason.trim()}`,
        initiatorId: user?.uid,
        status: 'OPEN',
        evidence: [{
          userId: user?.uid,
          note: `Auto-logged: Fraud alert triggered. Reason: "${reason.trim()}"`,
          attachments: [],
          createdAt: new Date().toISOString()
        }],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      // 2. Update escrow state
      await updateStatus('DISPUTED', {
        escrowStatus: 'Disputed'
      });

      await sendNotification(
        escrow.sellerId,
        '🚨 Fraud Alert Raised! Deal Frozen!',
        `Buyer raised a fraud alert during inspection. Deal locked and sent to admin. Reason: "${reason.trim()}"`,
        'DANGER',
        escrow.id
      ).catch(e => console.warn(e));
    } catch (err) {
      console.error("Error raising fraud alert:", err);
    }
  };

  // Set up real-time listener for chat messages
  useEffect(() => {
    if (!escrow.id) return;

    const messagesQuery = query(
      collection(db, 'chat_messages'),
      where('escrowId', '==', escrow.id),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        msgs.push({
          id: doc.id,
          senderId: data.senderId,
          senderPhone: data.senderPhone,
          text: data.text,
          proofUrl: data.proofUrl,
          createdAt: data.createdAt
        });
      });
      setMessages(msgs);
    }, (err) => {
      console.warn("Firestore error fetching chat messages:", err);
      handleFirestoreError(err, OperationType.LIST, `chat_messages/${escrow.id}`);
    });

    return () => unsubscribe();
  }, [escrow.id]);

  const handleSendMessage = async (text: string, proofUrl: string = '') => {
    if (!user || (!text.trim() && !proofUrl)) return;
    try {
      await addDoc(collection(db, 'chat_messages'), {
        escrowId: escrow.id,
        senderId: user.uid,
        senderPhone: user.phoneNumber || 'User',
        text: text.trim(),
        proofUrl: proofUrl,
        createdAt: new Date().toISOString()
      });
      setNewMessageText('');

      // Send real-time notification to the counterparty about this chat message
      const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
      if (targetId) {
        const displaySender = isBuyer ? 'Buyer' : 'Seller';
        const formattedMsg = text.trim() ? (text.trim().length > 40 ? text.trim().slice(0, 40) + '...' : text.trim()) : 'Sent an attachment';
        await sendNotification(
          targetId,
          'New Chat Message 💬',
          `"${displaySender}" regarding "${escrow.itemDescription}": ${formattedMsg}`,
          'INFO',
          escrow.id
        ).catch(e => console.warn('Failed to send chat notification:', e));
      }
    } catch (err) {
      console.error("Error sending message:", err);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    
    setIsUploadingProof(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Url = reader.result as string;
      handleSendMessage(`📎 Uploaded Media Proof: ${file.name}`, base64Url);
      setIsUploadingProof(false);
    };
    reader.onerror = () => {
      console.error("Failed to read file");
      setIsUploadingProof(false);
    };
    reader.readAsDataURL(file);
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        try {
          const compressed = await compressImage(rawBase64, 900, 0.70);
          setPayReceiptImage(compressed);
        } catch (err) {
          console.error("Error compressing receipt screenshot:", err);
          setPayReceiptImage(rawBase64); // fallback
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitPaymentProof = async () => {
    if (!payTransactionId.trim()) {
      setSimulationError("Please enter the unique Transaction ID (TID) to authenticate the transfer.");
      return;
    }
    if (!paySenderAccount.trim()) {
      setSimulationError("Please enter your sending mobile number or bank account number so the seller can identify you.");
      return;
    }
    if (!payReceiptImage) {
      setSimulationError("Please upload a transaction receipt screenshot proof to proceed.");
      return;
    }
    setSimulationError('');
    setIsSimulatingState(true);
    setSimulationStep(1); // "Reading receipt details via fast scanner..."
    
    await new Promise(r => setTimeout(r, 500));
    setSimulationStep(2); // "Analyzing transaction ID & Amount..."
    
    await new Promise(r => setTimeout(r, 500));
    setSimulationStep(3); // "Verifying Recipient and bank account..."

    await new Promise(r => setTimeout(r, 400));

    const expectedRecipientAccount = selectedPayMethod === 'raast' ? '215400182600001' : '03054333292';
    const expectedRecipientName = 'PK ESCROW CENTRAL HOLDINGS';

    try {
      // Call our backend verify endpoint
      const response = await fetch('/api/verify-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: payReceiptImage,
          expectedTid: payTransactionId.trim(),
          expectedAmount: escrow.amount,
          expectedRecipientAccount,
          expectedRecipientName
        })
      });

      if (!response.ok) {
        throw new Error(`AI scanner returned HTTP code: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }

      const isMatched = data.verdict === 'MATCH' || data.verdict === 'PARTIAL_MATCH';

      if (isMatched) {
        setSimulationStep(4); // "Audit success! Securely holding funds & preparing deal room updates..."
        await new Promise(r => setTimeout(r, 1500));

        const paymentDetails = {
          method: selectedPayMethod,
          tid: payTransactionId.trim(),
          senderAccount: paySenderAccount.trim(),
          senderName: paySenderName.trim(),
          receiptImage: payReceiptImage || '',
          submittedAt: new Date().toISOString(),
          verifiedByAi: true,
          aiVerdict: data.verdict,
          aiAnalysis: data.analysis,
          detectedAmount: data.detectedAmount || escrow.amount,
          detectedTid: data.detectedTid || payTransactionId.trim()
        };

        // Transition to FUNDED, locked/held status immediately! (locks the funds automatically)
        await updateStatus('FUNDED', {
          isPaymentSubmitted: true,
          payment_status: 'held',
          receipt_url: payReceiptImage || '',
          paymentDetails: paymentDetails,
        });

        // Send automated secure notification to counterparty (Seller)
        await sendNotification(
          escrow.sellerId,
          'Payment AUTO-APPROVED! 🛡️',
          `Google AI automated review has approved the buyer's payment receipt of Rs. ${escrow.amount.toLocaleString()} (TID: ${payTransactionId.trim()}). Proceed to fulfill work!`,
          'SUCCESS',
          escrow.id
        ).catch(e => console.warn(e));

        // Send automated secure notification to buyer
        await sendNotification(
          escrow.buyerId,
          'Payment Auto-Approved! 🔒',
          `Your payment receipt of Rs. ${escrow.amount.toLocaleString()} (TID: ${payTransactionId.trim()}) has been verified and locked by AI.`,
          'SUCCESS',
          escrow.id
        ).catch(e => console.warn(e));

        // Send a system message to the deal room chat automatically!
        const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
        await addDoc(msgsCollection, {
          text: `🤖 AUTOMATED AI COMPLIANCE AUDIT PASSED!\n• Verdict: ${data.verdict} (${data.confidence?.toUpperCase() || 'HIGH'} Confidence)\n• Secured Hold Amount: Rs. ${(data.detectedAmount || escrow.amount).toLocaleString()}\n• Verified Reference TID: ${data.detectedTid || payTransactionId.trim()}\n• Recipient Matches Central Holdings: Yes ✓\n\n💬 AI ANALYSIS:\n${data.analysis}\n\n👉 SELLER: The funds are safely locked in secure holding. Please proceed to deliver the items/credentials directly to the buyer now!`,
          senderId: 'SYSTEM_BOT',
          senderName: 'Compliance Auditor',
          createdAt: new Date().toISOString()
        });

        setIsFundingOpen(false);
      } else {
        // Mismatch! Let's reject the receipt and notify the buyer on screen, plus alert in the chat
        const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
        await addDoc(msgsCollection, {
          text: `⚠️ AUTOMATED COMPLIANCE AUDIT WARNING:\n• Receipt uploaded by buyer failed AI audit requirements.\n• Verdict: ${data.verdict}\n\n💬 AI ANALYSIS RATIONALE:\n${data.analysis}\n\n👉 BUYER: Please check if you entered the correct TID, sent the correct amount Rs. ${escrow.amount.toLocaleString()} to our official central holding account, and uploaded the actual bank/mobile transfer receipt screenshot. You are allowed to correct your details and upload again.`,
          senderId: 'SYSTEM_BOT',
          senderName: 'Compliance Auditor',
          createdAt: new Date().toISOString()
        });

        setSimulationError(`❌ AI Auto-Verify Rejected: ${data.analysis}`);
      }

    } catch (e: any) {
      console.warn("AI OCR auto-audit failed or timed out. Graceful degradation to manual queue:", e);
      // Fallback: Transition to standard paid_pending_verification for administrator compliance review!
      const paymentDetails = {
        method: selectedPayMethod,
        tid: payTransactionId.trim(),
        senderAccount: paySenderAccount.trim(),
        senderName: paySenderName.trim(),
        receiptImage: payReceiptImage || '',
        submittedAt: new Date().toISOString(),
        verifiedByAi: false,
        fallbackError: e.message || 'Timeout'
      };

      await updateStatus('ACCEPTED', {
        isPaymentSubmitted: true,
        payment_status: 'paid_pending_verification',
        receipt_url: payReceiptImage || '',
        paymentDetails: paymentDetails,
      });

      // Send automated secure notification to counterparty (Seller)
      await sendNotification(
        escrow.sellerId,
        'Direct Deposit Submitted ⏳',
        `The buyer has submitted payment details of Rs. ${escrow.amount.toLocaleString()}. Awaiting admin compliance checking!`,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));

      // Send automated secure notification to buyer
      await sendNotification(
        escrow.buyerId,
        'Payment Submitted! ⏱️',
        `Your payment details for Rs. ${escrow.amount.toLocaleString()} have been submitted successfully. Compliance will verify and hold the funds shortly.`,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));

      // Send a system message to the deal room chat automatically!
      const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
      await addDoc(msgsCollection, {
        text: `📢 SYSTEM: Buyer has uploaded direct payment proof of Rs. ${escrow.amount.toLocaleString()}!\n• Method: ${selectedPayMethod.toUpperCase()}\n• Sender Name/Account: ${paySenderName.trim()} (${paySenderAccount.trim()})\n• Transaction ID (TID): ${payTransactionId.trim()}\n• Status: AI scan timed out. Routed to manual ledger checking.\n👉 ADMIN / SELLER: Please await admin manual approval. Verification auditor will cross-reference internal statement register shortly to activate HELD status.`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString(),
        mediaUrl: payReceiptImage || null
      });

      setIsFundingOpen(false);
    } finally {
      setIsSimulatingState(false);
      setSimulationStep(0);
    }
  };

  const handleSafepayEscrowSubmit = async () => {
    if (!user) return;
    setSimulationError('');
    setIsSimulatingState(true);
    setSafepaySimulationStep('init');
    setSafepayStatusMsg(lang === 'ur' ? 'سیکیور کنکشن قائم کیا جا رہا ہے...' : 'Establishing secure handshakes with getsafepay.co/checkout...');

    await new Promise(r => setTimeout(r, 1200));

    setSafepaySimulationStep('verifying');
    setSafepayStatusMsg(lang === 'ur' ? 'بلنگ پیرامیٹر اور کی سائنچر کی تصدیق ہو رہی ہے...' : 'Authenticating merchant merchant_id api_key and integrity checksum...');

    await new Promise(r => setTimeout(r, 1200));

    setSafepaySimulationStep('processing');
    setSafepayStatusMsg(lang === 'ur' ? 'بینک آف پاکستان کے محفوظ لیجر میں رقم جمع ہو رہی ہے...' : 'Routing tokenized checkout payload directly to interbank RAAST consensus ledger...');

    await new Promise(r => setTimeout(r, 1500));

    const mockTid = 'SP-' + Math.floor(100000000 + Math.random() * 900000000);
    const paymentDetails = {
      method: 'safepay',
      tid: mockTid,
      senderAccount: safepayChoice === 'card' ? `ending in ${safepayCardNumber.slice(-4) || '4242'}` : (safepayMobile || '03000000000'),
      senderName: safepayChoice === 'card' ? (safepayCardName || 'Dev Sandbox Card') : (profile?.displayName || 'Merchant Partner'),
      submittedAt: new Date().toISOString()
    };

    try {
      // Transition directly to FUNDED status!
      await updateStatus('FUNDED', {
        isPaymentSubmitted: false, // Clear submission block
        paymentApprovedAt: new Date().toISOString(),
        paymentDetails: paymentDetails
      });

      // Show instant payment toast notification
      await sendNotification(
        escrow.buyerId,
        'Safepay Instant Payment Approved ✅',
        `Rs. ${escrow.amount.toLocaleString()} has been charged successfully via Safepay (TID: ${mockTid}). Deal funded.`,
        'INFO',
        escrow.id
      ).catch(e => console.warn('Failed self-notification:', e));

      await sendNotification(
        escrow.sellerId,
        'Instant Safepay Funding Approved 💸',
        `The buyer has funded the trade of Rs. ${escrow.amount.toLocaleString()} instantly via Safepay. Escrow is secured. Please ship!`,
        'SUCCESS',
        escrow.id
      ).catch(e => console.warn(e));

      // Send a system message to the deal room chat automatically!
      const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
      await addDoc(msgsCollection, {
        text: `🟢 SYSTEM: Safepay Instant Payment Gateway approved Rs. ${escrow.amount.toLocaleString()}!\n• Method: Safepay Sandbox (${safepayChoice.toUpperCase()})\n• Transaction ID: ${mockTid}\n• Status: Escrow Funds Locked & Secured in Trust Registry.\n👉 SELLER: Please proceed with shipping, credential delivery, or transfer now!`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString()
      });

      setSafepaySimulationStep('success');
      setSafepayStatusMsg(lang === 'ur' ? 'ادائیگی کامیابی سے مکمل ہو گئی ہے!' : 'Checkout payment successfully authorized and credited!');
      
      setTimeout(() => {
        setIsFundingOpen(false);
        setSafepaySimulationStep('idle');
        setIsSimulatingState(false);
      }, 2500);

    } catch (err: any) {
      setSimulationError(err.message || 'An error occurred during Safepay sandbox execution.');
      setSafepaySimulationStep('idle');
      setIsSimulatingState(false);
    }
  };

  const handleApprovePaymentReceipt = async () => {
    setIsSimulatingState(true);
    setSimulationStep(1); // "Verifying bank statement deposit clearance..."
    
    await new Promise(r => setTimeout(r, 1200));
    setSimulationStep(2); // "Locking cash reserve in PK Escrow secure vault..."
    
    await new Promise(r => setTimeout(r, 1000));

    try {
      // Transition to FUNDED status
      await updateStatus('FUNDED', {
        isPaymentSubmitted: false, // Clear submission block
        paymentApprovedAt: new Date().toISOString()
      });

      // Send system message to the chat
      const msgsCollection = collection(db, 'escrows', escrow.id, 'messages');
      await addDoc(msgsCollection, {
        text: `✅ SYSTEM: Seller has successfully VERIFIED and CONFIRMED receipt of funds on their physical account! Rs. ${escrow.amount.toLocaleString()} is now 100% locked and secured in the escrow trust registry. Seller should proceed with shipping / delivery!`,
        senderId: 'SYSTEM_BOT',
        senderName: 'PK Escrow Bot',
        createdAt: new Date().toISOString()
      });

    } catch (e: any) {
      console.error("Approval error:", e);
    } finally {
      setIsSimulatingState(false);
      setIsFundingOpen(false);
      setSimulationStep(0);
    }
  };

  const handleSubmitReview = async () => {
    if (!user) return;
    setIsSubmittingRating(true);
    const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
    if (!targetId) {
      setIsSubmittingRating(false);
      return;
    }

    try {
      // 1. Save review doc in /reviews
      await addDoc(collection(db, 'reviews'), {
        escrowId: escrow.id,
        reviewerId: user.uid,
        reviewerPhone: profile?.phoneNumber || user.phoneNumber || 'Member',
        reviewerName: profile?.displayName || 'P2P Member',
        targetId: targetId,
        rating: ratingStars,
        comment: ratingComment.trim(),
        tags: selectedRatingTags,
        createdAt: new Date().toISOString()
      });

      // 2. Update counterparty stats in /users/{targetId}
      const targetUserRef = doc(db, 'users', targetId);
      await updateDoc(targetUserRef, {
        completedDeals: increment(1),
        ratingSum: increment(ratingStars),
        ratingCount: increment(1)
      }).catch(err => console.warn("Failed to increment user stats:", err));

      // 3. Mark reviewed on the escrow doc (sync to both parties)
      const escrowRef = doc(db, 'escrows', escrow.id);
      const updateFields = isBuyer ? { reviewedByBuyer: true } : { reviewedBySeller: true };
      await updateDoc(escrowRef, updateFields);

      // Send notification to target users
      await sendNotification(
        targetId,
        'Rating Received ⭐',
        `${profile?.displayName || 'Counterparty'} rated your service ${ratingStars}★ on PK Escrow!`,
        'SUCCESS',
        escrow.id
      ).catch(e => console.warn(e));

      setRatingSubmittedLocal(true);
    } catch (err) {
      console.error("Error setting trust rating review:", err);
    } finally {
      setIsSubmittingRating(false);
    }
  };

  const handleSaveShippingDetails = async () => {
    if (!user) return;
    if (!editRecipientName.trim() || !editShippingAddress.trim()) return;
    setIsSavingShipping(true);
    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      await updateDoc(escrowRef, {
        isPhysical: true,
        recipientName: editRecipientName.trim(),
        recipientPhone: editRecipientPhone.trim(),
        shippingCity: editShippingCity,
        shippingAddress: editShippingAddress.trim()
      });
      setIsEditingShipping(false);
    } catch (err) {
      console.error("Error saving shipping details to card:", err);
    } finally {
      setIsSavingShipping(false);
    }
  };

  const handleSimulateTransitStep = async () => {
    if (!user) return;
    setIsSimulatingTransit(true);
    
    // Ensure we trigger a neat fake loading query if they want to load checkpoints
    setIsQueryingLogs(true);
    setTimeout(() => {
      setIsQueryingLogs(false);
    }, 1250);

    const nextStep = (escrow.transitStep !== undefined ? escrow.transitStep : 0) + 1;
    if (nextStep > 4) {
      setIsSimulatingTransit(false);
      return;
    }

    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      const updates: any = { transitStep: nextStep };
      
      let customMsg = '';
      if (nextStep === 1) {
        customMsg = `🚚 Courier Hub sorted: Your parcel has successfully left the Karachi Logistics Sort Facility.`;
      } else if (nextStep === 2) {
        customMsg = `✈️ Cargo Gateway: Transit hub processed scanning scan in ${escrow.shippingCity || 'Lahore'} Cargo Base.`;
      } else if (nextStep === 3) {
        customMsg = `🏍️ Out For Delivery: Local Rider #48 (Mobile 0305-XXXXXXX) has dispatched your parcel in ${escrow.shippingCity || 'Lahore'} Cantt.`;
      } else if (nextStep === 4) {
        updates.status = 'DELIVERED';
        customMsg = `✅ Delivered: Handover confirmed! Parcel signed by ${escrow.recipientName || 'Buyer'}. Please release the funds.`;
      }

      await updateDoc(escrowRef, updates);

      // Notify buyer & seller
      await sendNotification(
        escrow.buyerId,
        '🚚 Courier Logistics Update',
        customMsg,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));

      await sendNotification(
        escrow.sellerId,
        '🚚 Courier Logistics Update',
        customMsg,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));

    } catch (err) {
      console.error("Error simulating logistics step:", err);
    } finally {
      setIsSimulatingTransit(false);
    }
  };

  const handleInstantDeliver = async () => {
    if (!user) return;
    setIsSimulatingTransit(true);
    setIsQueryingLogs(true);
    setTimeout(() => {
      setIsQueryingLogs(false);
    }, 800);

    try {
      const escrowRef = doc(db, 'escrows', escrow.id);
      const updates: any = { 
        transitStep: 4,
        status: 'DELIVERED'
      };
      await updateDoc(escrowRef, updates);

      const customMsg = `✅ Delivered: Fast-track Handover confirmed! Parcel signed by ${escrow.recipientName || 'Buyer'}. Please release the funds.`;

      await sendNotification(
        escrow.buyerId,
        '🚚 Courier Logistics Update',
        customMsg,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));

      await sendNotification(
        escrow.sellerId,
        '🚚 Courier Logistics Update',
        customMsg,
        'INFO',
        escrow.id
      ).catch(e => console.warn(e));
    } catch (err) {
      console.error("Error initiating instant delivery:", err);
    } finally {
      setIsSimulatingTransit(false);
    }
  };

  const updateStatus = async (newStatus: EscrowStatus, extraFields: any = {}) => {
    if (!user) return;
    const escrowRef = doc(db, 'escrows', escrow.id);
    const timestampField = newStatus === 'FUNDED' ? 'fundedAt' : 
                         newStatus === 'SHIPPED' ? 'shippedAt' :
                         newStatus === 'DELIVERED' ? 'deliveredAt' : 
                         newStatus === 'COMPLETED' ? 'completedAt' : 'updatedAt';
    
    // Auto-map Digital Asset sub-stages
    const isDigitalAsset = escrow.type === 'Digital_Asset' || escrow.deliveryMode === 'digital_asset';
    let digitalAssetFields: any = {};
    if (isDigitalAsset) {
      if (newStatus === 'FUNDED') {
        digitalAssetFields.escrowStatus = 'Funds_Secured';
      } else if (newStatus === 'SHIPPED') {
        digitalAssetFields.escrowStatus = 'Credentials_Delivered';
      } else if (newStatus === 'DELIVERED') {
        digitalAssetFields.escrowStatus = 'Under_Inspection';
      } else if (newStatus === 'COMPLETED') {
        digitalAssetFields.escrowStatus = 'Completed';
      } else if (newStatus === 'DISPUTED') {
        digitalAssetFields.escrowStatus = 'Disputed';
      }
    }

    try {
      const isCompleted = newStatus === 'COMPLETED';
      await updateDoc(escrowRef, {
        status: newStatus,
        updatedAt: serverTimestamp(),
        [timestampField]: serverTimestamp(),
        ...(isCompleted ? { payment_status: 'released' } : {}),
        ...digitalAssetFields,
        ...extraFields
      });

      // Release money: Increment seller's active wallet balance (applying 1% platform commission) & completed deals
      if (newStatus === 'COMPLETED') {
        const commissionRate = 0.01;
        const commission = Math.round(escrow.amount * commissionRate);
        const netSellerPayout = escrow.amount - commission;

        const sellerRef = doc(db, 'users', escrow.sellerId);
        await updateDoc(sellerRef, {
          balance: increment(netSellerPayout),
          completedDeals: increment(1)
        }).catch(err => console.warn('Failed to increment seller balance on release:', err));

        // Credit to Admin's wallet
        const adminUserRef = doc(db, 'users', 'admin_wallet');
        const adminSnap = await getDoc(adminUserRef).catch(() => null);
        if (adminSnap && adminSnap.exists()) {
          await updateDoc(adminUserRef, {
            balance: increment(commission),
            updatedAt: serverTimestamp()
          }).catch(err => console.warn('Failed to increment admin balance:', err));
        } else {
          await setDoc(adminUserRef, {
            displayName: 'PK Escrow Admin (Platform)',
            phoneNumber: '+923000000001',
            balance: commission,
            isAdmin: true,
            onboardingStatus: 'APPROVED',
            isVerified: true,
            createdAt: serverTimestamp()
          }).catch(err => console.warn('Failed to set admin balance:', err));
        }
      }

      // Send automated notification to the counterparty
      const targetId = isBuyer ? escrow.sellerId : escrow.buyerId;
      if (targetId) {
        let notifTitle = '';
        let notifMsg = '';
        let notifType: 'INFO' | 'SUCCESS' | 'WARNING' | 'DANGER' = 'INFO';

        const formattedAmount = escrow.amount.toLocaleString();
        const shortDesc = escrow.itemDescription.length > 30 
          ? escrow.itemDescription.slice(0, 30) + '...' 
          : escrow.itemDescription;

        switch (newStatus) {
          case 'ACCEPTED':
            notifTitle = 'Contract Approved 🤝';
            notifMsg = `The seller has accepted your proposed contract of Rs. ${formattedAmount} for: "${shortDesc}".`;
            notifType = 'SUCCESS';
            break;
          case 'FUNDED':
            notifTitle = 'Secure Funds Deposited 🔒';
            notifMsg = `The buyer deposited Rs. ${formattedAmount} into secure holdings. You can safely ship or deliver the work.`;
            notifType = 'SUCCESS';
            break;
          case 'SHIPPED':
            notifTitle = 'Work/Logistics Dispatched 🚚';
            notifMsg = `The seller has shipped the package via ${extraFields.courier || 'courier'} (Tracking: ${extraFields.trackingId || 'N/A'}). Check proof details!`;
            notifType = 'INFO';
            break;
          case 'DELIVERED':
            if (isBuyer) {
              notifTitle = 'Goods Received ✔';
              notifMsg = `The buyer acknowledged delivery of your package (Rs. ${formattedAmount}).`;
              notifType = 'SUCCESS';
            } else {
              notifTitle = 'Task Marked Delivered 📍';
              notifMsg = `The seller marked the contract for "${shortDesc}" as successfully delivered. Please confirm or release payout.`;
              notifType = 'WARNING';
            }
            break;
          case 'COMPLETED':
            notifTitle = 'Escrow Payment Released 💸';
            notifMsg = `The buyer approved your deliverables & released Rs. ${formattedAmount} directly to your wallet account.`;
            notifType = 'SUCCESS';
            break;
          case 'DISPUTED':
            notifTitle = 'Dispute Opened ⚠️';
            notifMsg = `A formal dispute dispute has been filed regarding contract "${shortDesc}". PK Escrow arbitration panel is reviewing the evidence.`;
            notifType = 'DANGER';
            break;
          case 'CANCELLED':
            notifTitle = 'Contract Cancelled ❌';
            notifMsg = `The contract for "${shortDesc}" was cancelled and funds have been processed.`;
            notifType = 'INFO';
            break;
          default:
            notifTitle = `Status Updated: ${newStatus}`;
            notifMsg = `The contract for "${shortDesc}" progressed to ${newStatus}.`;
            notifType = 'INFO';
        }

        if (notifTitle && notifMsg) {
          await sendNotification(targetId, notifTitle, notifMsg, notifType, escrow.id)
            .catch(e => console.warn('Notification delivery failed:', e));
        }
      }
    } catch (err) {
      console.error("Firestore Error:", err);
    }
  };


  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 p-2">
         <ShieldCheck className="w-12 h-12 text-emerald-600 opacity-10 group-hover:opacity-20 transition-opacity" />
      </div>

      {/* ALWAYS VISIBLE HEADER */}
      <div className={`flex flex-col md:flex-row justify-between md:items-center gap-4 ${isExpanded ? 'border-b border-slate-100 pb-5 mb-5' : ''}`}>
        <div className="flex-1 space-y-2 text-left">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={escrow.status} />
            {isVirtual && (
              <span className="inline-flex items-center gap-1 text-[9px] bg-indigo-50 text-indigo-700 border border-indigo-100/60 font-black px-2 py-0.5 rounded-lg uppercase tracking-tight">
                💻 Digital Asset
              </span>
            )}
            {!isVirtual && escrow.isPhysical && (
              <span className="inline-flex items-center gap-1 text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-100/60 font-black px-2 py-0.5 rounded-lg uppercase tracking-tight">
                📦 Physical Goods
              </span>
            )}
            {escrow.deliveryMode === 'freelance' && (
              <span className="inline-flex items-center gap-1 text-[9px] bg-rose-50 text-rose-700 border border-rose-100/60 font-black px-2 py-0.5 rounded-lg uppercase tracking-tight animate-pulse">
                ⚡ Freelance Service Contract
              </span>
            )}
          </div>
          
          <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
            {escrow.itemDescription}
          </h3>
        </div>

        <div className="flex items-center justify-between md:justify-end gap-5 shrink-0 border-t md:border-t-0 border-slate-100 pt-3 md:pt-0">
          <div className="text-left md:text-right shrink-0">
            <p className="text-[10px] font-black text-slate-400 tracking-widest leading-none mb-1">SECURE AMOUNT</p>
            <p className="text-lg sm:text-2xl font-black text-emerald-600 tracking-tight leading-none font-sans">
              Rs. {escrow.amount.toLocaleString()}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="inline-flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100/80 text-slate-705 border border-slate-250 hover:border-slate-350 font-black px-4 py-2 rounded-xl text-xs cursor-pointer shadow-sm active:scale-95 transition-all select-none h-10 shrink-0"
          >
            <span>{isExpanded ? 'Collapse' : 'Expand Details'}</span>
            {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-600" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="space-y-6 animate-fade-in text-left">
          {/* Freelance Deadlines and Milestones if present */}
          {(escrow.deliveryMode === 'freelance' || escrow.itemDescription.startsWith('Project Deadline:')) && (
            <div className="p-4 bg-slate-50/55 border border-slate-200/80 rounded-2xl space-y-3">
              <div className="flex items-center gap-1.5 font-bold text-[9px] uppercase tracking-wider text-rose-700 bg-rose-50 border border-rose-100/60 px-2.5 py-1 rounded-lg w-auto max-w-max">
                ⚡ Freelance Service Parameters
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                <div>
                  <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Project Deadlines / Delivery Duration</span>
                  <p className="text-xs font-black text-slate-800 bg-white border border-slate-200/80 p-2.5 rounded-xl">{escrow.projectDeadlines || (escrow.itemDescription.match(/Project Deadline:\s*([^\n]+)/)?.[1] || "N/A")}</p>
                </div>
                <div>
                  <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Milestones & Requirements</span>
                  <div className="text-xs font-medium text-slate-700 bg-white border border-slate-200/80 p-2.5 rounded-xl whitespace-pre-wrap leading-relaxed">
                    {escrow.milestones || (escrow.itemDescription.includes('Milestones:') ? escrow.itemDescription.split('Milestones:')[1]?.trim() : escrow.itemDescription) || "N/A"}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Core Info Boxes (Counterparty & Finances) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Counterparty & Trust Details Card */}
            <div className="bg-slate-50/60 border border-slate-200/70 p-4 rounded-2xl space-y-3 flex flex-col justify-between">
              <div>
                <p className="text-[10px] font-black text-slate-405 uppercase tracking-widest">Trade Participant Details</p>
                <div className="flex items-center justify-between mt-2.5">
                  <div className="space-y-0.5">
                    <p className="text-xs font-black text-slate-400 uppercase tracking-widest text-[9px]">
                      {isBuyer ? 'SELLER IDENTITY' : 'BUYER IDENTITY'}
                    </p>
                    <p className="text-sm font-black text-slate-800 tracking-tight">
                      {counterparty?.displayName || 'Offline User'}
                    </p>
                    <p className="text-[10px] text-slate-500 font-mono font-bold">
                      ID/Phone: {isBuyer ? escrow.sellerPhone : escrow.buyerPhone}
                    </p>
                  </div>

                  {counterparty && (
                    <button 
                      type="button"
                      onClick={() => setIsTrustModalOpen(true)}
                      className="inline-flex items-center gap-1.5 text-[10px] bg-amber-500/10 text-amber-700 px-2.5 py-1.5 rounded-xl font-black hover:bg-amber-500/15 cursor-pointer whitespace-nowrap"
                    >
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      <span>{counterparty.ratingCount > 0 ? parseFloat((counterparty.ratingSum / counterparty.ratingCount).toFixed(1)) : '5.0'}★ ({counterparty.completedDeals || 0} Trades)</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-200/60 pt-2.5 flex justify-between items-center">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">System Status Check: OK</span>
                <button
                  type="button"
                  onClick={() => setIsTrustModalOpen(true)}
                  className="text-[10px] text-indigo-600 hover:text-indigo-800 font-extrabold uppercase hover:underline cursor-pointer flex items-center gap-1"
                >
                  View Trust Profile 🛡️
                </button>
              </div>
            </div>

            {/* Financial Ledger & Records Card */}
            <div className="bg-slate-50/60 border border-slate-200/70 p-4 rounded-2xl space-y-3">
              <div className="flex justify-between items-center border-b border-slate-200/55 pb-2">
                <span className="text-[10px] font-black text-slate-405 uppercase tracking-widest">Financial Vault Record</span>
                <span className="text-[9px] font-mono text-slate-455 font-bold">TX: {escrow.id.slice(0, 8).toUpperCase()}</span>
              </div>

              {(() => {
                const sub = escrow.amount;
                const fee = escrow.escrowFee !== undefined ? escrow.escrowFee : 0;
                const total = escrow.totalAmount !== undefined ? escrow.totalAmount : sub;
                return (
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Subtotal amount:</span>
                      <span>Rs. {sub.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-xs text-emerald-600 font-bold">
                      <span>Escrow fee (Promo 0%):</span>
                      <span>{fee > 0 ? `Rs. ${fee.toLocaleString()}` : 'FREE'}</span>
                    </div>
                    <div className="flex justify-between text-sm text-slate-900 font-black border-t border-slate-200/60 pt-1.5">
                      <span>Total Secure Balance:</span>
                      <span>Rs. {total.toLocaleString()}</span>
                    </div>
                  </div>
                );
              })()}

              <div className="pt-1.5 text-right font-sans">
                {escrow.createdAt && (
                  <p className="text-[9px] text-slate-400 font-bold">
                    Registered at:{' '}
                    {(() => {
                       const dateObj = escrow.createdAt.seconds ? new Date(escrow.createdAt.seconds * 1000) : new Date(escrow.createdAt);
                       if (isNaN(dateObj.getTime())) return 'Pending...';
                       return dateObj.toLocaleString('en-PK', { 
                         timeZone: 'Asia/Karachi',
                         day: '2-digit', 
                         month: 'short', 
                         year: 'numeric',
                         hour: '2-digit', 
                         minute: '2-digit', 
                         hour12: true 
                       }) + ' (PKT)';
                    })()}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200/50">
                <button
                  type="button"
                  disabled={isPdfLoading}
                  onClick={async () => {
                    setIsPdfLoading(true);
                    try {
                      const verifyLink = `${window.location.origin}/?verify=${escrow.id}`;
                      const qrDataUrl = await getQRBase64(verifyLink);
                      const pdf = generateReceiptPDF(escrow, isBuyer, counterparty?.displayName || 'Offline Participant', qrDataUrl);
                      const rawName = escrow.itemDescription ? escrow.itemDescription.trim() : 'Secured_Receipt';
                      const sanitized = rawName.replace(/[/\\?%*:|"<>]/g, '-').replace(/\s+/g, '_').trim();
                      const shortId = escrow.id ? escrow.id.substring(0, 6).toUpperCase() : 'RC';
                      const safeName = `${sanitized}_ID_${shortId}`;
                      pdf.save(`${safeName}.pdf`);
                    } catch (err) {
                      console.error('Error compiling QR-PDF receipt:', err);
                    } finally {
                      setIsPdfLoading(false);
                    }
                  }}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-xl text-xs font-black select-none cursor-pointer transition-all active:scale-[0.98]"
                >
                  {isPdfLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 animate-spin" />
                      <span>Securing PDF QR Code...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Download Secure Receipt (PDF)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

      {/* Visual Timeline Tracking */}
      {(() => {
        const isDigitalAsset = escrow.type === 'Digital_Asset' || escrow.deliveryMode === 'digital_asset';
        if (isDigitalAsset) {
          let assetStep = 1;
          const escStatus = escrow.escrowStatus || 'Funds_Pending';
          if (escStatus === 'Funds_Secured') assetStep = 2;
          else if (escStatus === 'Credentials_Delivered') assetStep = 3;
          else if (escStatus === 'Under_Inspection') assetStep = 4;
          else if (escStatus === 'Completed' || escrow.status === 'COMPLETED') assetStep = 5;
          else if (escStatus === 'Disputed' || escrow.status === 'DISPUTED') assetStep = 5;

          return (
            <div className="mb-6 bg-slate-50 border border-slate-200/60 rounded-3xl p-5 shadow-inner">
              <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-4 px-0.5 flex justify-between">
                <span>⚡ Digital Asset Phase Tracker ({escrow.assetType || 'Account'})</span>
                <span className="text-amber-700 font-extrabold font-mono text-[10px]">PHASE {assetStep}/5</span>
              </p>
              <div className="relative flex items-center justify-between px-2">
                <div className="absolute left-6 right-6 top-[14px] -translate-y-1/2 h-1 bg-slate-200 z-0 rounded" />
                <div 
                  className="absolute left-6 top-[14px] -translate-y-1/2 h-1 bg-amber-500 z-0 transition-all duration-500 rounded" 
                  style={{ width: `calc(${((assetStep - 1) / 4) * 100}% - 12px)` }}
                />
                {[
                  { step: 1, label: 'Deposit', desc: 'Pending' },
                  { step: 2, label: 'Vaulted', desc: 'Secure' },
                  { step: 3, label: 'Delivered', desc: 'Logins Out' },
                  { step: 4, label: 'Inspect', desc: '24h Timer' },
                  { step: 5, label: 'Completed', desc: 'Disbursed' }
                ].map((s) => {
                  const isActive = s.step <= assetStep;
                  const isCurrent = s.step === assetStep;
                  return (
                    <div key={s.step} className="flex flex-col items-center z-13 relative select-none">
                      <div 
                        className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                          isCurrent 
                            ? 'bg-amber-650 text-white ring-4 ring-amber-100 scale-110 shadow-md shadow-amber-600/20' 
                            : isActive 
                            ? 'bg-amber-500 text-white' 
                            : 'bg-white text-slate-400 border-2 border-slate-200'
                        }`}
                      >
                        {isActive ? (
                          <CheckCircle2 className="w-4 h-4 font-black" />
                        ) : (
                          <span className="text-xs font-black">{s.step}</span>
                        )}
                      </div>
                      <span className={`text-[9px] sm:text-[10px] font-extrabold mt-2 uppercase tracking-tight ${isCurrent ? 'text-amber-600 font-black' : isActive ? 'text-slate-800' : 'text-slate-400'}`}>
                        {s.label}
                      </span>
                      <span className="text-[8px] font-bold text-slate-400 hidden sm:block mt-0.5">
                        {s.desc}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        }

        if (getTimelineStep(escrow.status) > 0) {
          return (
            <div className="mb-6 bg-slate-50 border border-slate-200/60 rounded-3xl p-5 shadow-inner">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 px-0.5 flex justify-between">
                <span>Progress & Status Tracking</span>
                <span className="text-emerald-600 font-extrabold font-mono text-[10px]">STEP {getTimelineStep(escrow.status)}/5</span>
              </p>
              <div className="relative flex items-center justify-between px-2">
                {/* Background Line */}
                <div className="absolute left-6 right-6 top-[14px] -translate-y-1/2 h-1 bg-slate-200 z-0 rounded" />
                
                {/* Active Progress Line */}
                <div 
                  className="absolute left-6 top-[14px] -translate-y-1/2 h-1 bg-emerald-500 z-0 transition-all duration-500 rounded" 
                  style={{ width: `calc(${((getTimelineStep(escrow.status) - 1) / 4) * 100}% - 12px)` }}
                />

                {[
                  { step: 1, label: 'Proposed', desc: 'Deal Set' },
                  { step: 2, label: 'Funded', desc: 'Locked' },
                  { step: 3, label: 'Shipped', desc: 'In Transit' },
                  { step: 4, label: 'Delivered', desc: 'Received' },
                  { step: 5, label: 'Completed', desc: 'Paid Out' }
                ].map((s) => {
                  const isActive = s.step <= getTimelineStep(escrow.status);
                  const isCurrent = s.step === getTimelineStep(escrow.status);
                  return (
                    <div key={s.step} className="flex flex-col items-center z-13 relative select-none">
                      <div 
                        className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                          isCurrent 
                            ? 'bg-indigo-600 text-white ring-4 ring-indigo-100 scale-110 shadow-md shadow-indigo-600/20' 
                            : isActive 
                            ? 'bg-emerald-500 text-white' 
                            : 'bg-white text-slate-400 border-2 border-slate-200'
                        }`}
                      >
                        {isActive ? (
                          <CheckCircle2 className="w-4 h-4 font-black" />
                        ) : (
                          <span className="text-xs font-black">{s.step}</span>
                        )}
                      </div>
                      <span className={`text-[9px] sm:text-[10px] font-extrabold mt-2 uppercase tracking-tight ${isCurrent ? 'text-indigo-600' : isActive ? 'text-slate-800' : 'text-slate-400'}`}>
                        {s.label}
                      </span>
                      <span className="text-[8px] font-bold text-slate-400 hidden sm:block mt-0.5">
                        {s.desc}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        }
        return null;
      })()}

      {/* Buyer's Outbound Payment Receipt (For Seller's reassurance and Buyer's record) */}
      {escrow.receipt_url && (
        <div className="mb-6 bg-emerald-50/45 border border-emerald-200/80 rounded-3xl p-5 sm:p-6 space-y-4 text-left shadow-lg">
          <div className="flex justify-between items-center border-b border-emerald-100/70 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-650 flex items-center justify-center font-bold text-base">🧾</div>
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  Buyer Paid Hold Receipt
                </h4>
                <p className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest mt-0.5 animate-pulse">
                  Direct P2P Deposit Lock Active
                </p>
              </div>
            </div>
            <div className="text-[9px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-lg uppercase tracking-wider">
              🛡️ FUNDS SAFE & SECURED
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left section: details */}
            <div className="space-y-3">
              <div className="bg-white border border-slate-200/60 rounded-2xl p-4.5 space-y-3.5 text-xs text-slate-700 shadow-sm">
                <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-slate-400">
                  <span>TRANSFER METHOD DETAILS</span>
                  <span className="text-emerald-600 font-extrabold capitalize">{escrow.paymentDetails?.method || 'Direct Transfer'}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 font-sans">
                  <div>
                    <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Transaction Ref (TID)</span>
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="font-mono font-black text-xs text-slate-900 truncate select-all">{escrow.paymentDetails?.tid || 'N/A'}</span>
                      <button 
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(escrow.paymentDetails?.tid || '');
                        }}
                        className="text-[9px] font-black text-indigo-600 hover:text-indigo-850 bg-indigo-50 px-1.5 py-0.5 rounded cursor-pointer transition-all active:scale-95"
                      >
                        Copy
                      </button>
                    </div>
                  </div>
                  <div>
                    <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Sender Account</span>
                    <span className="font-extrabold text-slate-800 font-mono text-xs">{escrow.paymentDetails?.senderAccount || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Sender Name</span>
                    <span className="font-extrabold text-slate-800 text-xs">{escrow.paymentDetails?.senderName || 'Anonymous'}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Timestamp</span>
                    <span className="font-extrabold text-slate-800 text-xs font-mono">
                      {escrow.paymentApprovedAt ? new Date(escrow.paymentApprovedAt).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl text-[10px] text-slate-500 leading-relaxed font-semibold">
                <p className="text-emerald-700 font-black mb-1">📢 For {isBuyer ? 'Buyer' : 'Seller'}:</p>
                {isBuyer ? (
                  <p>Your payment details has been successfully locked and updated in the escrow tracking register. The seller can see this receipt on their dashboard and is safe to deliver your items.</p>
                ) : (
                  <p><strong>ڈیش بورڈ پر تصدیق:</strong> خریدار نے یہ سکرین شاٹ اور ٹرانزیکشن کا حقیقی TID حوالہ اپ لوڈ کر دیا ہے۔ رقم ہمارے پاس ہولڈ ہو گئی ہے۔ آپ بغیر کسی پریشانی کے مطمئن ہو کر اپنا مال/ڈیلیوری خریدار تک پہنچا سکتے ہیں!</p>
                )}
              </div>
            </div>

            {/* Right section: Screenshot */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-center items-center shadow-sm">
              <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 self-start">UPLOADED SCREENSHOT PROOF</span>
              <div className="relative rounded-2xl overflow-hidden border border-slate-150 max-w-full max-h-[220px] shadow-inner bg-slate-50 hover:bg-slate-100 transition-colors flex items-center justify-center">
                <img 
                  src={escrow.receipt_url} 
                  alt="Receipt proof" 
                  className="max-w-full max-h-[180px] object-contain cursor-zoom-in rounded-xl" 
                  referrerPolicy="no-referrer"
                  onClick={() => {
                    const win = window.open();
                    if (win) win.document.write(`<img src="${escrow.receipt_url}" style="max-width:105%; display:block; margin:auto; border-radius:12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);" />`);
                  }}
                />
              </div>
              <p className="text-[9px] text-slate-400 font-bold mt-2.5 italic text-center">Click image above to zoom / verify details</p>
            </div>
          </div>
        </div>
      )}

      {/* DIGITAL ASSET PANEL (Strict Stepper Workspace and Security Wizard) */}
      {(() => {
        const isDigitalAsset = escrow.type === 'Digital_Asset' || escrow.deliveryMode === 'digital_asset';
        if (!isDigitalAsset) return null;

        const escStatus = escrow.escrowStatus || 'Funds_Pending';

        return (
          <div className="mb-6 space-y-4 animate-fade-in text-left">
            {/* Step 1: Funds Pending */}
            {escStatus === 'Funds_Pending' && (
              <div className="bg-amber-50 border border-amber-200 rounded-3xl p-5 space-y-2">
                <span className="inline-flex items-center gap-1.5 text-[9px] bg-amber-100 text-amber-800 font-black uppercase tracking-wider px-2 py-0.5 rounded-md">
                  ⌛ Phase 1: Wait for Deposits
                </span>
                <p className="text-xs font-semibold text-slate-705 leading-relaxed">
                  {isBuyer 
                    ? "Your digital asset deal is initialized. Before credentials can be requested safely, you must deposit the deal amount into the secure PK Escrow vault. Click the 'Fund Escrow' button below to proceed."
                    : "The contract is registered. PK Escrow is waiting for the Buyer to deposit secure funds into our platform vault. Do NOT share your account passwords, cookies, or 2FA codes yet. We will notify you instantly when funds are secured."}
                </p>
              </div>
            )}

            {/* Step 2: Funds Secured */}
            {escStatus === 'Funds_Secured' && (
              <div className="bg-indigo-50/60 border border-indigo-150 rounded-3xl p-5 space-y-4">
                <div className="flex justify-between items-center text-[10px] font-black text-indigo-700 uppercase tracking-widest px-0.5 border-b border-indigo-100/60 pb-2">
                  <span className="flex items-center gap-1.5">🔒 Phase 2: Secure Vault Active</span>
                  <span className="text-emerald-600 font-extrabold bg-emerald-50 px-2 py-0.5 rounded text-[9px]">FUNDS IN VAULT</span>
                </div>
                
                {isBuyer ? (
                  <div className="space-y-1.5">
                    <p className="text-xs font-extrabold text-slate-800">Payment is 100% Locked with PK Escrow!</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">
                      We have notified the Seller that their funds are secured and it is safe to upload the login credentials, backup recovery email details, or transfer link. You will receive an immediate SMS/system alert once delivered.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs font-black text-slate-900">Complete Ownership Transfer Form</p>
                      <p className="text-[10px] text-slate-500 font-medium leading-normal mt-0.5">
                        Please enter direct account username & password, backup recovery codes, or verification links. These details are isolated & encrypted in the platform vault and disclosed to the Buyer once they open their inspection phase.
                      </p>
                    </div>

                    <div className="space-y-3.5">
                      <div>
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1 px-0.5">Login ID / Access Email / Username</label>
                        <input
                          type="text"
                          value={assetCredentialsInput}
                          onChange={(e) => setAssetCredentialsInput(e.target.value)}
                          placeholder="e.g. login_email@gmail.com, or TikTok phone"
                          className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1 px-0.5">Password, Backup Codes or Ownership Links</label>
                        <textarea
                          value={assetBackupsInput}
                          onChange={(e) => setAssetBackupsInput(e.target.value)}
                          placeholder="e.g. Password: mySecretPass123! | Backup Codes: 234141, 412413 | Recovery Link: fb.com/link..."
                          rows={3}
                          className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 leading-relaxed"
                        />
                      </div>

                      <button
                        type="button"
                        disabled={isSubmittingCredentials || !assetCredentialsInput.trim() || !assetBackupsInput.trim()}
                        onClick={handleDeliverCredentials}
                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-3 rounded-2xl text-xs uppercase tracking-wider shadow-lg shadow-indigo-600/15 disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                      >
                        {isSubmittingCredentials ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : "Deliver Access Credentials Securely 🔑"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Credentials Delivered */}
            {escStatus === 'Credentials_Delivered' && (
              <div className="bg-amber-50/55 border border-amber-200 rounded-3xl p-5 space-y-4">
                <div className="flex justify-between items-center text-[10px] font-black text-amber-700 uppercase tracking-widest px-0.5 border-b border-amber-100 pb-2">
                  <span className="flex items-center gap-1.5">📬 Phase 3: Credential Vault Locked</span>
                  <span className="text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-black text-[9px]">ENVELOPE READY</span>
                </div>

                {isBuyer ? (
                  <div className="space-y-4">
                    <p className="text-xs text-slate-650 leading-relaxed">
                      The Seller has successfully shipped the account credentials and backup bypasses. For premium security, clicking below opens the login envelope and immediately triggers a **24-hour countdown window**. Use this window to verify the asset and change recovery configurations.
                    </p>
                    <button
                      type="button"
                      onClick={handleStartInspection}
                      className="w-full bg-amber-500 hover:bg-amber-600 text-white font-black py-3.5 rounded-2xl text-xs uppercase tracking-wider shadow-lg shadow-amber-500/15 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
                    >
                      <span>🔓 Open Vault & Begin 24-Hour Inspection</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <p className="text-xs font-extrabold text-slate-805 text-left">Your Deliverables are Safely Dispatched!</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">
                      The credentials are registered in the PK Escrow Vault. They are currently locked. The Buyer has been notified and must initiate their 24-hour inspection envelope now. Standby for confirmation.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Step 4: Under Inspection */}
            {escStatus === 'Under_Inspection' && (
              <div className="space-y-4 animate-fade-in text-left">
                {/* 24h Countdown Alert Header */}
                <div className="bg-rose-950/95 text-rose-100 border border-rose-900 rounded-3xl p-5 space-y-3 shadow-lg">
                  <div className="flex justify-between items-center border-b border-rose-900 pb-2">
                    <span className="flex items-center gap-1.5 text-[9px] font-black bg-rose-500/15 border border-rose-500/30 text-rose-300 uppercase tracking-widest px-2.5 py-1 rounded-lg">
                      ⏰ 24H Security Verification Countdown
                    </span>
                    <span className="text-[14px] font-mono font-black text-rose-400 animate-pulse">{inspectionCountdown}</span>
                  </div>

                  <div className="space-y-2">
                    <p className="text-[11px] font-black uppercase text-rose-300 tracking-wider">🛡️ Scams Prevention Protocol (Read Carefully):</p>
                    <ul className="text-[10px] text-rose-200 list-decimal list-inside space-y-1 leading-relaxed">
                      <li>Log in and inspect subscriber counts, page monetization, list, posts status or gaming level.</li>
                      <li><strong className="text-rose-400">IMMEDIATELY change</strong> the account recovery email address to your secure email.</li>
                      <li>Remove any unfamiliar recovery phone numbers.</li>
                      <li>Enable Google & social Authenticator (2FA) and register secure backup codes.</li>
                      <li>Force-logout any previous sessions / devices in safety dashboards.</li>
                    </ul>
                    <p className="text-[9px] font-bold text-rose-300 uppercase tracking-tight italic mt-1 bg-rose-950 px-2 py-1.5 rounded-lg border border-rose-900">
                      ⚠️ WARNING: Do not click Approve/Release under any circumstance until you have completed all recovery configuration changes. There is no refund once funds leave escrow.
                    </p>
                  </div>
                </div>

                {isBuyer ? (
                  <div className="bg-slate-50 border border-slate-200/85 rounded-3xl p-5 space-y-4">
                    <div className="border-b border-slate-205 pb-2">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">🔑 Decrypted Vault Credentials</p>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div>
                        <span className="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-0.5">Decrypted Username / Email</span>
                        <div className="flex items-center gap-2 bg-white border border-slate-200 p-2.5 rounded-xl font-bold text-slate-800 shadow-sm break-all font-mono">
                          <span className="flex-1">{escrow.assetLoginCredentials?.split(' | ')[0] || 'N/A'}</span>
                          <button
                            type="button"
                            onClick={() => navigator.clipboard.writeText(escrow.assetLoginCredentials?.split(' | ')[0] || '')}
                            className="bg-slate-100 hover:bg-slate-200 font-extrabold px-2.5 py-1 rounded text-[9px] text-slate-600 tracking-tight"
                          >
                            Copy
                          </button>
                        </div>
                      </div>

                      <div>
                        <span className="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-0.5">Decrypted Password & Bypass Codes</span>
                        <div className="flex items-center gap-2 bg-white border border-slate-205 p-2.5 rounded-xl font-bold text-slate-800 shadow-sm break-all font-mono">
                          <span className="flex-1 whitespace-pre-wrap">{escrow.assetLoginCredentials?.split(' | ')[1] || 'N/A'}</span>
                          <button
                            type="button"
                            onClick={() => navigator.clipboard.writeText(escrow.assetLoginCredentials?.split(' | ')[1] || '')}
                            className="bg-slate-100 hover:bg-slate-200 font-extrabold px-2.5 py-1 rounded text-[9px] text-slate-600 tracking-tight"
                          >
                            Copy
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Step 4 Buttons inside the card body */}
                    <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-slate-200/60">
                      <button
                        onClick={() => setIsMpinOpen(true)}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-3 rounded-2xl text-xs font-black transition-all shadow-md shadow-emerald-600/10 active:scale-95 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" /> Confirm Full Ownership (Release)
                      </button>
                      <button
                        onClick={() => {
                          const reason = prompt("Describe the fraud or access issue in detail. This locks the contract instantly and opens an arbitration ticket:");
                          if (reason && reason.trim()) {
                            handleRaiseFraudAlert(reason);
                          }
                        }}
                        className="flex-1 flex items-center justify-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white px-5 py-3 rounded-2xl text-xs font-black transition-all shadow-md shadow-rose-600/10 active:scale-95 cursor-pointer"
                      >
                        <AlertCircle className="w-4 h-4" /> Raise Fraud Alert (Lock Ticket)
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 border border-slate-200 rounded-3xl p-5 text-xs text-slate-600 font-semibold text-center leading-relaxed">
                    ⚙️ The account details have been decrypted to the Buyer. Their 24-hour password recovery change has been locked at {inspectionCountdown}. The payout will complete when they confirm security or the review is closed.
                  </div>
                )}
              </div>
            )}

            {/* Custom settlement summaries */}
            {escStatus === 'Completed' && (
              <div className="space-y-3">
                <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-4.5 text-xs text-emerald-800 font-bold flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-600" />
                  <span>Trade successfully completed! The full 1% platform commission was secured and remaining funds released directly to the seller's secure bank/wallet.</span>
                </div>
                
                {/* Outbound Payout Dispatch information for direct bank settlements */}
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs space-y-2 font-bold text-slate-700">
                  <p className="text-[9px] uppercase tracking-wider text-slate-400 font-black">Outbound Settlement Dispatch Status</p>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-650 font-medium">Payout Status:</span>
                    {escrow.payoutStatus === 'PAID' ? (
                      <span className="text-emerald-600 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-lg text-[9px] uppercase font-black">
                        🟢 Dispatched (Direct settlement)
                      </span>
                    ) : (
                      <span className="text-amber-600 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded-lg text-[9px] uppercase font-black">
                        ⏳ Processing Outbound Dispatch
                      </span>
                    )}
                  </div>
                  {escrow.payoutStatus === 'PAID' && escrow.payoutTxId && (
                    <div className="flex justify-between items-center bg-white p-2.5 rounded-xl mt-2 border border-slate-100 text-[11px] font-mono">
                      <span className="text-slate-500 font-bold">Settlement TID:</span>
                      <span className="text-emerald-700 font-black select-all">{escrow.payoutTxId}</span>
                    </div>
                  )}
                  {escrow.payoutStatus !== 'PAID' && (
                    <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
                      PK Escrow dispatches direct direct-to-bank settlements for absolute safety. Once dispatch is completed, the Transaction Reference (TID) will appear here instantly.
                    </p>
                  )}
                </div>
              </div>
            )}

            {escStatus === 'Disputed' && (
              <div className="bg-rose-50 border border-rose-250 rounded-3xl p-4.5 text-xs text-rose-850 font-bold flex items-center gap-2">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 animate-pulse" />
                <span>Trade frozen under active FRAUD ALERT! Our 24/7 arbitration board is auditing logs and security records now. Check trust history.</span>
              </div>
            )}
          </div>
        );
      })()}

      {/* Physical Delivery Destination Block */}
      {!isVirtual && (escrow.isPhysical || isBuyer) && (
        <div className="mb-6 bg-slate-50 border border-slate-200/60 rounded-3xl p-5 space-y-4">
          <div className="flex justify-between items-center text-[10px] font-black text-slate-500 uppercase tracking-widest px-0.5">
            <span className="flex items-center gap-1.5"><Truck className="w-4 h-4 text-slate-500" /> Physical Delivery Destination</span>
            <span className="text-slate-400">Recipient Station</span>
          </div>

          {!escrow.isPhysical && !isEditingShipping ? (
            <div className="bg-white border border-dashed border-slate-300 rounded-2xl p-5 text-center space-y-3.5">
              <p className="text-xs font-medium text-slate-500 max-w-sm mx-auto">
                No physical shipping parameters set yet. This escrow currently defaults to 💻 Digital Deliverables.
              </p>
              {isBuyer && (escrow.status === 'PROPOSED' || escrow.status === 'ACCEPTED' || escrow.status === 'FUNDED') && (
                <button
                  type="button"
                  onClick={() => {
                    setEditRecipientName(profile?.displayName || '');
                    setEditRecipientPhone(profile?.phoneNumber || '');
                    setEditShippingAddress('');
                    setIsEditingShipping(true);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs bg-slate-900 text-white font-black px-4 py-2 rounded-xl hover:bg-slate-850 active:scale-95 transition-all cursor-pointer uppercase tracking-tight"
                >
                  Convert to Physical Goods Shipping 📦
                </button>
              )}
            </div>
          ) : isEditingShipping ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-4 shadow-sm animate-fade-in">
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <span className="text-[10px] font-black text-indigo-600 uppercase">Form: Shipping Parameters</span>
                <button
                  type="button"
                  onClick={() => setIsEditingShipping(false)}
                  className="text-xs font-black text-slate-400 hover:text-slate-600"
                >
                  Cancel
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Recipient Real Name</label>
                  <input
                    type="text"
                    value={editRecipientName}
                    onChange={(e) => setEditRecipientName(e.target.value)}
                    placeholder="e.g. Hammad Khan"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    value={editRecipientPhone}
                    onChange={(e) => setEditRecipientPhone(e.target.value)}
                    placeholder="e.g. +92 312 4567890 (optional)"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Destination City</label>
                    <select
                      value={editShippingCity}
                      onChange={(e) => setEditShippingCity(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Karachi">Karachi</option>
                      <option value="Lahore">Lahore</option>
                      <option value="Islamabad">Islamabad</option>
                      <option value="Rawalpindi">Rawalpindi</option>
                      <option value="Faisalabad">Faisalabad</option>
                      <option value="Multan">Multan</option>
                      <option value="Peshawar">Peshawar</option>
                      <option value="Quetta">Quetta</option>
                      <option value="Sialkot">Sialkot</option>
                      <option value="Gujranwala">Gujranwala</option>
                      <option value="Hyderabad">Hyderabad</option>
                      <option value="Other">Other City</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1">Physical Address</label>
                  <textarea
                    value={editShippingAddress}
                    onChange={(e) => setEditShippingAddress(e.target.value)}
                    placeholder="House Number, Street details, Area sector..."
                    rows={2}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 leading-relaxed"
                  />
                </div>

                <button
                  type="button"
                  disabled={isSavingShipping || !editRecipientName.trim() || !editShippingAddress.trim()}
                  onClick={handleSaveShippingDetails}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-2.5 rounded-xl text-xs uppercase tracking-tight shadow-md shadow-indigo-600/15 disabled:opacity-50 flex items-center justify-center gap-1 cursor-pointer"
                >
                  {isSavingShipping ? 'Saving...' : 'Lock Shipping Destination Details'}
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl p-4.5 flex gap-4.5 items-start shadow-sm hover:border-slate-300 transition-all">
              <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600 shrink-0">
                <Package className="w-6 h-6" />
              </div>
              <div className="flex-1 space-y-1.5 min-w-0">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-xs font-black text-slate-900">{escrow.recipientName}</p>
                    <p className="text-[10px] text-slate-400 font-mono font-bold mt-0.5">{escrow.recipientPhone || 'No contact specified'}</p>
                  </div>
                  <span className="bg-indigo-50 text-indigo-700 text-[8px] font-black px-2 py-0.5 rounded uppercase border border-indigo-100">
                    Target Station: {escrow.shippingCity}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Delivery Address</p>
                  <p className="text-xs font-semibold text-slate-700 leading-relaxed break-words">{escrow.shippingAddress}</p>
                </div>

                {isBuyer && (escrow.status === 'PROPOSED' || escrow.status === 'ACCEPTED' || escrow.status === 'FUNDED') && (
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEditRecipientName(escrow.recipientName || '');
                        setEditRecipientPhone(escrow.recipientPhone || '');
                        setEditShippingCity(escrow.shippingCity || 'Karachi');
                        setEditShippingAddress(escrow.shippingAddress || '');
                        setIsEditingShipping(true);
                      }}
                      className="text-[10px] hover:text-indigo-800 text-indigo-600 font-black uppercase hover:underline cursor-pointer"
                    >
                      Edit shipping address ✏️
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Interactive Logistics Track Live Progress Simulator */}
      {escrow.isPhysical && (escrow.status === 'SHIPPED' || escrow.status === 'DELIVERED' || escrow.status === 'COMPLETED' || escrow.status === 'DISPUTED') && (() => {
        const getCourierTheme = (courierName?: string) => {
          const name = courierName?.toLowerCase() || '';
          if (name.includes('tcs')) {
            return {
              textColor: 'text-red-700',
              bgColor: 'bg-red-50',
              borderColor: 'border-red-100',
              accentColor: '#ef4444',
              name: 'TCS Express Pakistan'
            };
          }
          if (name.includes('leopard')) {
            return {
              textColor: 'text-amber-700',
              bgColor: 'bg-amber-50',
              borderColor: 'border-amber-100',
              accentColor: '#f59e0b',
              name: 'Leopards Courier Service'
            };
          }
          if (name.includes('post')) {
            return {
              textColor: 'text-emerald-700',
              bgColor: 'bg-emerald-50',
              borderColor: 'border-emerald-100',
              accentColor: '#10b981',
              name: 'Pakistan Post'
            };
          }
          if (name.includes('bykea')) {
            return {
              textColor: 'text-teal-700',
              bgColor: 'bg-teal-50',
              borderColor: 'border-teal-100',
              accentColor: '#0d9488',
              name: 'Bykea Local Dispatch'
            };
          }
          return {
            textColor: 'text-indigo-700',
            bgColor: 'bg-indigo-50',
            borderColor: 'border-indigo-100',
            accentColor: '#4f46e5',
            name: 'Standard Logistics / Courier'
          };
        };

        const cTheme = getCourierTheme(escrow.courier);
        const currentStep = escrow.transitStep !== undefined ? escrow.transitStep : 0;

        const percentage = Math.min(100, Math.max(0, currentStep * 25));

        const getSimulatedCheckpoints = () => {
          const recipientCity = escrow.shippingCity || 'Lahore';
          const shipperName = escrow.recipientName || 'Buyer';
          const cName = cTheme.name;

          const baseLogs = [
            { 
              step: 0, 
              status: "Shipment Dispatched & Scanned at City Port", 
              location: "Karachi Central Hub GPO base", 
              time: "14:15 PKT",
              details: `Initial cargo booking scanned by the sender via ${cName}. Package weighed: 1.25kg.`
            },
            { 
              step: 1, 
              status: "Overland Linehaul Transit Departure", 
              location: "Sindh Freight Sorting Terminal-1", 
              time: "20:30 PKT", 
              details: "Cargo departures overnight overland transit container routed towards destination station." 
            },
            { 
              step: 2, 
              status: "Cargo Gateway Outbound Processed", 
              location: `${recipientCity} Cantonment Area Sort Depot`, 
              time: "07:15 PKT", 
              details: `Consignment arrived in ${recipientCity} sorting gateway center successfully. Scanned as safe.` 
            },
            { 
              step: 3, 
              status: "Out for Doorstep Security Handover", 
              location: `${recipientCity} Delivery Route Node #48`, 
              time: "09:30 PKT", 
              details: `Rider dispatched on motor-transit route. For safety, recipient verification code should be ready.` 
            },
            { 
              step: 4, 
              status: "Safely Handed Over & Signed", 
              location: `Destination doorstep at ${recipientCity}`, 
              time: "11:45 PKT", 
              details: `Consignment successfully hand-delivered and signed by ${shipperName}. Transaction verified.` 
            }
          ];

          return baseLogs.filter(log => log.step <= currentStep);
        };

        const logs = getSimulatedCheckpoints();

        return (
          <div className="mb-6 bg-slate-50 border border-slate-200/60 rounded-3xl p-5 space-y-4">
            <div className="flex justify-between items-center text-[10px] font-black text-slate-500 uppercase tracking-widest px-0.5">
              <span className="flex items-center gap-1.5"><Truck className="w-4 h-4 text-indigo-500 fill-indigo-500 animate-pulse" /> Live Pakistan Logistics Hub Tracker</span>
              <span className={`px-2 py-0.5 rounded-full border text-[8px] font-black ${cTheme.textColor} ${cTheme.bgColor} ${cTheme.borderColor}`}>
                {cTheme.name}
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-4 shadow-sm relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Active Consignment Tracking ID</p>
                  <p className="text-sm font-black text-slate-800 font-mono flex items-center gap-1.5 mt-0.5">
                    <span>{escrow.trackingId || 'N/A'}</span>
                    <button
                      type="button"
                      onClick={() => navigator.clipboard.writeText(escrow.trackingId || '')}
                      className="text-[9px] text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100"
                    >
                      Copy
                    </button>
                  </p>
                </div>

                <div className="text-right">
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Expected Transit Speed</p>
                  <p className="text-xs font-black text-emerald-600 uppercase tracking-tight mt-0.5">24-48 Hours Delivery</p>
                </div>
              </div>

              <div className="pt-3">
                <div className="flex justify-between items-center text-[8px] font-black text-slate-500 uppercase tracking-wider mb-2">
                  <span>Booking branch</span>
                  <span className={`${currentStep >= 4 ? 'text-emerald-600' : 'text-indigo-600'}`}>
                    {currentStep === 4 ? 'Delivered' : 'In Transit'}
                  </span>
                  <span>Recipient base</span>
                </div>

                <div className="h-2 w-full bg-slate-100 rounded-full border border-slate-150 relative">
                  <div 
                    className="h-full bg-indigo-600 transition-all duration-700 ease-out flex justify-end items-center rounded-full" 
                    style={{ 
                      width: `${percentage}%`,
                      backgroundColor: currentStep === 4 ? '#10b981' : cTheme.accentColor 
                    }}
                  >
                    <div className="w-1.5 h-1.5 bg-white rounded-full mr-0.5" />
                  </div>
                </div>

                <div className="grid grid-cols-5 text-center mt-2.5">
                  {[
                    { s: 0, label: 'Booked' },
                    { s: 1, label: 'Sort Hub' },
                    { s: 2, label: 'In Transit' },
                    { s: 3, label: 'Rider Out' },
                    { s: 4, label: 'Delivered' }
                  ].map((m) => (
                    <div key={m.s} className="flex flex-col items-center select-none">
                      <div className={`w-2 h-2 rounded-full mb-1 ${currentStep >= m.s ? (currentStep === m.s ? 'bg-indigo-600 scale-125 ring-2 ring-indigo-200' : 'bg-emerald-500') : 'bg-slate-200'}`} />
                      <span className={`text-[8px] font-black uppercase tracking-tighter ${currentStep === m.s ? 'text-indigo-600 font-black scale-105' : 'text-slate-400'}`}>
                        {m.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => setShowLogsDetails(!showLogsDetails)}
                  className="text-[10px] text-slate-600 hover:text-slate-800 font-extrabold uppercase flex items-center gap-1 cursor-pointer"
                >
                  {showLogsDetails ? 'Hide Travel Scans 🔼' : 'Show Travel Scans (Checkpoints) 🔽'}
                </button>

                <button
                  type="button"
                  disabled={isQueryingLogs}
                  onClick={async () => {
                    setIsQueryingLogs(true);
                    setTimeout(() => {
                      setIsQueryingLogs(false);
                    }, 1000);
                  }}
                  className="text-[10px] text-indigo-600 hover:text-indigo-800 font-black uppercase flex items-center gap-1 cursor-pointer"
                >
                  {isQueryingLogs ? (
                    <span className="flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" /> Fetching Live GPS...
                    </span>
                  ) : (
                    "Query Live API 🔄"
                  )}
                </button>
              </div>

              {showLogsDetails && (
                <div className="bg-slate-900 text-slate-100 rounded-2xl p-4.5 font-mono text-[10px] leading-relaxed border border-slate-950 space-y-3.5 mt-3 shadow-inner max-h-56 overflow-y-auto">
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-cyan-400 uppercase font-black tracking-widest text-[9px]">// RAST LOGISTICS CONSOLE</span>
                    <span className="text-slate-400 font-bold">{cTheme.name}</span>
                  </div>

                  {logs.map((log) => (
                    <div key={log.step} className="space-y-1 pl-2 border-l-2 border-cyan-500 animate-fade-in text-left">
                      <div className="flex justify-between text-slate-350">
                        <span className="text-cyan-300 font-black">[ {log.status} ]</span>
                        <span className="font-bold">{log.time}</span>
                      </div>
                      <p className="text-white font-black text-[11px] mt-0.5">{log.location}</p>
                      <p className="text-[10px] text-slate-400 leading-snug font-medium">{log.details}</p>
                    </div>
                  ))}
                </div>
              )}

              {currentStep < 4 && (
                <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mt-4 text-left">
                  <div className="flex-1">
                    <p className="text-[10px] font-black text-indigo-800 uppercase">Interactive Sandbox Test Tool</p>
                    <p className="text-[9px] text-slate-500 font-medium leading-normal">Test tracking & status updates. Progress step-by-step or skip immediately!</p>
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto shrink-0">
                    <button
                      type="button"
                      disabled={isSimulatingTransit}
                      onClick={handleSimulateTransitStep}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-[10px] uppercase tracking-wide cursor-pointer disabled:opacity-50 flex items-center gap-1 whitespace-nowrap justify-center flex-1 sm:flex-initial"
                    >
                      {isSimulatingTransit ? 'Advancing...' : 'Simulate Step 🚚'}
                    </button>
                    <button
                      type="button"
                      disabled={isSimulatingTransit}
                      onClick={handleInstantDeliver}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-3 py-1.5 rounded-xl text-[10px] uppercase tracking-wide cursor-pointer disabled:opacity-50 flex items-center gap-1 whitespace-nowrap justify-center flex-1 sm:flex-initial shadow-md shadow-emerald-600/10"
                    >
                      Instant Deliver ⚡
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* Proof of Work & Delivery Details */}
      {(escrow.trackingId || escrow.courier || escrow.proofOfWorkLink || escrow.proofOfWorkNote) && (
        <div className="mb-6 bg-slate-50 border border-slate-200/60 rounded-3xl p-5 space-y-4">
          <div className="flex justify-between items-center text-[10px] font-black text-indigo-600 uppercase tracking-widest px-0.5">
            <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-indigo-500 animate-pulse" /> Delivery & Work Evidence</span>
            <span className="text-slate-400">Escrow Records</span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {isVirtual ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-4 shadow-sm text-left">
                <div className="flex items-center gap-2 text-emerald-600">
                  <ShieldCheck className="w-5 h-5 shrink-0" />
                  <div>
                    <h5 className="text-[10px] font-black uppercase tracking-wider text-slate-400">Delivery Status</h5>
                    <p className="text-xs font-bold text-slate-800">Online Digital Delivery Completed</p>
                  </div>
                </div>

                {escrow.proofOfWorkLink && (
                  <div className="border-t border-slate-100 pt-3">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Verifiable Deliverable Link</p>
                    <div className="flex items-center justify-between gap-2.5 mt-1 bg-slate-50 border border-slate-100 p-2.5 rounded-xl">
                      <span className="text-xs font-semibold text-slate-600 truncate font-mono max-w-[180px] sm:max-w-[280px]">{escrow.proofOfWorkLink}</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(escrow.proofOfWorkLink || '');
                          }}
                          className="text-[9px] bg-white border border-slate-250 hover:bg-slate-50 text-slate-600 font-extrabold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer"
                        >
                          Copy
                        </button>
                        <a
                          href={escrow.proofOfWorkLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[9px] bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-3 py-1.5 rounded-lg transition-all inline-flex items-center gap-1 cursor-pointer"
                        >
                          Open <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                {escrow.proofOfWorkNote && (
                  <div className="border-t border-slate-100 pt-3">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Completion Note / Credentials</p>
                    <div className="bg-indigo-50/40 border border-indigo-150/50 rounded-xl p-3 text-xs text-slate-700 font-semibold leading-relaxed">
                      {escrow.proofOfWorkNote}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* Courier Service & Tracking Details Card */
              <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Courier/Dispatch Method</p>
                  <p className="text-sm font-black text-slate-800 mt-0.5">{escrow.courier || 'Standard Logistics / Courier'}</p>
                  
                  {escrow.trackingId && (
                    <div className="mt-3">
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Tracking Reference Code</p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xs font-black text-slate-800 font-mono bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-150 break-all">{escrow.trackingId}</p>
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(escrow.trackingId || '');
                          }}
                          className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold px-2 py-1.5 rounded-xl cursor-pointer transition-colors"
                          title="Copy Tracking ID"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {escrow.trackingId && escrow.trackingId !== 'N/A' && (
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <a 
                      href={
                        escrow.courier?.toLowerCase().includes('tcs') ? 'https://www.tcsexpress.com/tracking' :
                        escrow.courier?.toLowerCase().includes('leopard') ? 'https://www.leopardscourier.com/tracking' :
                        `https://www.google.com/search?q=track+package+${escrow.trackingId}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-black text-indigo-600 hover:text-indigo-800 hover:underline"
                    >
                      Track Live Dispatch <ArrowRight className="w-3 h-3 animate-pulse" />
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bank Details Section */}
      {showBankInfo && counterparty && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-6 bg-slate-50 border border-slate-100 rounded-2xl overflow-hidden"
        >
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Bank Verification</h4>
              <ShieldCheck className="w-3 h-3 text-emerald-500" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-slate-100">
                <UserIcon className="w-4 h-4 text-emerald-500" />
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Account Holder</p>
                  <p className="text-xs font-black text-slate-900">{counterparty.accountHolderName || 'Not Shared'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-slate-100">
                <Building2 className="w-4 h-4 text-emerald-500" />
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Bank Name</p>
                  <p className="text-xs font-black text-slate-900">{counterparty.bankName || 'Not Shared'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-slate-100 md:col-span-2">
                <div className="w-4 h-4 text-emerald-500 flex items-center justify-center font-black text-[10px]">IBAN</div>
                <div className="flex-1">
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Account Number / IBAN</p>
                  <p className="text-xs font-black text-slate-900 font-mono">{counterparty.ibanNumber || 'Not Shared'}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      <div className="border-t border-slate-100 pt-6 flex flex-wrap gap-3">
        {/* Secure Deal Chat Button redirects to dedicated chat page */}
        <button 
          type="button"
          onClick={async () => {
            if (!escrow.isChatOpen) {
              const escrowRef = doc(db, 'escrows', escrow.id);
              await updateDoc(escrowRef, { isChatOpen: true }).catch(err => console.warn(err));
            }
            setActiveChatEscrowId(escrow.id);
            setView('chat');
          }}
          className="relative flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all active:scale-95 cursor-pointer border bg-white hover:bg-slate-50 border-slate-200 text-slate-700 hover:text-slate-900 shadow-sm"
        >
          <MessageSquare className="w-4 h-4 text-emerald-500" /> 
          <span>OPEN SECURE CHAT</span>
          
          {hasUnread && (
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
          )}
        </button>
        {/* PROPOSED (Accepted by Seller) */}
        {!isBuyer && escrow.status === 'PROPOSED' && (
          <button 
            onClick={() => updateStatus('ACCEPTED')}
            className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors"
          >
            <ThumbsUp className="w-4 h-4" /> Accept Order
          </button>
        )}

        {/* ACCEPTED (Funded by Buyer with P2P Manual Settlement) */}
        {escrow.status === 'ACCEPTED' && (
          <div className="w-full">
            {/* If payment proof is already submitted, show state info or approval actions */}
            {escrow.isPaymentSubmitted ? (
              <div className="w-full max-w-lg">
                {/* Both Buyer and Seller see the Pending Admin Audit dashboard card */}
                <div className="bg-slate-50 border border-amber-200 rounded-[2rem] p-6 space-y-4 text-left shadow-xl shadow-amber-950/5">
                  <div className="flex gap-3">
                    <div className="w-12 h-12 rounded-[1.25rem] bg-amber-500 text-white flex items-center justify-center shrink-0 font-black text-xl animate-pulse shadow-md shadow-amber-500/20">⏳</div>
                    <div>
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest">
                        {isBuyer ? 'Direct Deposit Awaiting Admin Audit' : 'Buyer Paid — Awaiting Admin Verification'}
                      </h4>
                      <p className="text-[10px] font-bold text-amber-600 uppercase mt-0.5">منجانب پلیٹ فارم ایڈمنسٹریٹر تصدیق ہورہی ہے</p>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-150 rounded-2xl p-4.5 space-y-3.5 text-xs text-slate-700">
                    <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-slate-400">
                      <span>Verification Agent</span>
                      <span className="text-indigo-600 font-extrabold animate-pulse">Platform compliance desk</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3.5 pt-2 border-t border-slate-100 font-sans">
                      <div>
                        <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Payment Method</span>
                        <span className="font-extrabold text-slate-800 capitalize font-mono text-xs">{escrow.paymentDetails?.method || 'Direct Transfer'}</span>
                      </div>
                      <div>
                        <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Transaction Ref (TID)</span>
                        <span className="font-black text-slate-900 font-mono text-xs select-all bg-slate-50 border border-slate-100 px-2 py-0.5 rounded">{escrow.paymentDetails?.tid || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Sender Account No</span>
                        <span className="font-extrabold text-slate-800 font-mono text-xs">{escrow.paymentDetails?.senderAccount || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Sender Account Name</span>
                        <span className="font-extrabold text-slate-800 text-xs">{escrow.paymentDetails?.senderName || 'N/A'}</span>
                      </div>
                    </div>

                    {escrow.receipt_url && (
                      <div className="pt-3 border-t border-slate-100 space-y-1.5">
                        <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Uploaded Screenshot Proof</span>
                        <div className="relative rounded-xl overflow-hidden border border-slate-200 max-w-[200px] shadow-sm bg-slate-50 hover:opacity-90 transition-opacity">
                          <img 
                            src={escrow.receipt_url} 
                            alt="Receipt proof" 
                            className="w-full h-auto object-contain cursor-zoom-in" 
                            referrerPolicy="no-referrer"
                            onClick={() => {
                              const win = window.open();
                              if (win) win.document.write(`<img src="${escrow.receipt_url}" style="max-width:100%; display:block; margin:auto;" />`);
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-[11px] text-slate-700 leading-relaxed font-bold space-y-1">
                    <p className="text-amber-800">🔒 SECURED ESCROW PROTOCOL:</p>
                    <p className="font-medium text-slate-600">The platform compliance admin is currently verifying this receipt screenshot against the direct bank/wallet accounts register. Once the transaction is physically confirmed, the admin will set this escrow state to <strong>"Held" (LOCK FUNDS)</strong>, enabling active order fulfillment.</p>
                  </div>

                  {isBuyer && (
                    <button
                      type="button"
                      disabled={isSimulatingState}
                      onClick={async () => {
                        if (confirm("Cancel submission to edit bank transfer details? your transaction remains on hold.")) {
                          const escrowRef = doc(db, 'escrows', escrow.id);
                          await updateDoc(escrowRef, { isPaymentSubmitted: false });
                        }
                      }}
                      className="text-[10px] font-black text-rose-600 hover:text-rose-800 uppercase tracking-widest pl-1 mt-2.5 transition-colors cursor-pointer"
                    >
                      ⚠️ Cancel & Resubmit Proof
                    </button>
                  )}
                </div>
              </div>
            ) : (
              isBuyer ? (
                // Buyer sees checkout portal directly
                <div className={`w-full transition-all duration-300 ${isFundingOpen ? 'max-w-4xl' : 'max-w-lg'}`}>
                  {!isFundingOpen ? (
                    <button 
                      onClick={() => setIsFundingOpen(true)}
                      className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-4 rounded-[1.75rem] text-xs font-black transition-all shadow-xl shadow-emerald-600/15 active:scale-95 cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4 animate-pulse" /> Direct Admin P2P — Lock Funds
                    </button>
                  ) : (
                    <div className="bg-white border border-slate-200/85 rounded-[2.5rem] p-5 sm:p-7 space-y-6 animate-fade-in w-full text-left shadow-2xl">
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-base">🛡️</div>
                          <div>
                            <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                              Direct P2P Escrow Holding
                            </h4>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                              TRANSFER TO LOCK FUNDS INSTANTLY
                            </p>
                          </div>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => { setIsFundingOpen(false); }}
                          className="text-xs font-black text-slate-400 hover:text-slate-650 cursor-pointer px-2 py-1"
                        >
                          Cancel
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                        {/* Column 1: Payment Instructions */}
                        <div className="md:col-span-5 space-y-4">
                          <div className="bg-slate-50/60 p-4 rounded-2xl border border-slate-100 text-center">
                            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Transfer Value Required</span>
                            <span className="text-2xl font-mono font-black text-rose-500 mt-0.5 block">Rs. {escrow.amount.toLocaleString()}</span>
                            <p className="text-[8px] text-slate-500 mt-1 font-medium">Please send the exact amount above</p>
                          </div>

                          {/* Quick Tabs Selection */}
                          <div className="space-y-1.5">
                            <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider px-1">Select Account Method</label>
                            <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
                              {(['easypaisa', 'jazzcash', 'raast'] as const).map((method) => (
                                <button
                                  key={method}
                                  type="button"
                                  onClick={() => setSelectedPayMethod(method)}
                                  className={`flex-1 text-[10px] py-2 font-bold rounded-lg transition-all capitalize text-center cursor-pointer ${
                                    selectedPayMethod === method 
                                      ? 'bg-white text-slate-900 shadow-sm' 
                                      : 'text-slate-500 hover:text-slate-800'
                                  }`}
                                >
                                  {method === 'raast' ? 'Bank' : method}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Selected Method Details */}
                          <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4 space-y-3">
                            <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider pb-1.5 border-b border-slate-200/55">
                              <span>
                                {selectedPayMethod === 'raast' 
                                  ? (adminWalletData?.bankName || 'BankIslami') 
                                  : selectedPayMethod.toUpperCase()} Central holding Account
                              </span>
                              <span className="text-[8px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-black tracking-widest uppercase">SECURE HOLD</span>
                            </div>

                            {selectedPayMethod === 'raast' ? (
                              <div className="space-y-2 text-xs text-left">
                                <div className="flex justify-between items-center">
                                  <span className="text-slate-400 text-[10px] font-bold">Bank Name</span>
                                  <span className="font-extrabold text-slate-705">{adminWalletData?.bankName || 'BankIslami'}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-slate-400 text-[10px] font-bold">Account Title</span>
                                  <span className="font-extrabold text-slate-705">{adminWalletData?.accountHolderName || 'PK ESCROW CENTRAL HOLDINGS'}</span>
                                </div>
                                <div className="pt-1.5 border-t border-slate-200/40">
                                  <span className="text-slate-400 text-[9px] font-bold block mb-1">Account No.</span>
                                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 p-2 rounded-xl text-slate-900 font-mono font-bold text-[11px] justify-between shadow-sm">
                                    <span className="truncate select-all text-[10px]">{adminWalletData?.ibanNumber || '215400182600001'}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleCopyToClipboard(adminWalletData?.ibanNumber || '215400182600001', 'iban')}
                                      className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-black px-2 py-1 rounded text-[9px] shrink-0 min-w-[50px] text-center transition-all cursor-pointer active:scale-95"
                                    >
                                      {copiedField === 'iban' ? 'Copied! ✓' : 'Copy'}
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div className="space-y-2 text-xs text-left">
                                <div className="flex justify-between items-center">
                                  <span className="text-slate-405 text-[10px] font-bold">Account Title</span>
                                  <span className="font-extrabold text-slate-705">{adminWalletData?.accountHolderName || 'PK ESCROW CENTRAL HOLDINGS'}</span>
                                </div>
                                <div className="pt-1.5 border-t border-slate-200/40">
                                  <span className="text-slate-400 text-[9px] font-bold block mb-1">
                                    {selectedPayMethod.toUpperCase()} Account No
                                  </span>
                                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 p-2 rounded-xl text-slate-900 font-mono font-bold text-[11px] justify-between shadow-sm">
                                    <span className="font-extrabold">
                                      {selectedPayMethod === 'easypaisa' 
                                        ? (adminWalletData?.easypaisaNumber || '03054333292') 
                                        : (adminWalletData?.jazzcashNumber || '03054333292')}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const num = selectedPayMethod === 'easypaisa' 
                                          ? (adminWalletData?.easypaisaNumber || '03054333292') 
                                          : (adminWalletData?.jazzcashNumber || '03054333292');
                                        handleCopyToClipboard(num, 'phone');
                                      }}
                                      className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-black px-2 py-1 rounded text-[9px] shrink-0 min-w-[50px] text-center transition-all cursor-pointer active:scale-95"
                                    >
                                      {copiedField === 'phone' ? 'Copied! ✓' : 'Copy'}
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="text-[9px] text-slate-400 font-semibold leading-relaxed bg-slate-50 border border-slate-100 p-3 rounded-2xl text-left">
                            💡 <strong>اہم ہدایت:</strong> رقم سیلر کو براہِ راست مت بھیجیں۔ اوپر دیے گئے <strong>پی کے ایسکرو</strong> کے سرکاری ہولڈنگ اکاؤنٹس میں فنڈز ٹرانسفر کریں۔ ایڈمن آپ کے فنڈز کو محفوظ کر کے ڈیل لاک کرے گا، اور ڈیل مکمل ہونے پر خودکار طریقے سے فنڈز سیلر کو جاری کر دیے جائیں گے!
                          </div>
                        </div>

                        {/* Column 2: Verification Form */}
                        <div className="md:col-span-7 space-y-4 border-t md:border-t-0 md:border-l border-slate-100 pt-5 md:pt-0 md:pl-6">
                          <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Verification Details</h5>

                          {!isSimulatingState ? (
                            <>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div className="space-y-1">
                                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest px-1">Your Sender Account No</label>
                                  <input 
                                    type="tel"
                                    required
                                    value={paySenderAccount}
                                    onChange={(e) => setPaySenderAccount(e.target.value)}
                                    placeholder="e.g. 03451234567"
                                    className="w-full bg-slate-50 border border-slate-205 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 transition-all font-mono outline-none"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest px-1">Your Sender Name</label>
                                  <input 
                                    type="text"
                                    required
                                    value={paySenderName}
                                    onChange={(e) => setPaySenderName(e.target.value)}
                                    placeholder="e.g. Muhammad Usman"
                                    className="w-full bg-slate-50 border border-slate-205 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 transition-all outline-none"
                                  />
                                </div>
                              </div>

                              <div className="space-y-1">
                                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest px-1">
                                  Transaction ID (TID Reference) <span className="text-rose-500">*</span>
                                </label>
                                <input 
                                  type="text"
                                  required
                                  value={payTransactionId}
                                  onChange={(e) => {
                                    setPayTransactionId(e.target.value);
                                    if(simulationError) setSimulationError('');
                                  }}
                                  placeholder="Enter transaction reference TID (e.g. 19873109283)"
                                  className="w-full bg-slate-50 hover:bg-slate-100/30 focus:bg-white border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 rounded-xl px-4 py-2.5 text-xs font-black text-slate-900 transition-all font-mono tracking-wider outline-none text-center"
                                />
                              </div>

                              {/* Screenshot upload zone */}
                              <div className="space-y-1">
                                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest px-1">
                                  Upload Receipt Screenshot <span className="text-rose-500">*</span>
                                </label>
                                <div className="flex items-center gap-3 bg-slate-50 hover:bg-slate-100/40 border border-dashed border-slate-200 hover:border-emerald-500/50 rounded-xl p-3 transition-all font-sans">
                                  <input 
                                    type="file" 
                                    required
                                    accept="image/*" 
                                    onChange={handleReceiptUpload} 
                                    className="hidden" 
                                    id="receipt-screenshot-file" 
                                  />
                                  <label 
                                    htmlFor="receipt-screenshot-file"
                                    className="bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-lg text-[10px] font-extrabold cursor-pointer transition-all active:scale-95 text-center shrink-0 shadow-sm"
                                  >
                                    Select Image
                                  </label>
                                  <span className="text-[10px] font-bold text-slate-500 truncate flex-1">
                                    {payReceiptImage ? '🟢 SCREENSHOT UPLOADED' : 'No photo selected'}
                                  </span>
                                </div>
                                {payReceiptImage && (
                                  <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 max-w-[120px] aspect-[1.3/1] bg-slate-100 shadow-sm relative animate-fade-in">
                                    <img src={payReceiptImage} alt="receipt thumb" className="w-full h-full object-cover" />
                                    <button 
                                      onClick={() => setPayReceiptImage(null)}
                                      type="button"
                                      className="absolute top-1 right-1 bg-slate-900/80 hover:bg-slate-900 text-white p-1 rounded-full text-[8px] font-bold"
                                    >
                                      ✕
                                    </button>
                                  </div>
                                )}
                              </div>

                              {simulationError && (
                                <p className="text-[9px] font-bold text-rose-500 mt-1 text-center animate-shake bg-rose-50 border border-rose-100 p-2 rounded-xl">
                                  {simulationError}
                                </p>
                              )}

                              <div className="bg-slate-105 rounded-xl p-3 border border-slate-100 text-[10px] space-y-1 font-bold text-slate-500">
                                <div className="flex justify-between">
                                  <span>Value to Lock in Hold:</span>
                                  <span className="text-slate-800 font-extrabold">Rs. {escrow.amount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Fee:</span>
                                  <span className="text-emerald-600 font-extrabold">Rs. 0 (Free Launch)</span>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => {
                                  if (!payReceiptImage) {
                                    setSimulationError("You must upload your transaction receipt screenshot proof to proceed.");
                                    return;
                                  }
                                  if (!payTransactionId.trim()) {
                                    setSimulationError("Please enter the Reference Transaction ID (TID).");
                                    return;
                                  }
                                  handleSubmitPaymentProof();
                                }}
                                className="w-full text-white py-3 rounded-2xl text-[11px] font-black shadow-lg hover:shadow-emerald-600/10 hover:opacity-95 transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer bg-emerald-600 active:scale-95"
                              >
                                <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Submit Proof & Lock Funds
                              </button>
                            </>
                          ) : (
                            <div className="flex flex-col items-center justify-center p-6 border border-slate-100 rounded-2xl bg-slate-50/50 text-center space-y-4 animate-fade-in font-sans min-h-[300px]">
                              <div className="relative">
                                <div className="w-16 h-16 rounded-full bg-indigo-50 border-2 border-indigo-200 flex items-center justify-center text-indigo-600 animate-pulse">
                                  <Sparkles className="w-8 h-8 text-indigo-600 fill-indigo-100" />
                                </div>
                                <div className="absolute top-0 left-0 w-16 h-16 rounded-full border-2 border-indigo-550 border-t-transparent animate-spin" />
                              </div>
                              
                              <div className="space-y-2 max-w-xs">
                                <span className="text-[8px] font-black tracking-widest text-indigo-600 uppercase bg-indigo-50 px-2 py-0.5 rounded-full inline-block">
                                  PK Fast-Scan compliance node v3.5
                                </span>
                                <h5 className="text-xs font-black text-slate-800 uppercase tracking-wide">
                                  {simulationStep === 1 && 'Reading receipt details via fast scanner...'}
                                  {simulationStep === 2 && 'Analyzing transaction ID & Amount...'}
                                  {simulationStep === 3 && 'Verifying Recipient Account details...'}
                                  {simulationStep === 4 && 'Audit success! Securing holdings...'}
                                </h5>
                                <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
                                  {simulationStep === 1 && 'Extracting secure visual parameters from transaction screenshot...'}
                                  {simulationStep === 2 && `Matching TID ${payTransactionId.trim()} and amount Rs. ${escrow.amount.toLocaleString()}...`}
                                  {simulationStep === 3 && `Comparing expected recipient (${selectedPayMethod === 'raast' ? '215400182600001' : '03054333292'}) match...`}
                                  {simulationStep === 4 && 'Audit passed! Locking funds and writing escrow ledger blocks...'}
                                </p>
                              </div>
                              
                              <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden max-w-[200px]">
                                <div 
                                  className="bg-indigo-600 h-1 rounded-full transition-all duration-300" 
                                  style={{ width: `${simulationStep * 25}%` }}
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                // Seller is looking at escrow waiting for buyer payment
                <div className="bg-slate-55 border border-slate-200 rounded-3xl p-5 text-left w-full max-w-sm space-y-2">
                  <div className="flex items-center gap-1.5 text-slate-500">
                    <Loader2 className="w-4 h-4 animate-spin text-indigo-600 shrink-0" />
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest animate-pulse">Awaiting Buyer Payment</span>
                  </div>
                  <p className="text-[11px] font-bold text-slate-600 leading-relaxed">
                    Once the buyer performs the direct Bank/JazzCash transfer to the official project escrow account and uploads their receipt screenshot, our platform administrators will audit internal statements, verify the TID reference, and lock the funds in hold.
                  </p>
                  <span className="text-[9px] font-medium text-slate-400 block italic leading-none border-t border-slate-200/50 pt-1.5">You can chat with them to expedite payment details</span>
                </div>
              )
            )}
          </div>
        )}
        
        {/* FUNDED (Shipped by Seller with interactive Proof input) */}
        {!isBuyer && escrow.status === 'FUNDED' && (
          <div className="w-full">
            {!isAddingTracking ? (
              <div className="flex flex-wrap gap-2.5">
                {isVirtual ? (
                  <button 
                    onClick={() => setIsAddingTracking(true)}
                    className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-lg shadow-indigo-600/15 active:scale-95 transition-all cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Deliver Credentials & Proof
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={() => setIsAddingTracking(true)}
                      className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-lg shadow-indigo-600/15 active:scale-95 transition-all cursor-pointer"
                    >
                      <Truck className="w-4 h-4" /> Ship with Details
                    </button>
                    <button 
                      onClick={async () => {
                        const randomTrk = 'PK-' + Math.floor(100000 + Math.random() * 900000);
                        await updateStatus('SHIPPED', {
                          trackingId: randomTrk,
                          courier: 'TCS Express Pakistan',
                          proofOfWorkLink: '',
                          proofOfWorkNote: 'Shipped instantly via 1-Click Fast-Track.',
                          proofOfWorkSubmittedAt: new Date().toISOString(),
                          transitStep: 4 // Put it directly as ready and delivered!
                        });
                        
                        // Also fire notifications
                        const customMsg = `🚚 Quick Ship: Your parcel has been dispatched instantly (Tracking ID: ${randomTrk}). Ready for delivery verification.`;
                        await sendNotification(escrow.buyerId, '🚚 Courier Dispatched', customMsg, 'INFO', escrow.id).catch(e => console.warn(e));
                      }}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-lg shadow-emerald-500/15 active:scale-95 transition-all cursor-pointer"
                    >
                      ⚡ Quick Ship (1-Click)
                    </button>
                  </>
                )}
              </div>
            ) : (
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-3xl p-5 space-y-4 animate-fade-in w-full max-w-lg">
                <div className="flex justify-between items-center border-b border-indigo-100/60 pb-2">
                  <h4 className="text-xs font-black text-indigo-700 uppercase tracking-widest flex items-center gap-1.5">
                    {isVirtual ? (
                      <>
                        <ShieldCheck className="w-4 h-4 animate-pulse" /> Digital Delivery & Work Verification Form
                      </>
                    ) : (
                      <>
                        <Truck className="w-4 h-4 animate-bounce" /> Dispatch Logistics & Proof Form
                      </>
                    )}
                  </h4>
                  <button 
                    type="button"
                    onClick={() => setIsAddingTracking(false)}
                    className="text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {!isVirtual && (
                    <>
                      <div>
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1.5 px-0.5">Courier or Dispatch Channel</label>
                        <select
                          value={courierInput}
                          onChange={(e) => setCourierInput(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                        >
                          <option value="TCS Extension">TCS Express Pakistan</option>
                          <option value="Leopards Courier">Leopards Courier</option>
                          <option value="Pakistan Post">Pakistan Post (GPO)</option>
                          <option value="Bykea / Rider">Local Rider (Bykea, Careem, Indrive)</option>
                          <option value="Digital Deliverables / Link">Digital Delivery (Email, Github, Drive)</option>
                          <option value="In-Person Handover">In-Person Handover</option>
                          <option value="Other">Other Method</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1.5 px-0.5">Tracking Number / Ref ID</label>
                        <input 
                          type="text"
                          value={trackingIdInput}
                          onChange={(e) => setTrackingIdInput(e.target.value)}
                          placeholder="e.g. TCS108429184"
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 placeholder:text-slate-350"
                        />
                      </div>
                    </>
                  )}

                  <div className="sm:col-span-2">
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1.5 px-0.5">Proof of Work Link (Verifiable URL)</label>
                    <input 
                      type="url"
                      value={proofLinkInput}
                      onChange={(e) => setProofLinkInput(e.target.value)}
                      placeholder={isVirtual ? "https://github.com/..., https://drive.google.com/..." : "Google Drive, Dropbox, Imgur, Github, etc."}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 placeholder:text-slate-350"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider mb-1.5 px-0.5">Completion Message / Instructions</label>
                    <textarea 
                      value={proofNoteInput}
                      onChange={(e) => setProofNoteInput(e.target.value)}
                      placeholder={isVirtual ? "Provide passwords, keys, workspace details, or other deliverables instructions..." : "Enter details about your shipment, weights, passwords, digital specifications, or any critical info..."}
                      rows={2}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 placeholder:text-slate-350 leading-relaxed"
                    />
                  </div>
                </div>

                <div className="flex gap-2.5 pt-1.5">
                  <button 
                    type="button"
                    onClick={async () => {
                      await updateStatus('SHIPPED', {
                        trackingId: isVirtual ? 'DIGITAL-VERIFIED' : (trackingIdInput.trim() || 'N/A'),
                        courier: isVirtual ? 'Online Digital Delivery' : courierInput,
                        proofOfWorkLink: proofLinkInput.trim() || '',
                        proofOfWorkNote: proofNoteInput.trim() || '',
                        proofOfWorkSubmittedAt: new Date().toISOString(),
                        transitStep: isVirtual ? 4 : 0
                      });
                      setIsAddingTracking(false);
                    }}
                    className="flex-1 text-white py-2.5 rounded-xl text-xs font-black shadow-lg shadow-indigo-600/10 active:scale-95 transition-all w-full text-center cursor-pointer"
                    style={{ backgroundColor: '#4f46e5' }}
                  >
                    {isVirtual ? "Complete Delivery & Submit Proof" : "Confirm Dispatch & Submit Proof"}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsAddingTracking(false)}
                    className="px-4 py-2.5 text-xs font-black text-slate-400 hover:text-slate-600 border border-slate-250 hover:bg-slate-50 rounded-xl transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SHIPPED - Seller Actions vs Buyer Actions */}
        {escrow.status === 'SHIPPED' && !isDigitalAsset && (
          <div className="w-full flex flex-wrap gap-2.5">
            {isBuyer ? (
              <div className="flex flex-col sm:flex-row gap-2.5 w-full">
                <button 
                  onClick={() => updateStatus('DELIVERED')}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-black transition-all shadow-lg shadow-indigo-600/10 active:scale-95 cursor-pointer"
                >
                  <Package className="w-4 h-4" /> Acknowledge Handover / Delivery
                </button>
                <button 
                  onClick={() => setIsMpinOpen(true)}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-xs font-black transition-all shadow-lg shadow-emerald-600/10 active:scale-95 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> Approve Proof & Release Payout
                </button>
              </div>
            ) : (
              <button 
                onClick={() => updateStatus('DELIVERED')}
                className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors cursor-pointer"
              >
                <Package className="w-4 h-4" /> Mark as Arrived / Delivered
              </button>
            )}
          </div>
        )}

        {/* DELIVERED - Release Payment (By Buyer) */}
        {escrow.status === 'DELIVERED' && !isDigitalAsset && (
          <div className="w-full">
            {isBuyer ? (
              <button 
                onClick={() => setIsMpinOpen(true)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-xs font-black transition-all shadow-lg shadow-emerald-600/10 active:scale-95 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" /> Release Secure Escrow Payout
              </button>
            ) : (
              <div className="text-xs text-amber-600 font-extrabold px-3 py-2 bg-amber-50 border border-amber-100 rounded-xl flex items-center gap-2">
                <Clock className="w-4 h-4 shrink-0" /> Goods marked as delivered! Awaiting buyer's confirmation or panel dispute grace period.
              </div>
            )}
          </div>
        )}

        {/* Dispute Actions (Multi-stage) */}
        {(escrow.status === 'FUNDED' || escrow.status === 'SHIPPED' || escrow.status === 'DELIVERED') && !isDigitalAsset && (
          <button 
            onClick={() => setView('disputes')}
            className="flex items-center gap-2 border border-rose-200 text-rose-600 hover:bg-rose-50 px-4 py-2 rounded-xl text-sm font-medium transition-colors"
          >
            <AlertCircle className="w-4 h-4" /> Raise Dispute
          </button>
        )}

        {escrow.status === 'DISPUTED' && (
          <button 
            onClick={() => setView('disputes')}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors shadow-lg shadow-amber-500/20"
          >
            <ShieldCheck className="w-4 h-4" /> View Dispute Evidence
          </button>
        )}

        {/* Info States */}
        {escrow.status === 'COMPLETED' && (
          <div className="w-full space-y-4 pt-3 border-t border-slate-100 mt-4.5">
            <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 px-4 py-2.5 rounded-2xl text-xs font-black border border-emerald-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" /> 
              <span>Secure Transaction Settled SUCCESSFULLY!</span>
            </div>

            {/* Dynamic Star Ratings and Badging Feedbacks */}
            {!(isBuyer ? escrow.reviewedByBuyer : escrow.reviewedBySeller) && !ratingSubmittedLocal ? (
              <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-505 uppercase tracking-widest">
                    ⭐ Rate counterparty to build P2P trust
                  </span>
                  <span className="bg-amber-100 text-amber-800 text-[9px] font-black uppercase px-2 py-0.5 rounded-md text-[8px]">
                    PENDING RATING
                  </span>
                </div>

                {/* Rating trigger */}
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingStars(star)}
                      className="transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                    >
                      <Star 
                        className={`w-7 h-7 ${star <= ratingStars ? 'text-amber-500 fill-amber-400' : 'text-slate-305'}`} 
                      />
                    </button>
                  ))}
                  <span className="text-xs font-black text-slate-700 ml-2 font-mono">{ratingStars}.0 / 5.0 Stars</span>
                </div>

                {/* Tag Select triggers */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block">
                    Choose Highlight Tags:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(isBuyer 
                      ? ["Fast Shipping", "Excellent Quality", "Recommended Seller", "Great Communication"]
                      : ["Prompt Funding", "Polite Buyer", "Fast Approval", "Highly Recommended"]
                    ).map((tag) => {
                      const isSelected = selectedRatingTags.includes(tag);
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            setSelectedRatingTags(prev => 
                              isSelected ? prev.filter(t => t !== tag) : [...prev, tag]
                            );
                          }}
                          className={`text-[9px] font-black uppercase tracking-tight px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
                            isSelected 
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/10'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {tag}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Comment area */}
                <textarea
                  placeholder="Leave a public written feedback detail here..."
                  value={ratingComment}
                  onChange={(e) => setRatingComment(e.target.value)}
                  rows={2}
                  className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-medium"
                />

                <button
                  type="button"
                  disabled={isSubmittingRating}
                  onClick={handleSubmitReview}
                  className="w-full bg-indigo-600 hover:bg-indigo-705 text-white font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-indigo-60s/15 disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
                  style={{ backgroundColor: '#4f46e5' }}
                >
                  {isSubmittingRating ? 'Saving stats...' : <><Sparkles className="w-4 h-4 animate-spin-slow" /> Submit P2P Rating</>}
                </button>
              </div>
            ) : (
              <div className="text-xs text-indigo-750 bg-indigo-50 border border-indigo-100 px-4 py-3 rounded-2xl flex items-center gap-2.5 mt-3 animate-fade-in">
                <ShieldCheck className="w-5 h-5 text-indigo-600 animate-pulse shrink-0" />
                <div>
                  <p className="font-extrabold uppercase tracking-tight text-[10px]">Trust Score Verified</p>
                  <p className="font-medium text-[11px] text-indigo-700/85 -mt-0.5">Your peer-to-peer reputation score feedback has been successfully locked in!</p>
                </div>
              </div>
            )}
          </div>
        )}

        {isBuyer && escrow.status === 'PROPOSED' && (
          <div className="text-sm text-slate-500 flex items-center gap-1.5 italic font-medium px-2 py-1 bg-slate-50 border border-slate-100 rounded-lg">
            Waiting for seller to accept...
          </div>
        )}

        {!isBuyer && escrow.status === 'ACCEPTED' && (
          <div className="text-sm text-slate-500 flex items-center gap-1.5 italic font-medium px-2 py-1 bg-slate-50 border border-slate-100 rounded-lg">
            Waiting for buyer to fund...
          </div>
        )}
      </div>
    </div>
  )}

      <TrustProfileModal 
        isOpen={isTrustModalOpen}
        onClose={() => setIsTrustModalOpen(false)}
        userId={isBuyer ? escrow.sellerId : escrow.buyerId}
        userPhone={isBuyer ? escrow.sellerPhone : escrow.buyerPhone}
      />

      <MpinVerificationModal 
        isOpen={isMpinOpen}
        onClose={() => setIsMpinOpen(false)}
        onVerifySuccess={async () => {
          await updateStatus('COMPLETED');
        }}
        escrowAmount={escrow.amount}
        itemDescription={escrow.itemDescription}
      />

    </motion.div>
  );
}


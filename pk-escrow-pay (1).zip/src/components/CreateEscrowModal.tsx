import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { db, auth } from '../lib/firebase';
import { sendNotification } from '../lib/notifications';
import { X, UserPlus, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { normalizePhoneNumber, getPhoneVariations } from '../lib/utils';

export function CreateEscrowModal({ isOpen, onClose, defaultDeliveryMode = 'digital' }: { isOpen: boolean; onClose: () => void; defaultDeliveryMode?: 'digital' | 'physical' | 'freelance' | 'digital_asset' }) {
  const { user, profile } = useAuth();
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [counterpartyPhone, setCounterpartyPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Escrow Delivery Category / Custom States
  const [deliveryMode, setDeliveryMode] = useState<'digital' | 'physical' | 'freelance' | 'digital_asset'>(defaultDeliveryMode);

  useEffect(() => {
    if (isOpen) {
      setDeliveryMode(defaultDeliveryMode);
    }
  }, [isOpen, defaultDeliveryMode]);
  const [assetType, setAssetType] = useState<'YouTube' | 'Facebook' | 'TikTok' | 'Gaming_ID'>('YouTube');
  const [digitalServiceType, setDigitalServiceType] = useState<'Streaming' | 'Software' | 'Canva' | 'VPN' | 'Hosting' | 'Other'>('Streaming');
  const [freelanceServiceType, setFreelanceServiceType] = useState<'Web_Dev' | 'Graphic_Design' | 'Video_Editing' | 'Content_Writing' | 'SEO' | 'Other'>('Web_Dev');
  const [projectDeadlines, setProjectDeadlines] = useState('');
  const [milestones, setMilestones] = useState('');

  // Physical Delivery Custom States
  const isPhysical = deliveryMode === 'physical';
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [shippingCity, setShippingCity] = useState('Karachi');
  const [shippingAddress, setShippingAddress] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setLoading(true);
    setError(null);

    try {
      const variations = getPhoneVariations(counterpartyPhone.trim());
      const normalizedPhone = normalizePhoneNumber(counterpartyPhone.trim());

      // 1. Find counterparty by phone number (trying all variations)
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('phoneNumber', 'in', variations));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        throw new Error('User not registered. Ensure the recipient has logged in to PK Escrow at least once to be "found" in the system.');
      }

      const counterparty = querySnapshot.docs[0];
      const counterpartyId = counterparty.id;
      const counterpartyData = counterparty.data();

      if (counterpartyId === user.uid) {
        throw new Error('You cannot initiate an escrow with yourself.');
      }

      // 2. Create Escrow record with promo 0% fee-less calculation
      const subVal = parseFloat(amount);
      if (isNaN(subVal) || subVal <= 0) {
        throw new Error('Please enter a valid transfer amount.');
      }

      const currentLimit = 2000000;

      // Query escrows initiated today by this user to verify daily total
      const escrowsRef = collection(db, 'escrows');
      const qInitiator = query(escrowsRef, where('initiatorId', '==', user.uid));
      const initiatorSnapshot = await getDocs(qInitiator);
      
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
      
      let dailyTotal = 0;
      initiatorSnapshot.forEach(docSnap => {
        const data = docSnap.data();
        let createdTime = 0;
        if (data.createdAt?.seconds) {
          createdTime = data.createdAt.seconds * 1000;
        } else if (data.createdAt) {
          createdTime = new Date(data.createdAt).getTime();
        }
        
        if (createdTime >= startOfToday && data.status !== 'CANCELLED') {
          dailyTotal += Number(data.amount || 0);
        }
      });

      if (dailyTotal + subVal > currentLimit) {
        throw new Error(`Transaction Limit Exceeded! The standard daily transaction volume limit is Rs. ${currentLimit.toLocaleString()}. You have already initiated Rs. ${dailyTotal.toLocaleString()} today. Adding Rs. ${subVal.toLocaleString()} would bring today's total to Rs. ${(dailyTotal + subVal).toLocaleString()}, which exceeds the Rs. ${currentLimit.toLocaleString()} limit.`);
      }

      const feeVal = 0;
      const totalVal = subVal;

      let finalDescription = description.trim();
      if (deliveryMode === 'freelance') {
        if (!projectDeadlines.trim() || !milestones.trim()) {
          throw new Error('Please fill in both the Project Deadlines and Milestones fields.');
        }
        const serviceTypeLabels: Record<string, string> = {
          Web_Dev: 'Web & Software Development',
          Graphic_Design: 'Graphic Design & UI/UX',
          Video_Editing: 'Video Editing & Animation',
          Content_Writing: 'Content Writing & Copywriting',
          SEO: 'SEO & Digital Marketing',
          Other: 'Other Custom Freelancing Work'
        };
        const prettyType = serviceTypeLabels[freelanceServiceType] || freelanceServiceType;
        finalDescription = `Freelance Service: ${prettyType}\nProject Deadline: ${projectDeadlines.trim()}\nMilestones: ${milestones.trim()}`;
      } else if (deliveryMode === 'digital_asset') {
        finalDescription = description.trim() 
          ? `Digital Asset: ${assetType} - ${description.trim()}` 
          : `Digital Asset: ${assetType} transfer`;
      } else if (deliveryMode === 'digital') {
        finalDescription = description.trim()
          ? `Digital Service: ${digitalServiceType} - ${description.trim()}`
          : `Digital Service: ${digitalServiceType} transfer`;
      }

      const escrowData: any = {
        buyerId: role === 'buyer' ? user.uid : counterpartyId,
        sellerId: role === 'seller' ? user.uid : counterpartyId,
        buyerPhone: role === 'buyer' ? user.phoneNumber : normalizedPhone,
        sellerPhone: role === 'seller' ? user.phoneNumber : normalizedPhone,
        amount: subVal,
        escrowFee: feeVal,
        totalAmount: totalVal,
        itemDescription: finalDescription,
        status: 'PROPOSED',
        initiatorId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        isPhysical: isPhysical,
        deliveryMode: deliveryMode,
      };

      if (deliveryMode === 'freelance') {
        escrowData.projectDeadlines = projectDeadlines.trim();
        escrowData.milestones = milestones.trim();
        escrowData.freelanceServiceType = freelanceServiceType;
      }

      if (deliveryMode === 'digital_asset') {
        escrowData.type = 'Digital_Asset';
        escrowData.assetType = assetType;
        escrowData.escrowStatus = 'Funds_Pending';
        escrowData.assetLoginCredentials = '';
        escrowData.inspectionTimer = null;
      }

      if (isPhysical) {
        if (!recipientName.trim() || !shippingAddress.trim()) {
          throw new Error('Please fill in both the Recipient Name and Shipping Address for physical delivery.');
        }
        escrowData.recipientName = recipientName.trim();
        escrowData.recipientPhone = recipientPhone.trim() || (role === 'buyer' ? (profile?.phoneNumber || user.phoneNumber) : normalizedPhone);
        escrowData.shippingCity = shippingCity.trim();
        escrowData.shippingAddress = shippingAddress.trim();
      }

      const docRef = await addDoc(collection(db, 'escrows'), escrowData);
      
      // Send real-time notification to the counterparty
      const isUserBuyer = role === 'buyer';
      const formattedAmount = parseFloat(amount).toLocaleString();
      const senderPhone = profile?.phoneNumber || user?.phoneNumber || '';
      await sendNotification(
        counterpartyId,
        isUserBuyer ? 'New Sale Proposal 💰' : 'Purchase Request 🛒',
        isUserBuyer 
          ? `Buyer ${senderPhone} proposed a secure contract of Rs. ${formattedAmount} for: "${description}".`
          : `Seller ${senderPhone} requested an escrow proposal of Rs. ${formattedAmount} for: "${description}".`,
        'INFO',
        docRef.id
      ).catch(e => console.warn('Failed to send proposal notification:', e));

      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create escrow');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[95vh]"
        >
          <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center shrink-0">
            <h2 className="text-xl font-bold text-slate-900">Create Escrow</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-full transition-colors shrink-0">
              <X className="w-5 h-5 text-slate-400" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
            {error && (
              <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl flex gap-3 text-rose-600 text-sm font-medium">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex bg-slate-100 p-1 rounded-2xl">
              <button
                type="button"
                onClick={() => setRole('buyer')}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${role === 'buyer' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'}`}
              >
                I am Buying
              </button>
              <button
                type="button"
                onClick={() => setRole('seller')}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${role === 'seller' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'}`}
              >
                I am Selling
              </button>
            </div>

            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col gap-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Your Testing ID</span>
              <span className="text-sm font-black text-slate-900">
                {profile?.phoneNumber || user?.phoneNumber || 'Linking phone...'}
              </span>
              <p className="text-[10px] font-medium text-slate-500 italic">Give this exact number to the other person to find you.</p>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
                {role === 'buyer' ? 'Seller Mobile Number' : 'Buyer Mobile Number'}
              </label>
              <input 
                type="tel" 
                required
                value={counterpartyPhone}
                onChange={(e) => setCounterpartyPhone(e.target.value)}
                placeholder="+92 3XX XXXXXXX"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-bold focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Amount (PKR)</label>
              <input 
                type="number" 
                required
                min="100"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="5000"
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-black focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-mono text-lg"
              />
            </div>

            {amount && parseFloat(amount) > 0 && (() => {
              const sub = parseFloat(amount) || 0;
              const fee = 0;
              const total = sub;
              return (
                <div className="bg-emerald-50/50 border border-emerald-100 rounded-2xl p-4.5 space-y-2 animate-fade-in">
                  <div className="flex justify-between items-center text-xs text-slate-500 font-bold">
                    <span>Subtotal:</span>
                    <span className="font-mono text-slate-700">Rs. {sub.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-500 font-bold">
                    <span>Platform Fee (Promo 0%):</span>
                    <span className="font-mono text-emerald-650">Rs. 0 (Free Launch)</span>
                  </div>
                  <div className="flex justify-between items-center text-sm font-black text-slate-900 border-t border-emerald-100/60 pt-2.5 mt-1">
                    <span>Total Escrow Value:</span>
                    <span className="font-mono text-emerald-700 text-base">Rs. {total.toLocaleString()}</span>
                  </div>
                </div>
              );
            })()}

            {deliveryMode === 'digital' && (
              <div className="space-y-4 pt-1 animate-fade-in text-slate-900">
                <div>
                  <label className="block text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-2 px-1">Type of Digital Service</label>
                  <select
                    value={digitalServiceType}
                    onChange={(e) => setDigitalServiceType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="Streaming">📺 Netflix / Streaming Accounts</option>
                    <option value="Software">🔑 Software License / Antivirus Keys</option>
                    <option value="Canva">🎨 Canva Pro / Premium Graphic Access</option>
                    <option value="VPN">🛡️ VPN Premium Access</option>
                    <option value="Hosting">🌐 Web Hosting / Domain Transfer</option>
                    <option value="Other">🛠️ Other Custom Digital Service</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Digital Service Details</label>
                  <textarea 
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g. Netflix Premium 1-Screen Panel, or Canva team invitation link..."
                    rows={3}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-medium focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-sm"
                  />
                </div>
              </div>
            )}

            {deliveryMode === 'physical' && (
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Physical Item Description & Quantity</label>
                <textarea 
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Leather jacket size M, Mobile phone package status, etc."
                  rows={3}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-medium focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-sm"
                />
              </div>
            )}

            {deliveryMode === 'digital_asset' && (
              <div className="space-y-4 pt-1 animate-fade-in text-slate-900">
                <div>
                  <label className="block text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] mb-2 px-1">Digital Asset Category</label>
                  <select
                    value={assetType}
                    onChange={(e) => setAssetType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="YouTube">🔴 YouTube Channel</option>
                    <option value="Facebook">🔵 Facebook Page</option>
                    <option value="TikTok">🎵 TikTok Account</option>
                    <option value="Gaming_ID">🎮 PUBG / Gaming ID</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Asset Details / URL / Handle</label>
                  <textarea 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g. @gaming_zone (50k Subscribers, Organic Reach)"
                    rows={2}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-medium focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-sm"
                  />
                </div>
              </div>
            )}

            {deliveryMode === 'freelance' && (
              <div className="space-y-4 pt-1 animate-fade-in text-slate-900">
                <div>
                  <label className="block text-[10px] font-black text-rose-600 uppercase tracking-[0.2em] mb-2 px-1">Type of Freelancing Service</label>
                  <select
                    value={freelanceServiceType}
                    onChange={(e) => setFreelanceServiceType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all text-sm cursor-pointer"
                  >
                    <option value="Web_Dev">💻 Web & Software Development</option>
                    <option value="Graphic_Design">🎨 Graphic Design & UI/UX</option>
                    <option value="Video_Editing">🎬 Video Editing & Animation</option>
                    <option value="Content_Writing">✍️ Content Writing & Copywriting</option>
                    <option value="SEO">📈 SEO & Digital Marketing</option>
                    <option value="Other">🛠️ Other Custom Freelancing Work</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-rose-500 uppercase tracking-[0.2em] mb-2 px-1">Project Deadlines</label>
                  <input 
                    type="text"
                    required
                    value={projectDeadlines}
                    onChange={(e) => setProjectDeadlines(e.target.value)}
                    placeholder="e.g. 5 June 2026 or 2 Weeks"
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all text-sm"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] mb-2 px-1">Milestones</label>
                  <textarea 
                    required
                    value={milestones}
                    onChange={(e) => setMilestones(e.target.value)}
                    placeholder="e.g. Milestone 1: UI Design (50%), Milestone 2: Code Integration (50%)"
                    rows={3}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 text-slate-900 font-medium focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all text-sm leading-relaxed"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">Escrow Delivery Mode</label>
              <div className="grid grid-cols-4 gap-1 bg-slate-50 border border-slate-200/60 p-1 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setDeliveryMode('digital')}
                  className={`py-2 px-0.5 rounded-xl text-[9px] font-black uppercase tracking-tight transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${deliveryMode === 'digital' ? 'bg-white shadow-sm border border-slate-100 text-indigo-700' : 'text-slate-500'}`}
                >
                  <span>💻</span>
                  <span>Digital</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryMode('physical')}
                  className={`py-2 px-0.5 rounded-xl text-[9px] font-black uppercase tracking-tight transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${deliveryMode === 'physical' ? 'bg-indigo-600 font-extrabold text-white shadow-md shadow-indigo-600/10' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <span>📦</span>
                  <span>Physical</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryMode('freelance')}
                  className={`py-2 px-0.5 rounded-xl text-[9px] font-black uppercase tracking-tight transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${deliveryMode === 'freelance' ? 'bg-rose-600 font-extrabold text-white shadow-md shadow-rose-600/10' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <span>⚡</span>
                  <span>Freelance</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryMode('digital_asset')}
                  className={`py-2 px-0.5 rounded-xl text-[9px] font-black uppercase tracking-tight transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${deliveryMode === 'digital_asset' ? 'bg-amber-500 font-extrabold text-white shadow-md shadow-amber-500/10' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <span>🔑</span>
                  <span>Asset</span>
                </button>
              </div>
            </div>

            {isPhysical && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-indigo-50/40 border border-indigo-100 p-4.5 rounded-2xl space-y-3.5 animate-fade-in"
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] bg-indigo-100 text-indigo-700 font-black tracking-widest uppercase px-2 py-0.5 rounded">
                    ✏️ Shipping Recipient Info
                  </span>
                </div>

                <div className="space-y-2.5 pt-1">
                  <div>
                    <label className="block text-[9px] font-black text-indigo-600 uppercase tracking-wider mb-1 px-0.5">Recipient Full Name</label>
                    <input 
                      type="text"
                      required={isPhysical}
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="e.g. Muhammad Amjad"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 animate-fade-in"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-black text-indigo-600 uppercase tracking-wider mb-1 px-0.5">Recipient Phone Number</label>
                    <input 
                      type="tel"
                      value={recipientPhone}
                      onChange={(e) => setRecipientPhone(e.target.value)}
                      placeholder="e.g. +92 321 4567890 (optional)"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-black text-indigo-600 uppercase tracking-wider mb-1 px-0.5">Shipping City</label>
                    <select
                      value={shippingCity}
                      onChange={(e) => setShippingCity(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Karachi">Karachi</option>
                      <option value="Lahore">Lahore</option>
                      <option value="Islamabad">Islamabad</option>
                      <option value="Rawalpindi">Rawalpindi</option>
                      <option value="Faisalabad">Faisalabad</option>
                      <option value="Multan">Multan</option>
                      <option value="Peshawar">Peshawar</option>
                      <option value="Quetta">Quetta</option>
                      <option value="Sialkot">Sialkot</option>
                      <option value="Gujranwala">Gujranwala</option>
                      <option value="Hyderabad">Hyderabad</option>
                      <option value="Other">Other City</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-black text-indigo-600 uppercase tracking-wider mb-1 px-0.5">Full Street / Delivery Address</label>
                    <textarea 
                      required={isPhysical}
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      placeholder="House No, Street name, Sector / Area details..."
                      rows={2}
                      className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 leading-relaxed"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            <button 
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-emerald-600/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? 'Processing...' : <><UserPlus className="w-5 h-5" /> Initiate Escrow</>}
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

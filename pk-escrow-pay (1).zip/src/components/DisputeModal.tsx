import React, { useState, useEffect } from 'react';
import { doc, getDoc, setDoc, updateDoc, arrayUnion, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { X, AlertTriangle, Send, FileText, User, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Escrow } from './EscrowCard';

interface DisputeModalProps {
  isOpen: boolean;
  onClose: () => void;
  escrow: Escrow;
}

export function DisputeModal({ isOpen, onClose, escrow }: DisputeModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [dispute, setDispute] = useState<any>(null);
  const [note, setNote] = useState('');
  const [attachment, setAttachment] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && escrow.id) {
      fetchDispute();
    } else {
      setDispute(null);
      setNote('');
      setAttachment('');
      setError(null);
    }
  }, [isOpen, escrow.id]);

  const fetchDispute = async () => {
    try {
      const docSnap = await getDoc(doc(db, 'disputes', escrow.id));
      if (docSnap.exists()) {
        setDispute(docSnap.data());
      }
    } catch (err) {
      console.error("Error fetching dispute:", err);
    }
  };

  const handleSubmitEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !note.trim()) return;

    setLoading(true);
    setError(null);

    const evidenceItem = {
      userId: user.uid,
      note: note.trim(),
      attachments: attachment ? [attachment] : [],
      createdAt: new Date().toISOString()
    };

    try {
      if (!dispute) {
        // Create new dispute case
        await setDoc(doc(db, 'disputes', escrow.id), {
          escrowId: escrow.id,
          initiatorId: user.uid,
          reason: note.trim(),
          evidence: [evidenceItem],
          status: 'OPEN',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        
        // Update escrow status
        await updateDoc(doc(db, 'escrows', escrow.id), {
          status: 'DISPUTED',
          updatedAt: serverTimestamp()
        });
      } else {
        // Add to existing evidence
        await updateDoc(doc(db, 'disputes', escrow.id), {
          evidence: arrayUnion(evidenceItem),
          updatedAt: new Date().toISOString()
        });
      }
      
      setNote('');
      setAttachment('');
      fetchDispute();
    } catch (err: any) {
      setError(err.message || "Failed to submit evidence");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden relative z-10 flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-rose-50/50">
              <div className="flex items-center gap-3 text-rose-600">
                <AlertTriangle className="w-6 h-6 border-2 border-rose-600 rounded-lg p-0.5" />
                <h2 className="text-2xl font-black tracking-tight">Dispute Resolution</h2>
              </div>
              <button onClick={onClose} className="p-2.5 hover:bg-rose-100/50 rounded-2xl transition-all">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
              {/* Context Info */}
              <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Transaction</p>
                  <h3 className="text-lg font-black text-slate-900">{escrow.itemDescription}</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase">TX ID: {escrow.id.toUpperCase()}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Amount</p>
                  <p className="text-xl font-black text-rose-600">Rs. {escrow.amount.toLocaleString()}</p>
                </div>
              </div>

              {/* Status Section */}
              {dispute && (
                <div className={`flex items-center gap-4 p-4 rounded-2xl border ${
                  dispute.status === 'RESOLVED' ? 'bg-emerald-50 border-emerald-100' : 'bg-amber-50 border-amber-100'
                }`}>
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    dispute.status === 'RESOLVED' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'
                  }`}>
                    {dispute.status === 'RESOLVED' ? <CheckCircle2 className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
                  </div>
                  <div className="flex-1">
                    <p className={`text-[10px] font-black uppercase tracking-widest ${
                      dispute.status === 'RESOLVED' ? 'text-emerald-600' : 'text-amber-600'
                    }`}>Case Status</p>
                    <p className="text-sm font-black text-slate-900">
                      {dispute.status} 
                      <span className="text-slate-400 font-medium ml-2">
                        {dispute.status === 'OPEN' ? '— Moderator review in progress' : 
                         dispute.status === 'RESOLVED' ? '— This dispute has been settled' : 
                         '— Case is currently under review'}
                      </span>
                    </p>
                  </div>
                </div>
              )}

              {/* Initial Reason */}
              {dispute?.reason && (
                <div className="bg-slate-50 border-l-4 border-rose-500 p-6 rounded-r-3xl">
                  <h4 className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-2">Original Dispute Reason</h4>
                  <p className="text-base font-bold text-slate-900 leading-relaxed italic">"{dispute.reason}"</p>
                  <p className="text-[10px] text-slate-400 font-bold mt-2">Opened by {dispute.initiatorId === user?.uid ? 'You' : 'Counterparty'}</p>
                </div>
              )}

              {/* Evidence History */}
              {dispute?.evidence && (
                <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Evidence & Communication</h4>
                  <div className="space-y-4">
                    {dispute.evidence.map((ev: any, i: number) => (
                      <div key={i} className={`flex flex-col gap-2 ${ev.userId === user?.uid ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[85%] rounded-3xl p-4 shadow-sm border ${ev.userId === user?.uid ? 'bg-emerald-50 border-emerald-100 rounded-tr-none' : 'bg-white border-slate-100 rounded-tl-none'}`}>
                          <div className="flex items-center gap-2 mb-2">
                             <User className="w-3 h-3 text-slate-400" />
                             <span className="text-[10px] font-black uppercase text-slate-400 tracking-tighter">
                               {ev.userId === user?.uid ? 'You' : 'Counterparty'} • {new Date(ev.createdAt).toLocaleString()}
                             </span>
                          </div>
                          <p className="text-sm font-bold text-slate-800 leading-relaxed">{ev.note}</p>
                          {ev.attachments?.map((at: string, j: number) => (
                            <a key={j} href={at} target="_blank" rel="noreferrer" className="mt-3 block p-2 bg-white rounded-xl border border-slate-100 hover:border-emerald-500 transition-colors">
                               <div className="flex items-center gap-2 text-xs font-black text-slate-600">
                                 <FileText className="w-4 h-4 text-emerald-500" />
                                 View Attached Evidence
                               </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    ))}
                    {dispute.moderatorNotes && (
                      <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-6">
                        <div className="flex items-center gap-2 mb-3">
                           <ShieldCheck className="w-5 h-5 text-indigo-600" />
                           <span className="text-xs font-black uppercase tracking-widest text-indigo-600">Moderator Resolution Note</span>
                        </div>
                        <p className="text-sm font-bold text-indigo-900 italic">"{dispute.moderatorNotes}"</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Submit Form */}
              <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6">
                  <div className="mb-4 bg-rose-50 border border-rose-100 rounded-2xl p-4 flex gap-3 text-xs text-rose-800 font-bold leading-relaxed">
                    <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-black uppercase tracking-wider text-[10px] text-rose-700 mb-0.5">Strict Evidence Proof Rules</p>
                      <p className="font-semibold text-[11px]">
                        You have exactly <strong className="font-extrabold">24 Hours</strong> to submit genuine escrow evidence. Anyone submitting fake receipts, altered images, or edited screenshots will face an <strong className="font-extrabold">immediate account ban without warning</strong> and absolute forfeiture of wallet balances.
                      </p>
                    </div>
                  </div>

                 <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Add Your Evidence</h4>
                 <form onSubmit={handleSubmitEvidence} className="space-y-4">
                    <textarea 
                      required
                      placeholder="Explain the issue in detail. Provide dates, what happened, and why you are disputing this transaction..."
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-2xl p-4 text-sm font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 h-32 resize-none"
                    />
                    <div className="relative">
                      <FileText className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="url"
                        placeholder="Link to image or file proof (Optional)"
                        value={attachment}
                        onChange={(e) => setAttachment(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-3 text-xs font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500"
                      />
                    </div>
                    {error && <p className="text-xs font-black text-rose-600 px-2">{error}</p>}
                    <button 
                      type="submit"
                      disabled={loading}
                      className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-slate-900/10 flex items-center justify-center gap-2"
                    >
                      {loading ? 'Submitting...' : dispute ? 'Submit Additional Evidence' : 'Open Dispute Case'}
                      <Send className="w-4 h-4" />
                    </button>
                 </form>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-4 bg-slate-50 text-center border-t border-slate-100">
               <p className="text-[10px] font-bold text-slate-400 flex items-center justify-center gap-2">
                 <ShieldCheck className="w-3 h-3" />
                 Moderators usually respond within 24-48 business hours
               </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

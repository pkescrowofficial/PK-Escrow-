import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { X, Star, CheckCircle2, ShieldCheck, Flame, Award, AlertTriangle, Sparkles, User, BadgeAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Review {
  id: string;
  escrowId: string;
  reviewerId: string;
  reviewerPhone?: string;
  reviewerName?: string;
  targetId: string;
  rating: number;
  comment: string;
  tags?: string[];
  createdAt: any;
}

interface UserProfile {
  uid: string;
  displayName: string;
  phoneNumber: string;
  completedDeals?: number;
  disputesCount?: number;
  ratingSum?: number;
  ratingCount?: number;
  isVerified?: boolean;
}

export function TrustProfileModal({ 
  isOpen, 
  onClose, 
  userId,
  userPhone
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  userId?: string | null;
  userPhone?: string | null;
}) {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    if (!isOpen) return;

    const fetchTrustProfile = async () => {
      setLoading(true);
      try {
        let targetUid = userId;

        // 1. If we only have phoneNumber, find the user doc
        if (!targetUid && userPhone) {
          const usersRef = collection(db, 'users');
          const q = query(usersRef, where('phoneNumber', '==', userPhone));
          const snap = await getDocs(q);
          if (!snap.empty) {
            targetUid = snap.docs[0].id;
          }
        }

        if (!targetUid) {
          setLoading(false);
          return;
        }

        // 2. Fetch User Record
        const userDocRef = doc(db, 'users', targetUid);
        const userDocSnap = await getDoc(userDocRef);
        if (userDocSnap.exists()) {
          const data = userDocSnap.data();
          setProfile({
            uid: targetUid,
            displayName: data.displayName || 'P2P Member',
            phoneNumber: data.phoneNumber || '',
            completedDeals: data.completedDeals || 0,
            disputesCount: data.disputesCount || 0,
            ratingSum: data.ratingSum || 0,
            ratingCount: data.ratingCount || 0,
            isVerified: data.isVerified || false,
          });
        }

        // 3. Fetch Reviews received by this target user
        const reviewsRef = collection(db, 'reviews');
        const rQuery = query(reviewsRef, where('targetId', '==', targetUid));
        const rSnap = await getDocs(rQuery);
        
        const fetchedReviews: Review[] = [];
        rSnap.forEach((doc) => {
          const d = doc.data();
          fetchedReviews.push({
            id: doc.id,
            escrowId: d.escrowId,
            reviewerId: d.reviewerId,
            reviewerPhone: d.reviewerPhone || 'P2P Member',
            reviewerName: d.reviewerName || 'Anonymous',
            targetId: d.targetId,
            rating: d.rating || 5,
            comment: d.comment || '',
            tags: d.tags || [],
            createdAt: d.createdAt,
          });
        });

        // Simple client sort by date string
        fetchedReviews.sort((a,b) => {
          const aTime = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const bTime = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return bTime - aTime;
        });

        setReviews(fetchedReviews);
      } catch (err) {
        console.error("Error loading trust metrics:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchTrustProfile();
  }, [isOpen, userId, userPhone]);

  if (!isOpen) return null;

  // Calculative aggregates
  const completed = profile?.completedDeals || 0;
  const disputes = profile?.disputesCount || 0;
  const totalTrades = completed + disputes;
  const successRatio = totalTrades > 0 ? Math.round((completed / totalTrades) * 100) : 100;

  const totalRatingCount = profile?.ratingCount || reviews.length || 0;
  const totalSum = profile?.ratingSum || reviews.reduce((acc, r) => acc + r.rating, 0) || 0;
  const ratingAvg = totalRatingCount > 0 ? parseFloat((totalSum / totalRatingCount).toFixed(1)) : 5.0;

  // Reputation Label Designation
  let badgeTitle = "🆕 New Contractor";
  let badgeColor = "bg-slate-100 text-slate-600 border-slate-200";
  let badgeIcon = <User className="w-4 h-4" />;
  let badgeDesc = "A newcomer learning secure transactions on the platform.";

  if (completed >= 8 && ratingAvg >= 4.7) {
    badgeTitle = "👑 P2P King Merch";
    badgeColor = "bg-amber-500 text-white border-transparent shadow-lg shadow-amber-500/20";
    badgeIcon = <Award className="w-4 h-4 stroke-[2.5]" />;
    badgeDesc = "Elite grade participant with impeccable deal history and feedback.";
  } else if (completed >= 4 && ratingAvg >= 4.5) {
    badgeTitle = "🛡️ Trusted Merchant";
    badgeColor = "bg-emerald-600 text-white border-transparent";
    badgeIcon = <ShieldCheck className="w-4 h-4" />;
    badgeDesc = "Solid reputation score, reliable verification and prompt performance.";
  } else if (completed >= 1) {
    badgeTitle = "🤝 Verified Contractor";
    badgeColor = "bg-indigo-50 text-indigo-700 border-indigo-200";
    badgeIcon = <CheckCircle2 className="w-4 h-4" />;
    badgeDesc = "Completed certified escrows smoothly on PK Escrow system.";
  }

  // Tags aggregation count
  const allTags = reviews.flatMap(r => r.tags || []);
  const tagCounts = allTags.reduce((acc, curr) => {
    acc[curr] = (acc[curr] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedCounterTags = Object.entries(tagCounts).map(([k, v]) => [k, Number(v)] as [string, number]);
  sortedCounterTags.sort((a, b) => b[1] - a[1]);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="px-6 py-4.5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500 fill-amber-500 animate-pulse" />
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Trust Core™ P2P Verification</h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors cursor-pointer">
              <X className="w-5 h-5 text-slate-500" />
            </button>
          </div>

          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin" />
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Syncing secure ledger...</p>
            </div>
          ) : !profile ? (
            <div className="p-10 text-center space-y-4">
              <div className="w-16 h-16 bg-rose-50 rounded-2xl flex items-center justify-center mx-auto text-rose-500">
                <BadgeAlert className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-black text-slate-900">Account Offline</h3>
              <p className="text-xs text-slate-500 font-medium max-w-xs mx-auto">
                The specified user is registered but has not completed trust profile onboarding or has an inactive wallet node.
              </p>
            </div>
          ) : (
            <div className="overflow-y-auto flex-1 p-6 space-y-6">
              {/* Profile Card Summary */}
              <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 p-6 rounded-2xl text-white relative overflow-hidden shadow-lg border border-indigo-950">
                <div className="absolute top-0 right-0 p-3 text-indigo-500/10 pointer-events-none">
                  <ShieldCheck className="w-32 h-32 -translate-x-2 translate-y-2 stroke-[1.5]" />
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                  <div>
                    <span className="text-[9px] bg-indigo-500/20 text-indigo-300 font-black tracking-widest uppercase px-2.5 py-1 rounded-full border border-indigo-500/30">
                      PK Escrow Ledger ID
                    </span>
                    <h3 className="text-2xl font-black mt-2 tracking-tight">{profile.displayName}</h3>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">{profile.phoneNumber}</p>
                  </div>

                  <div className={`px-4 py-2 rounded-2xl border text-xs font-black uppercase tracking-tight flex items-center gap-1.5 ${badgeColor}`}>
                    {badgeIcon}
                    <span>{badgeTitle}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 mt-3 font-medium leading-relaxed italic border-t border-indigo-950/50 pt-3">
                  "{badgeDesc}"
                </p>

                {/* Main Metrics Row */}
                <div className="grid grid-cols-3 gap-3.5 mt-5 pt-4 border-t border-white/15">
                  <div className="text-center">
                    <p className="text-[9px] font-black uppercase tracking-wider text-slate-500">Reputation Score</p>
                    <p className="text-xl font-black text-amber-400 flex items-center justify-center gap-1 mt-0.5">
                      <span>{ratingAvg}</span>
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 stroke-[2.5]" />
                    </p>
                  </div>
                  <div className="text-center border-x border-white/10">
                    <p className="text-[9px] font-black uppercase tracking-wider text-slate-500">Deals Settled</p>
                    <p className="text-xl font-black text-emerald-400 mt-0.5">{completed}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[9px] font-black uppercase tracking-wider text-slate-500">Safe Success</p>
                    <p className="text-xl font-black text-indigo-350 mt-0.5">{successRatio}%</p>
                  </div>
                </div>
              </div>

              {/* Status Verification Checks */}
              <div className="space-y-2.5">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-0.5">National Security Verifications</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
                  <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-[10px] font-black text-slate-800 tracking-tight uppercase">SMS Verified</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <CheckCircle2 className={`w-4 h-4 ${profile.isVerified ? 'text-emerald-600' : 'text-slate-300'}`} />
                    <span className="text-[10px] font-black text-slate-800 tracking-tight uppercase">NADRA CNIC</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 col-span-2 md:col-span-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-[10px] font-black text-slate-800 tracking-tight uppercase">P2P Wallet Linked</span>
                  </div>
                </div>
              </div>

              {/* Aggregated Quick Feedback Tags */}
              {sortedCounterTags.length > 0 && (
                <div className="space-y-2.5">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-0.5">Merchant Highlights</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {sortedCounterTags.map(([tag, count]) => (
                      <span 
                        key={tag}
                        className="bg-indigo-50 text-indigo-700 font-extrabold text-[10px] uppercase tracking-tighter px-3 py-1 rounded-xl border border-indigo-100 flex items-center gap-1"
                      >
                        <span>{tag}</span>
                        <span className="bg-indigo-200 text-indigo-800 px-1.5 py-0.2 rounded-md font-black text-[9px]">{count}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Detailed Reviews & Star Feedbacks list */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-0.5">
                  Ledger Feedbacks ({reviews.length})
                </h4>

                {reviews.length === 0 ? (
                  <div className="text-center p-8 bg-slate-50 rounded-2xl border border-slate-100 italic text-slate-400 text-xs">
                    No individual transaction reviews written yet. Completed escrows are scored automatically.
                  </div>
                ) : (
                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                    {reviews.map((r) => (
                      <div key={r.id} className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-2 shadow-sm">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-xs font-black text-slate-800">
                              {r.reviewerName || 'P2P Member'} 
                              <span className="text-[9px] text-slate-400 font-mono font-bold ml-1">{r.reviewerPhone}</span>
                            </p>
                            <p className="text-[8px] text-slate-400 font-bold">
                              {r.createdAt ? new Date(r.createdAt).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' }) : ''}
                            </p>
                          </div>

                          <div className="flex bg-slate-50 border border-slate-100 px-2 py-1 rounded-xl items-center gap-0.5">
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            <span className="text-xs font-black text-slate-800">{r.rating}</span>
                          </div>
                        </div>

                        {r.comment && (
                          <p className="text-slate-600 text-xs font-medium leading-relaxed">
                            "{r.comment}"
                          </p>
                        )}

                        {r.tags && r.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-1">
                            {r.tags.map(t => (
                              <span key={t} className="text-[8px] bg-slate-100 text-slate-500 font-black px-1.5 py-0.5 rounded uppercase">
                                #{t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

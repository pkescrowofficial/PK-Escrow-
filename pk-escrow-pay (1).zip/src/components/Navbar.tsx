import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { collection, query, where, onSnapshot, doc, updateDoc, writeBatch } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { AppNotification } from '../lib/notifications';
import { 
  ShieldCheck, 
  User as UserIcon, 
  Plus, 
  Wallet, 
  LogOut, 
  LayoutDashboard, 
  History, 
  Scale, 
  Bell, 
  Check, 
  CheckCheck, 
  AlertCircle, 
  Clock, 
  Sparkles,
  Eye
} from 'lucide-react';
import { ProfileModal } from './ProfileModal';
import { TermsModal } from './TermsModal';
import { getTranslation } from '../lib/translations';

function playChime() {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // First frequency note (C5)
    const osc1 = audioCtx.createOscillator();
    const gain1 = audioCtx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(523.25, audioCtx.currentTime);
    gain1.gain.setValueAtTime(0.08, audioCtx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
    osc1.connect(gain1);
    gain1.connect(audioCtx.destination);
    osc1.start();
    osc1.stop(audioCtx.currentTime + 0.3);

    // Second frequency note slightly offset (G5)
    setTimeout(() => {
      const osc2 = audioCtx.createOscillator();
      const gain2 = audioCtx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(783.99, audioCtx.currentTime);
      gain2.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain2.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
      osc2.connect(gain2);
      gain2.connect(audioCtx.destination);
      osc2.start();
      osc2.stop(audioCtx.currentTime + 0.4);
    }, 120);
  } catch (err) {
    console.warn('Audio chime ignored:', err);
  }
}

function formatRelativeTime(timestamp: any): string {
  if (!timestamp) return 'Just now';
  const date = timestamp.seconds ? new Date(timestamp.seconds * 1000) : new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  
  if (isNaN(date.getTime())) return 'Just now';
  
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return 'Just now';
  
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  
  const diffDays = Math.floor(diffHr / 24);
  return `${diffDays}d ago`;
}

const getNotificationStyles = (type: string) => {
  switch (type) {
    case 'SUCCESS':
      return { iconBg: 'bg-emerald-500 text-white' };
    case 'WARNING':
      return { iconBg: 'bg-amber-500 text-white' };
    case 'DANGER':
      return { iconBg: 'bg-rose-500 text-white' };
    case 'INFO':
    default:
      return { iconBg: 'bg-indigo-500 text-white' };
  }
};

export function Navbar() {
  const { user, profile, logout, view, setView, lang, setLang } = useAuth();
  const t = getTranslation(lang);
  
  const getFirstName = () => {
    if (profile?.displayName) {
      const parts = profile.displayName.split(' ');
      if (profile.displayName.startsWith('User ') && (profile.email || user?.email)) {
        const emailAddress = profile.email || user?.email || '';
        const prefix = emailAddress.split('@')[0].split(/[0-9_.-]/)[0];
        if (prefix) {
          return prefix.charAt(0).toUpperCase() + prefix.slice(1);
        }
      }
      return parts[0];
    }
    const fallbackEmail = profile?.email || user?.email || 'mohsinsmartshop@gmail.com';
    const prefix = fallbackEmail.split('@')[0].split(/[0-9_.-]/)[0];
    if (prefix) {
      return prefix.charAt(0).toUpperCase() + prefix.slice(1);
    }
    return 'Mohsin';
  };

  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [activeToast, setActiveToast] = useState<{ id: string; title: string; message: string; type: string } | null>(null);

  // Real-time notifications listener
  useEffect(() => {
    if (!user?.uid) return;

    const mountTime = Date.now();
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      let playSound = false;
      let newAlert: any = null;

      const items = snapshot.docs.map(docSnap => {
        const data = docSnap.data();
        const id = docSnap.id;

        const createdTime = data.createdAt?.seconds 
          ? data.createdAt.seconds * 1000 
          : (data.createdAt ? new Date(data.createdAt).getTime() : Date.now());

        // Only play sound and alert for notifications created after navbar is mounted and is unread
        if (createdTime > mountTime && !data.isRead) {
          playSound = true;
          newAlert = { id, title: data.title, message: data.message, type: data.type };
        }

        return {
          id,
          ...data
        } as AppNotification;
      });

      // Sort items descending by creation date in memory
      items.sort((a, b) => {
        const aVal = a.createdAt?.seconds ? a.createdAt.seconds * 1000 : (a.createdAt ? new Date(a.createdAt).getTime() : 0);
        const bVal = b.createdAt?.seconds ? b.createdAt.seconds * 1000 : (b.createdAt ? new Date(b.createdAt).getTime() : 0);
        return bVal - aVal;
      });

      setNotifications(items);

      if (playSound && newAlert) {
        playChime();
        setActiveToast(newAlert);
        // Automatically hide on-screen alert banner after 4.5 seconds
        setTimeout(() => {
          setActiveToast(prev => prev?.id === newAlert.id ? null : prev);
        }, 4500);
      }
    }, (err) => {
      console.warn("Real-time notifications listener subscription failed:", err);
      handleFirestoreError(err, OperationType.LIST, `notifications/${user?.uid}`);
    });

    return () => unsubscribe();
  }, [user]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { isRead: true });
    } catch (e) {
      console.error('Failed to mark notification as read:', e);
    }
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.isRead);
    if (unread.length === 0) return;
    try {
      const batch = writeBatch(db);
      unread.forEach(n => {
        if (n.id) {
          const ref = doc(db, 'notifications', n.id);
          batch.update(ref, { isRead: true });
        }
      });
      await batch.commit();
    } catch (e) {
      console.error('Failed to mark all as read:', e);
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <nav id="main-nav" className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm px-4">
      {/* Real-time Toast Banner overlay */}
      {activeToast && (
        <div className="fixed top-24 right-4 z-[9999] max-w-sm w-full bg-slate-900 border border-slate-800 text-white rounded-3xl shadow-2xl p-4.5 flex items-start gap-4 ring-4 ring-emerald-500/10">
          <div className="p-2.5 bg-emerald-600 rounded-2xl text-white shadow-md shadow-emerald-600/20">
            <Bell className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-black uppercase tracking-wider text-emerald-400">Live Update Alert</h4>
            <h5 className="text-sm font-extrabold tracking-tight text-white mt-1 break-words">{activeToast.title}</h5>
            <p className="text-[11px] text-slate-350 mt-1 font-semibold leading-relaxed break-words">{activeToast.message}</p>
          </div>
          <button 
            type="button"
            onClick={() => setActiveToast(null)}
            className="text-slate-400 hover:text-white font-black text-xs p-1"
          >
            ✕
          </button>
        </div>
      )}

      <div className="max-w-7xl mx-auto py-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          <div className="flex items-center justify-between lg:justify-start gap-4 sm:gap-6 w-full lg:w-auto">
            {/* Brand */}
            <div className="flex items-center gap-4">
              <div className="bg-emerald-600 p-2.5 rounded-2xl shadow-lg shadow-emerald-600/20">
                <ShieldCheck className="text-white w-7 h-7" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center">
                  <span className="text-xl font-black text-slate-900 tracking-tight leading-none">{t.brand}</span>
                </div>
                {profile && (
                  <div className="flex flex-col mt-0.5">
                    <span className="text-sm font-bold text-slate-500 uppercase tracking-wider">{profile.displayName}</span>
                    <span className="text-[10px] text-emerald-600 font-extrabold uppercase tracking-wider leading-none mt-0.5">First Name: {getFirstName()}</span>
                  </div>
                )}
              </div>
              
              {/* Language Choice Switcher */}
              <div className="flex bg-slate-100 p-0.5 rounded-xl border border-slate-200 shrink-0">
                <button
                  type="button"
                  onClick={() => setLang('en')}
                  className={`px-2 py-0.5 rounded-lg text-[9px] font-black tracking-wider transition-all cursor-pointer ${lang === 'en' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  EN
                </button>
                <button
                  type="button"
                  onClick={() => setLang('ur')}
                  className={`px-2 py-0.5 rounded-lg text-[9px] font-black tracking-wider transition-all cursor-pointer ${lang === 'ur' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  اردو
                </button>
              </div>
            </div>

            {/* Real-time Notifications Bell Dropdown (Moved Uper/Upward to top bar block) */}
            <div className="relative">
              <button 
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className={`w-10 h-10 flex items-center justify-center bg-white border rounded-xl hover:border-indigo-200 hover:text-indigo-600 transition-all shadow-sm cursor-pointer relative ${isNotificationsOpen ? 'border-indigo-600 text-indigo-600 ring-4 ring-indigo-50' : 'border-slate-200 text-slate-400'}`}
                title="Notifications alert"
              >
                <Bell className={`w-5 h-5 ${unreadCount > 0 ? 'animate-swing' : ''}`} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-white select-none">
                    {unreadCount}
                  </span>
                )}
              </button>

              {isNotificationsOpen && (
                <>
                  {/* Backdrop Overlay */}
                  <div 
                    className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-[1000] cursor-pointer"
                    onClick={() => setIsNotificationsOpen(false)}
                  />
                  
                  {/* Centered Modal Panel */}
                  <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[calc(100%-2rem)] max-w-sm sm:max-w-md bg-white border border-slate-200 rounded-3xl shadow-2xl z-[1001] py-1 max-h-[80vh] overflow-hidden flex flex-col text-slate-800 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-5 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 sticky top-0 backdrop-blur-md">
                      <div>
                        <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">In-App Alerts</h3>
                        <p className="text-[10px] font-bold text-slate-400 mt-0.5">{unreadCount} unread currently</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {unreadCount > 0 && (
                          <button 
                            onClick={markAllAsRead}
                            className="text-[9px] font-black text-indigo-600 hover:text-indigo-800 uppercase tracking-widest cursor-pointer hover:underline flex items-center gap-1"
                          >
                            <CheckCheck className="w-3.5 h-3.5" /> Mark all read
                          </button>
                        )}
                        <button
                          onClick={() => setIsNotificationsOpen(false)}
                          className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs font-bold transition-colors cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                    </div>

                    <div className="divide-y divide-slate-100/80 overflow-y-auto flex-1">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center flex flex-col items-center justify-center">
                          <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-3">
                            <Sparkles className="w-6 h-6 text-slate-300" />
                          </div>
                          <p className="text-xs font-extrabold text-slate-800 animate-pulse">All Caught Up!</p>
                          <p className="text-[10px] text-slate-400 mt-1 max-w-[200px] leading-relaxed mx-auto">You will receive live updates as transactions, trades and contracts progress.</p>
                        </div>
                      ) : (
                        notifications.map((n) => {
                          const style = getNotificationStyles(n.type);
                          return (
                            <div 
                              key={n.id} 
                              onClick={() => {
                                if (n.id) markAsRead(n.id);
                                if (n.link) setView('dashboard');
                                setIsNotificationsOpen(false);
                              }}
                              className={`p-4 hover:bg-slate-50 cursor-pointer transition-colors flex items-start gap-3 relative ${!n.isRead ? 'bg-slate-50/50' : ''}`}
                            >
                              {!n.isRead && (
                                <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-indigo-600 rounded-full" />
                              )}
                              
                              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${style.iconBg} text-xs shadow-sm`}>
                                {n.type === 'SUCCESS' ? <Check className="w-4 h-4 shrink-0 font-black" /> : 
                                 n.type === 'WARNING' ? <Clock className="w-4 h-4 shrink-0 font-black" /> :
                                 n.type === 'DANGER' ? <AlertCircle className="w-4 h-4 shrink-0 font-black" /> :
                                 <Bell className="w-4 h-4 shrink-0 font-black" />}
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start gap-1">
                                  <p className={`text-xs font-black truncate ${!n.isRead ? 'text-slate-900' : 'text-slate-500'}`}>
                                    {n.title}
                                  </p>
                                  <span className="text-[8px] font-black font-mono text-slate-400 shrink-0 uppercase tracking-tighter">
                                    {formatRelativeTime(n.createdAt)}
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-550 font-semibold mt-1 line-clamp-2 leading-relaxed break-words">
                                  {n.message}
                                </p>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Navigation Tabs */}
            <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 scale-90 sm:scale-100 origin-left">
              <button 
                onClick={() => setView('dashboard')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'dashboard' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden xs:inline">{t.dashboard}</span>
              </button>
              <button 
                onClick={() => setView('transactions')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'transactions' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <History className="w-4 h-4" />
                <span className="hidden xs:inline">{t.history}</span>
              </button>
              <button 
                onClick={() => setView('disputes')}
                title={lang === 'ur' ? 'شکایات' : 'Disputes'}
                className={`flex items-center justify-center px-3 py-2 rounded-xl transition-all ${view === 'disputes' ? 'bg-rose-500 text-white shadow-sm font-black' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <AlertCircle className="w-4 h-4" />
              </button>
              {(profile?.isAdmin === true || profile?.phoneNumber === '+923000000001' || profile?.role === 'Admin' || profile?.role === 'admin') && (
                <button 
                  onClick={() => setView('admin')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'admin' ? 'bg-indigo-600 text-white shadow-sm' : 'text-indigo-500 hover:text-indigo-700'}`}
                >
                  <Scale className="w-4 h-4" />
                  <span className="hidden xs:inline">Admin Hub 👑</span>
                </button>
              )}
            </div>
          </div>
 
          {/* Balance & Actions */}
          <div className="flex items-center justify-between lg:justify-end gap-4 w-full lg:w-auto bg-transparent p-0 rounded-2xl border-0">
            {profile && (
              <div className="flex items-center gap-3">
                <div className="text-left">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none block">Welcome,</span>
                  <span className="text-xs font-black text-emerald-600 tracking-tight leading-none mt-1 block">{getFirstName()}</span>
                </div>
              </div>
            )}
            <div className="flex items-center gap-3 ml-auto lg:ml-0">
              <button 
                onClick={() => setIsProfileOpen(true)}
                className="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-emerald-600 hover:border-emerald-200 transition-all shadow-sm cursor-pointer"
                title="Profile & Terms"
              >
                <UserIcon className="w-5 h-5" />
              </button>
 
              <button 
                onClick={logout}
                className="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-rose-600 hover:border-rose-200 transition-all shadow-sm cursor-pointer"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
 
        </div>
      </div>
      <ProfileModal 
        isOpen={isProfileOpen} 
        onClose={() => setIsProfileOpen(false)} 
        onOpenTerms={() => {
          setIsProfileOpen(false);
          setIsTermsOpen(true);
        }}
      />
      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
    </nav>
  );
}

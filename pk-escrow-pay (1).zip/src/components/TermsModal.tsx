import React from 'react';
import { X, Shield, ShieldAlert, CheckCircle2, FileText, Scale, Camera, AlertCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsModal({ isOpen, onClose }: TermsModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden relative z-10 flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="bg-slate-900 px-8 py-6 text-white flex justify-between items-center relative overflow-hidden">
              <div className="absolute right-0 top-0 opacity-10 transform translate-x-12 -translate-y-8">
                <Scale className="w-56 h-56" />
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/30">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-black tracking-tight uppercase">Platform T&C & Dispute Policy</h2>
                  <p className="text-xs text-slate-300 font-bold">Rules & Dispute Policy</p>
                </div>
              </div>
              
              <button 
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-all cursor-pointer relative z-20"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content area */}
            <div className="p-8 overflow-y-auto custom-scrollbar flex-1 space-y-6 text-sm text-slate-600">
              
              {/* Introduction Banner */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 rounded-2xl p-5 flex gap-4">
                <Sparkles className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-extrabold text-emerald-950 text-sm">Protection of Escrow Funds & Honest Earnings</h3>
                  <p className="text-xs text-emerald-800 leading-relaxed font-semibold mt-1">
                    PK Escrow is a secure, clean, and transparent system. Strict legal action and permanent account bans will be enforced against anyone attempting fake transactions, falsified testimony, or any form of fraud.
                  </p>
                </div>
              </div>

              {/* SECTION 1: DISPUTE SYSTEM & PROOFS */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-rose-600 font-extrabold text-base tracking-tight uppercase">
                  <ShieldAlert className="w-5 h-5" />
                  <h4>1. Dispute Resolution & File Proof Requirements</h4>
                </div>
                
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4">
                  <p className="font-bold text-slate-900 leading-relaxed text-xs">
                    If any issue arises during an escrow deal (for example, the seller does not deliver the product, or the buyer files a false report), either party can open a dispute. The resolution workflow follows these strict rules:
                  </p>

                  <ul className="space-y-3.5 text-xs text-slate-700 font-medium list-none">
                    <li className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-600 font-black flex items-center justify-center text-[10px] shrink-0">1</span>
                      <div>
                        <strong className="text-slate-900">24-Hour Evidence Submission Deadline:</strong>
                        <p className="text-slate-500 mt-1 leading-relaxed">
                          Once a dispute is opened, both parties (Buyer and Seller) must submit authentic video proof, transaction receipts, and chat history screenshots within <strong>24 hours</strong>. Failure to submit sufficient proof within this timeframe will result in the dispute being resolved in favor of the opposing party.
                        </p>
                      </div>
                    </li>

                    <li className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-600 font-black flex items-center justify-center text-[10px] shrink-0">2</span>
                      <div>
                        <strong className="text-slate-900">Valid Proof Formats & Verified Receipt Guidelines:</strong>
                        <p className="text-slate-500 mt-1 leading-relaxed">
                          Only verified links and image uploads are accepted. Visual proof must clearly display the <strong>Transaction ID (TID)</strong>, date, amount, and recipient's account name without any blurring or edits.
                        </p>
                      </div>
                    </li>

                    <li className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-600 font-black flex items-center justify-center text-[10px] shrink-0">3</span>
                      <div>
                        <strong className="text-slate-900">Zero Tolerance for Forgery & Falsification:</strong>
                        <p className="text-slate-500 mt-1 leading-relaxed">
                          Any attempt to submit altered, falsified, or inspect-element modified screenshots/receipts will result in an immediate and permanent <strong>account ban</strong>. Any ongoing escrow funds and transaction privileges will be permanently forfeited.
                        </p>
                      </div>
                    </li>

                    <li className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-600 font-black flex items-center justify-center text-[10px] shrink-0">4</span>
                      <div>
                        <strong className="text-slate-900">Moderator Final and Binding Verdict:</strong>
                        <p className="text-slate-500 mt-1 leading-relaxed">
                          Based on transaction audits, secure background database logs, and evidence, the platform's independent moderators will render a final, legally binding decision that cannot be appealed or challenged.
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>

              {/* SECTION 2: SAFE ESCROW DEPOSITS & PAYOUTS */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-emerald-600 font-extrabold text-base tracking-tight uppercase">
                  <Scale className="w-5 h-5" />
                  <h4>2. Safe Escrow Deposits & Payouts Protocol</h4>
                </div>

                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-3.5 text-xs text-slate-700 font-medium">
                  <div className="flex gap-2.5 items-start">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900">Transactional ID (TID) Validation:</strong>
                      <p className="text-slate-500 mt-0.5">Every manual EasyPaisa, JazzCash, or bank transfer requires a unique, valid Transaction ID (TID) for credit verification. Users attempting to reuse or submit duplicate TIDs will have their accounts locked for investigation.</p>
                    </div>
                  </div>

                  <div className="flex gap-2.5 items-start">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900">Direct External Payout Dispatch:</strong>
                      <p className="text-slate-500 mt-0.5">Upon successful transaction completion, funds are dispatched directly to your designated EasyPaisa, JazzCash, or Raast Bank account. Admins verify and dispatch the payout securely, avoiding the risks of storing in-app wallet balances.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 3: ACCOUNT & MPIN SAFETY */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-indigo-600 font-extrabold text-base tracking-tight uppercase">
                  <Shield className="w-5 h-5" />
                  <h4>3. Security Verification & Mobile PIN Safety</h4>
                </div>

                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-3.5 text-xs text-slate-700 font-medium">
                  <p className="text-slate-600 italic leading-relaxed">
                    Never share your 4-digit transaction validation PIN (MPIN) with anyone! Your MPIN is used to authorize the release of escrow funds. If you forget your security PIN, it can be securely reset through your registered security verification questions (Mother's Maiden Name and Place of Birth).
                  </p>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="bg-slate-50 px-8 py-5 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Version 2.4 (Security Hardened)</span>
              <button
                onClick={onClose}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-md"
              >
                I Read & Accept the Terms
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

import React from 'react';

export type EscrowStatus = 'PROPOSED' | 'ACCEPTED' | 'FUNDED' | 'SHIPPED' | 'DELIVERED' | 'COMPLETED' | 'DISPUTED' | 'CANCELLED';

const STATUS_CONFIG: Record<EscrowStatus, { label: string; className: string }> = {
  PROPOSED: { label: 'Proposed', className: 'bg-slate-100 text-slate-700 border-slate-200' },
  ACCEPTED: { label: 'Accepted', className: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
  FUNDED: { label: 'Funded', className: 'bg-blue-50 text-blue-700 border-blue-200' },
  SHIPPED: { label: 'Shipped', className: 'bg-violet-50 text-violet-700 border-violet-200' },
  DELIVERED: { label: 'Delivered', className: 'bg-amber-50 text-amber-700 border-amber-200' },
  COMPLETED: { label: 'Completed', className: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  DISPUTED: { label: 'Disputed', className: 'bg-rose-50 text-rose-700 border-rose-200' },
  CANCELLED: { label: 'Cancelled', className: 'bg-slate-100 text-slate-500 border-slate-200' },
};

export function StatusBadge({ status }: { status: EscrowStatus }) {
  const config = STATUS_CONFIG[status];
  return (
    <span id={`status-${status.toLowerCase()}`} className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${config.className}`}>
      {config.label}
    </span>
  );
}

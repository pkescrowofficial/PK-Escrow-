import React, { useState, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { X, User, Mail, CreditCard, Building2, Camera, Check, AlertCircle, Scale, Phone, Lock } from 'lucide-react';
import { normalizePhoneNumber } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { watermarkImage, compressImage } from '../lib/watermark';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTerms?: () => void;
}

export function ProfileModal({ isOpen, onClose, onOpenTerms }: ProfileModalProps) {
  const { user, profile, logout } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Deletion States
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [deletePhone, setDeletePhone] = useState('');
  const [deleteMpinCode, setDeleteMpinCode] = useState('');
  const [deleteValidationError, setDeleteValidationError] = useState<string | null>(null);

  // Form state
  const [fullName, setFullName] = useState(profile?.displayName || '');
  const [email, setEmail] = useState(profile?.email || '');
  const [cnic, setCnic] = useState(profile?.cnicNumber || '');
  const [iban, setIban] = useState(profile?.ibanNumber || '');
  const [bankName, setBankName] = useState(profile?.bankName || '');
  const [accountHolder, setAccountHolder] = useState(profile?.accountHolderName || '');
  const [easypaisaNumber, setEasypaisaNumber] = useState(profile?.easypaisaNumber || '');
  const [jazzcashNumber, setJazzcashNumber] = useState(profile?.jazzcashNumber || '');
  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [cnicFront, setCnicFront] = useState(profile?.cnicFrontImage || null);
  const [cnicBack, setCnicBack] = useState(profile?.cnicBackImage || null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cnicFrontRef = useRef<HTMLInputElement>(null);
  const cnicBackRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const rawPhone = profile?.phoneNumber || '';
      const maskedPhone = rawPhone.length > 7 ? (rawPhone.slice(0, 5) + '***' + rawPhone.slice(-3)) : '***';
      await updateDoc(doc(db, 'users', user.uid), {
        displayName: fullName,
        email,
        cnicNumber: cnic,
        ibanNumber: iban,
        bankName,
        accountHolderName: accountHolder,
        easypaisaNumber,
        jazzcashNumber,
        photoURL,
        cnicFrontImage: cnicFront,
        cnicBackImage: cnicBack,
        maskedAccountNumber: maskedPhone,
        updatedAt: new Date().toISOString()
      });
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setIsDeleting(true);
    setError(null);
    setDeleteValidationError(null);
    try {
      const normalizedInput = normalizePhoneNumber(deletePhone);
      const normalizedProfile = normalizePhoneNumber(profile?.phoneNumber || '');

      if (normalizedInput !== normalizedProfile) {
        setDeleteValidationError("Phone number does not match registered account number! درج کردہ فون نمبر درست نہیں ہے۔");
        setIsDeleting(false);
        return;
      }

      if (deleteMpinCode !== (profile?.mpin || '')) {
        setDeleteValidationError("Incorrect Security MPIN! غلط سیکیورٹی ایم پن درج کیا گیا ہے۔");
        setIsDeleting(false);
        return;
      }

      await updateDoc(doc(db, 'users', user.uid), {
        isDeleted: true,
        onboardingStatus: 'DELETED',
        displayName: `${profile?.displayName || 'User'} (Deleted Account / مستقل حذف شدہ)`,
        deletedAt: new Date().toISOString()
      });
      alert("Your account has been permanently deleted. آپ کا اکاؤنٹ مستقل طور پر حذف کر دیا گیا ہے۔");
      onClose();
      await logout();
    } catch (err: any) {
      console.error("Account deletion failed:", err);
      setError(err.message || 'Failed to permanently delete account');
    } finally {
      setIsDeleting(false);
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        try {
          const compressed = await compressImage(rawBase64, 400, 0.70); // App-focused size
          setPhotoURL(compressed);
        } catch (err) {
          console.error("Error compressing profile photo:", err);
          setPhotoURL(rawBase64); // fallback
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCnicChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'front' | 'back') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        try {
          const stamped = await watermarkImage(base64, {
            text: "PK ESCROW VERIFICATION ONLY",
            subtext: profile?.displayName ? `IDENTITY: ${profile.displayName}` : "MERCHANT PERSONAL ACCOUNT"
          });
          if (type === 'front') setCnicFront(stamped);
          else setCnicBack(stamped);
        } catch (err) {
          if (type === 'front') setCnicFront(base64);
          else setCnicBack(base64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden relative z-10"
          >
            <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Personal Information</h2>
              <button onClick={onClose} className="p-2.5 hover:bg-slate-200/50 rounded-2xl transition-all active:scale-95">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-8 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
              {error && (
                <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl flex gap-3 text-rose-600 text-sm font-bold animate-shake">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl flex gap-3 text-emerald-600 text-sm font-bold animate-fade-in">
                  <Check className="w-5 h-5 shrink-0" />
                  <span>Profile updated successfully!</span>
                </div>
              )}

              {/* Profile Picture */}
              <div className="flex flex-col items-center gap-4 mb-8">
                <div 
                  className="relative group cursor-pointer" 
                  onClick={() => fileInputRef.current?.click()}
                >
                  <div className="w-28 h-28 rounded-[2rem] bg-slate-100 border-4 border-white shadow-xl overflow-hidden relative">
                    {photoURL ? (
                      <img src={photoURL} alt="Profile" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-300">
                        <User className="w-12 h-12" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <Camera className="w-8 h-8" />
                    </div>
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-emerald-600 text-white p-2 rounded-xl shadow-lg">
                    <Camera className="w-4 h-4" />
                  </div>
                  <input 
                    ref={fileInputRef}
                    type="file" accept="image/*" className="hidden"
                    onChange={handlePhotoChange}
                  />
                </div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tap to change avatar</p>
                
                {/* Daily Channel limit status block */}
                <div className="mt-2.5 flex flex-col items-center gap-1 bg-slate-50 border border-slate-150 px-4 py-2 rounded-2xl">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] font-black text-slate-700 uppercase tracking-wider">
                      Daily Channel Cap: Rs. 2,000,000
                    </span>
                  </div>
                  <span className="text-[8px] font-medium text-slate-400 italic">PK Escrow Securities Sovereign Limits</span>
                </div>
              </div>

              <div className="space-y-5">
                {/* Registered Phone / Account Number */}
                <div>
                  <label className="block text-[10px] font-black text-rose-600 uppercase tracking-[0.2em] mb-2 px-1">Registered Account / Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                    <input 
                      type="text"
                      disabled
                      value={(() => {
                        const num = profile?.phoneNumber || '';
                        if (num.length > 7) {
                          return num.slice(0, 5) + '***' + num.slice(-3);
                        }
                        return num || '***';
                      })()}
                      className="w-full bg-slate-100 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 font-bold text-slate-500 cursor-not-allowed text-lg"
                    />
                  </div>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                    <input 
                      type="text" required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Your full name"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-lg"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                    <input 
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="email@example.com"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-lg"
                    />
                  </div>
                </div>

                {/* CNIC */}
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">CNIC Number</label>
                  <div className="relative">
                    <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                    <input 
                      type="text"
                      value={cnic}
                      onChange={(e) => setCnic(e.target.value)}
                      placeholder="42XXX-XXXXXXX-X"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-4 font-bold text-slate-900 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-lg"
                    />
                  </div>
                </div>

                {/* CNIC Pictures */}
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">CNIC Front</label>
                    <div 
                      className="relative group aspect-[1.6/1] bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500/50 hover:bg-emerald-50/30 transition-all overflow-hidden"
                      onClick={() => cnicFrontRef.current?.click()}
                    >
                      {cnicFront ? (
                        <img src={cnicFront} alt="CNIC Front" className="w-full h-full object-cover" />
                      ) : (
                        <Camera className="w-6 h-6 text-slate-300 group-hover:text-emerald-500 transition-colors" />
                      )}
                      <input 
                        ref={cnicFrontRef}
                        type="file" accept="image/*" className="hidden"
                        onChange={(e) => handleCnicChange(e, 'front')}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-1">CNIC Back</label>
                    <div 
                      className="relative group aspect-[1.6/1] bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500/50 hover:bg-emerald-50/30 transition-all overflow-hidden"
                      onClick={() => cnicBackRef.current?.click()}
                    >
                      {cnicBack ? (
                        <img src={cnicBack} alt="CNIC Back" className="w-full h-full object-cover" />
                      ) : (
                        <Camera className="w-6 h-6 text-slate-300 group-hover:text-emerald-500 transition-colors" />
                      )}
                      <input 
                        ref={cnicBackRef}
                        type="file" accept="image/*" className="hidden"
                        onChange={(e) => handleCnicChange(e, 'back')}
                      />
                    </div>
                  </div>
                </div>

                {/* P2P Receiving / Payout Accounts Section */}
                <div className="border-t border-slate-100 pt-5 mt-5 space-y-4">
                  <h3 className="text-xs font-black text-indigo-700 uppercase tracking-widest flex items-center gap-1.5">
                    🛡️ P2P Payout & Receiving Accounts
                  </h3>
                  <p className="text-[10px] font-bold text-slate-500 leading-relaxed -mt-1 text-left">
                    Enter details where you wish to receive buyer transfers. Buyers will transfer directly to these accounts when funding your secure deals.
                  </p>

                  <div className="bg-slate-50 border border-slate-200/60 p-4 rounded-3xl space-y-3 text-left">
                    <div className="space-y-1">
                      <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider px-1">Account Holder Name (For Verification)</label>
                      <input 
                        type="text"
                        value={accountHolder}
                        onChange={(e) => setAccountHolder(e.target.value)}
                        placeholder="e.g. Muhammad Usman"
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/10 placeholder:text-slate-300"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider px-1">Bank Name</label>
                        <input 
                          type="text"
                          value={bankName}
                          onChange={(e) => setBankName(e.target.value)}
                          placeholder="e.g. HBL, Meezan, SadaPay"
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/10 placeholder:text-slate-300"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[9px] font-black text-slate-400 uppercase tracking-wider px-1">IBAN / Account Number</label>
                        <input 
                          type="text"
                          value={iban}
                          onChange={(e) => setIban(e.target.value)}
                          placeholder="PK00 SADA 123456..."
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/10 placeholder:text-slate-300 font-mono text-[11px]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 border-t border-slate-200/50 pt-3">
                      <div className="space-y-1">
                        <label className="block text-[9px] font-black text-emerald-600 uppercase tracking-wider px-1 flex items-center gap-1">
                          🟢 EasyPaisa Account
                        </label>
                        <input 
                          type="tel"
                          value={easypaisaNumber}
                          onChange={(e) => setEasypaisaNumber(e.target.value)}
                          placeholder="e.g. 03450000000"
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 placeholder:text-slate-300 font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[9px] font-black text-red-600 uppercase tracking-wider px-1 flex items-center gap-1">
                          🟠 JazzCash Account
                        </label>
                        <input 
                          type="tel"
                          value={jazzcashNumber}
                          onChange={(e) => setJazzcashNumber(e.target.value)}
                          placeholder="e.g. 03000000000"
                          className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-500/10 placeholder:text-slate-300 font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 space-y-3">
                <button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-black py-5 rounded-[2rem] transition-all shadow-xl shadow-slate-900/10 active:scale-95 cursor-pointer text-sm"
                >
                  {loading ? 'Saving Changes...' : 'Save Profile'}
                </button>

                {onOpenTerms && (
                  <button 
                    type="button"
                    onClick={onOpenTerms}
                    className="w-full bg-slate-105 hover:bg-slate-100 text-slate-700 font-extrabold py-4 rounded-[2rem] transition-all flex items-center justify-center gap-2 border border-slate-200 cursor-pointer text-xs"
                    id="profile-terms-btn"
                  >
                    <Scale className="w-4 h-4 text-emerald-600 animate-pulse" />
                    <span>Terms and conditions</span>
                  </button>
                )}

                {/* Danger Zone: Permanently Delete Account */}
                <div className="border-t border-slate-100 pt-6 mt-6">
                  <div className="bg-rose-50 border border-rose-100 p-5 rounded-[2rem] space-y-4 text-left">
                    <div>
                      <h3 className="text-sm font-black text-rose-800 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        Danger Zone / خطرہ زون
                      </h3>
                      <p className="text-[11px] text-rose-700 font-bold mt-1.5 leading-relaxed">
                        Permanently delete your account. This will completely wipe your identity, zero out active wallet status, and freeze remaining balances. Secure records are processed instantly, and you will be logged out.
                      </p>
                      <p className="text-[10px] text-rose-600/90 font-medium mt-1 leading-relaxed">
                        اپنا اکاؤنٹ مستقل طور پر حذف کریں۔ یہ آپ کا اکاؤنٹ منقطع کر دے گا اور بیلنس منجمد کر دیا جائے گا۔ یہ عمل ناقابل واپسی ہے۔
                      </p>
                    </div>

                    {confirmDelete ? (
                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-rose-900 uppercase tracking-widest bg-rose-100/50 p-2.5 rounded-xl border border-rose-200 text-center">
                          ⚠️ Identity Verification / تصدیقِ شناخت
                        </p>

                        {deleteValidationError && (
                          <div id="delete-account-status" className="bg-rose-100/90 text-rose-800 p-3 rounded-xl text-[10px] font-black border border-rose-300 flex gap-2 items-center leading-relaxed animate-shake">
                            <AlertCircle className="w-4 h-4 shrink-0 text-rose-700" />
                            <span>{deleteValidationError}</span>
                          </div>
                        )}

                        <div className="space-y-1.5">
                          <label className="block text-[9px] font-black text-rose-800 uppercase tracking-wider px-1">Registered Phone Number / فون نمبر</label>
                          <div className="relative">
                            <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-400" />
                            <input
                              type="tel"
                              id="delete-account-phone"
                              required
                              placeholder="e.g. 03XXXXXXXXX"
                              value={deletePhone}
                              onChange={(e) => {
                                setDeletePhone(e.target.value);
                                setDeleteValidationError(null);
                              }}
                              className="w-full bg-white border border-rose-200 rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold text-rose-950 focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-400 transition-all shadow-inner"
                            />
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <label className="block text-[9px] font-black text-rose-800 uppercase tracking-wider px-1">4-Digit Security MPIN / سیکیورٹی پن کوڈ</label>
                          <div className="relative">
                            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-400" />
                            <input
                              type="password"
                              id="delete-account-mpin"
                              required
                              maxLength={4}
                              placeholder="●●●●"
                              value={deleteMpinCode}
                              onChange={(e) => {
                                setDeleteMpinCode(e.target.value.replace(/\D/g, ''));
                                setDeleteValidationError(null);
                              }}
                              className="w-full bg-white border border-rose-200 rounded-xl pl-10 pr-4 py-2.5 text-xs font-black tracking-widest text-rose-950 focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-400 transition-all shadow-inner"
                            />
                          </div>
                        </div>

                        <p className="text-[10px] font-black text-rose-900 uppercase tracking-widest bg-rose-100/50 p-2.5 rounded-xl border border-rose-200 text-center">
                          ⚠️ Type "DELETE" to authorize / تصدیق کے لیے "DELETE" لکھیں
                        </p>
                        <input
                          type="text"
                          placeholder='Type "DELETE"'
                          value={deleteConfirmText}
                          onChange={(e) => setDeleteConfirmText(e.target.value)}
                          className="w-full bg-white border border-rose-300 rounded-2xl px-4 py-3 font-black text-rose-900 focus:outline-none focus:ring-4 focus:ring-rose-500/10 focus:border-rose-500 transition-all text-center text-sm shadow-inner"
                        />
                        <div className="grid grid-cols-2 gap-3 pt-1">
                          <button
                            type="button"
                            disabled={deleteConfirmText !== 'DELETE' || !deletePhone || deleteMpinCode.length < 4 || isDeleting}
                            onClick={handleDeleteAccount}
                            className="w-full bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-black py-3 rounded-xl transition-all cursor-pointer text-xs"
                          >
                            {isDeleting ? 'Deleting...' : 'Yes, Delete Account'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setConfirmDelete(false);
                              setDeleteConfirmText('');
                              setDeletePhone('');
                              setDeleteMpinCode('');
                              setDeleteValidationError(null);
                            }}
                            className="w-full bg-slate-200 hover:bg-slate-300 text-slate-700 font-extrabold py-3 rounded-xl transition-all cursor-pointer text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDelete(true)}
                        className="w-full bg-rose-100 hover:bg-rose-200 text-rose-700 font-black py-3.5 rounded-2xl transition-all flex items-center justify-center gap-2 border border-rose-20 border-rose-200 cursor-pointer text-xs"
                      >
                        <span>Permanently Delete My Account / اکاؤنٹ مستقل حذف کریں</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

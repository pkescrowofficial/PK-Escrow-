/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useAuth, AuthProvider } from './hooks/useAuth';
import { DashboardView } from './views/DashboardView';
import { TransactionsView } from './views/TransactionsView';
import { DisputesView } from './views/DisputesView';
import { ChatView } from './views/ChatView';
import { AdminView } from './views/AdminView';
import { LoginView } from './views/LoginView';
import { RegistrationView } from './views/RegistrationView';
import { VerificationView } from './views/VerificationView';
import { MpinView } from './views/MpinView';
import { PublicVerificationView } from './views/PublicVerificationView';
import { ShieldCheck } from 'lucide-react';

function AppContent() {
  const { user, profile, loading, view } = useAuth();

  const params = new URLSearchParams(window.location.search);
  const verifyId = params.get('verify') || params.get('v');

  if (verifyId) {
    return <PublicVerificationView verifyId={verifyId} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center flex-col gap-4">
        <div className="bg-emerald-600 p-3 rounded-2xl animate-bounce shadow-xl">
          <ShieldCheck className="text-white w-10 h-10" />
        </div>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Securing session...</p>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  // Handle onboarding flow
  if (!profile || !profile.onboardingStatus || profile.onboardingStatus === 'PENDING') {
    return <RegistrationView />;
  }

  if (profile.onboardingStatus === 'REGISTERED') {
    return <VerificationView />;
  }

  if (profile.onboardingStatus === 'VERIFIED') {
    return <MpinView />;
  }

  if (view === 'chat') {
    return <ChatView />;
  }

  if (view === 'admin') {
    const isAdmin = profile?.isAdmin === true || profile?.phoneNumber === '+923000000001' || profile?.role === 'Admin' || profile?.role === 'admin';
    if (!isAdmin) {
      return <DashboardView />;
    }
    return <AdminView />;
  }

  if (view === 'disputes') {
    return <DisputesView />;
  }

  return view === 'dashboard' ? <DashboardView /> : <TransactionsView />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

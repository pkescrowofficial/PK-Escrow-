import { jsPDF } from 'jspdf';
import { Escrow } from '../components/EscrowCard';

export function generateReceiptPDF(escrow: Escrow, isBuyer: boolean, counterpartyName?: string, qrBase64?: string) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const primaryColor = [15, 23, 42]; // Slate 900
  const accentColor = [16, 185, 129]; // Emerald 500
  const subtextColor = [100, 116, 139]; // Slate 500
  const lightBgColor = [248, 250, 252]; // Slate 50

  // 1. Draw elegant accent border
  doc.setDrawColor(226, 232, 240); // border-slate-200
  doc.setLineWidth(0.5);
  doc.rect(5, 5, 200, 287);

  // Decorative top color bar
  doc.setFillColor(15, 23, 42);
  doc.rect(5, 5, 200, 4, 'F');

  // 2. Main Title Header (PK Escrow Digital Stamp)
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('PK ESCROW SECURED RECEIPT', 12, 24);

  // Subtitle
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(subtextColor[0], subtextColor[1], subtextColor[2]);
  doc.text('SOVEREIGN SECURE MULTI-SIG LOCK & KEY LEDGER AGREEMENT', 12, 30);

  // Timestamp on top right
  const dateObj = escrow.createdAt?.seconds ? new Date(escrow.createdAt.seconds * 1000) : (escrow.createdAt ? new Date(escrow.createdAt) : new Date());
  const dateStr = !isNaN(dateObj.getTime()) ? dateObj.toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) + ' (PKT)' : 'N/A';
  
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(`ISSUED STATUS: ${escrow.status}`, 198, 24, { align: 'right' });
  doc.setFont('Helvetica', 'normal');
  doc.text(`DATE: ${dateStr}`, 198, 30, { align: 'right' });

  // Draw separator line
  doc.setDrawColor(226, 232, 240);
  doc.line(12, 36, 198, 36);

  // 3. Receipt Status Panel / Block
  doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
  doc.rect(12, 42, 186, 22, 'F');
  doc.setDrawColor(241, 245, 249);
  doc.rect(12, 42, 186, 22, 'D');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('SECURE VAULT REFERENCE KEY:', 18, 50);

  doc.setFont('Courier', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(escrow.id.toUpperCase(), 18, 56);

  // Draw safe badge
  doc.setFillColor(16, 185, 129);
  doc.rect(142, 48, 48, 10, 'F');
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('100% SECURE SYSTEM', 166, 54, { align: 'center' });

  // 4. AGREEMENT DESCRIPTION & CATEGORY DETAILS
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('I. LOCKED ASSETS & COVENANT DETAILS', 12, 76);

  // Subtle table block for details
  const startY = 82;
  const rowHeight = 8;
  const labelX = 14;
  const valX = 75;

  const fields = [
    { label: 'Agreement Subject / Title:', val: escrow.itemDescription },
    { label: 'Asset Delivery Channel Mode:', val: escrow.deliveryMode ? escrow.deliveryMode.toUpperCase() : 'STANDARD ESCROW' },
    { label: 'Active Transaction Stage:', val: escrow.status },
    { label: 'Tracking Courier / Delivery Link:', val: escrow.trackingId ? `${escrow.courier || 'TCS'} - ID: ${escrow.trackingId}` : 'NOT SHIPPED / PENDING DISPATCH' },
    { label: 'Custom Deadlines / Milestones:', val: escrow.projectDeadlines || 'STANDARDIZED IMMEDIATE RELEASE' }
  ];

  doc.setFontSize(8.5);
  fields.forEach((field, idx) => {
    const currentY = startY + (idx * rowHeight);

    // Alternate row bg
    if (idx % 2 === 0) {
      doc.setFillColor(248, 250, 252);
      doc.rect(12, currentY - 5, 186, rowHeight, 'F');
    }

    doc.setFont('Helvetica', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(field.label, labelX, currentY);

    doc.setFont('Helvetica', 'normal');
    doc.setTextColor(30, 41, 59);
    
    // Auto wrap description to avoid lines overflowing right margin (around 195)
    const maxLen = 70;
    let descriptionText = String(field.val || 'N/A');
    if (descriptionText.length > maxLen) {
      descriptionText = descriptionText.substring(0, maxLen - 3) + '...';
    }
    doc.text(descriptionText, valX, currentY);
  });

  // 5. LEDGER LEDGERS / FINANCIAL TRANSACTIONS
  const finY = 135;
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('II. FINANCIAL STATEMENTS & VAULT HOLDINGS', 12, finY);

  const subtotal = Number(escrow.amount || 0);
  const fee = Number(escrow.escrowFee || 0);
  const total = Number(escrow.totalAmount || subtotal);

  doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
  doc.rect(12, finY + 6, 186, 30, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.rect(12, finY + 6, 186, 30, 'D');

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(subtextColor[0], subtextColor[1], subtextColor[2]);
  doc.text('Locked Subtotal Balance:', 18, finY + 14);
  doc.setFont('Helvetica', 'normal');
  doc.text(`Rs. ${subtotal.toLocaleString()}`, 115, finY + 14);

  doc.setFont('Helvetica', 'bold');
  doc.text('Escrow Verification Fee (Promo 0%):', 18, finY + 21);
  doc.setFont('Helvetica', 'normal');
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(fee > 0 ? `Rs. ${fee.toLocaleString()}` : 'FREE (Promo)', 115, finY + 21);

  doc.setDrawColor(203, 213, 225);
  doc.line(18, finY + 25, 192, finY + 25);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('TOTAL SECURED MULTI-SIG ESCROW VALUE:', 18, finY + 31);
  doc.setFont('Helvetica', 'bold');
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(`PKR ${total.toLocaleString()}/-`, 115, finY + 31);

  // 6. PARTICIPANT ROLES
  const partY = 185;
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('III. CONTRACTOR PARTICIPANTS & DELEGATED AUTHORIZATIONS', 12, partY);

  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  
  // Buyer Card
  doc.rect(12, partY + 6, 90, 42);
  doc.setFillColor(15, 23, 42);
  doc.rect(12, partY + 6, 90, 7, 'F');
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('BUYER DELEGATION', 57, partY + 11, { align: 'center' });

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(`Name: ${isBuyer ? 'YOU (Verified)' : (counterpartyName || 'Offline Participant')}`, 16, partY + 20);
  doc.text(`Contact ID: ${escrow.buyerPhone}`, 16, partY + 27);
  doc.text('Status: APPROVED AUTHORIZED', 16, partY + 34);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.setFont('Courier', 'bold');
  doc.text('SIGNATURE SYSTEM LOCK // APPROVED', 16, partY + 41);

  // Seller Card
  doc.setFillColor(255, 255, 255);
  doc.rect(108, partY + 6, 90, 42);
  doc.setFillColor(15, 23, 42);
  doc.rect(108, partY + 6, 90, 7, 'F');
  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text('SELLER DELEGATION', 153, partY + 11, { align: 'center' });

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(`Name: ${!isBuyer ? 'YOU (Verified)' : (counterpartyName || 'Offline Participant')}`, 112, partY + 20);
  doc.text(`Contact ID: ${escrow.sellerPhone}`, 112, partY + 27);
  doc.text('Status: APPROVED AUTHORIZED', 112, partY + 34);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.setFont('Courier', 'bold');
  doc.text('SIGNATURE SYSTEM LOCK // APPROVED', 112, partY + 41);

  // 7. PUBLIC SOVEREIGN LEGAL NOTICE & GUARANTOR STAMP
  const stampY = 245;
  doc.setDrawColor(226, 232, 240);
  doc.line(12, stampY, 198, stampY);

  doc.setFont('Helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('IV. GUARANTOR PUBLIC COMPLIANCE NOTICE', 12, stampY + 8);

  // Render scan QR block
  if (qrBase64) {
    try {
      doc.addImage(qrBase64, 'PNG', 12, stampY + 11, 22, 22);
    } catch (err) {
      console.warn('Could not render QR code in PDF:', err);
    }
  } else {
    // Elegant fallback border pattern
    doc.setDrawColor(226, 232, 240);
    doc.rect(12, stampY + 11, 22, 22);
    doc.setFont('Courier', 'bold');
    doc.setFontSize(5);
    doc.text('SCANNABLE', 23, stampY + 20, { align: 'center' });
    doc.text('VERIFICATION', 23, stampY + 23, { align: 'center' });
  }

  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(subtextColor[0], subtextColor[1], subtextColor[2]);
  
  // Legal compliance paragraph text line by line - shifted to start at x=38 to make beautiful room for scanned QR
  doc.text('This receipt serves as an immutable ledger holding confirmation generated dynamically by the PK Escrow Sovereign Protocol.', 38, stampY + 14);
  doc.text('All locked values are fully protected from arbitrary chargebacks, spoof accounts, and unilateral cancellations by our 24/7', 38, stampY + 18);
  doc.text('internal sovereign arbitration. Scan the QR code to verify this transaction live on our verified portal.', 38, stampY + 22);

  // Footer visual stamp
  doc.setFillColor(15, 23, 42);
  doc.rect(140, stampY + 27, 58, 12, 'F');
  doc.setFont('Courier', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text('PK ESCROW DIGITAL STAMP', 169, stampY + 32, { align: 'center' });
  doc.setFont('Courier', 'normal');
  doc.text('GUARANTEED CRYPTO LOCK', 169, stampY + 36, { align: 'center' });

  // Page numbering and automated audit string
  doc.setFont('Helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text('Guarantor Ledger Copy Page 1 of 1 • Internal Audit System Approved • https://pk-secured-escrow.gov', 12, 282);

  return doc;
}

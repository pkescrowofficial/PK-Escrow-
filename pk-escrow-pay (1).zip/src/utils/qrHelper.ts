/**
 * Dynamic QR Code Base64 Generator for PK Escrow
 */
export function getQRBase64(data: string): Promise<string> {
  const size = 180;
  // Using secure stable global api.qrserver.com
  const url = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(data)}`;
  
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = url;
    
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/png'));
        } else {
          resolve('');
        }
      } catch (err) {
        console.warn('Canvas conversion failed for QR code:', err);
        resolve('');
      }
    };
    
    img.onerror = () => {
      console.warn('QR Code image asset load failed, fallback matrix will be used');
      resolve('');
    };
  });
}

/**
 * Returns a clean, direct QR server URL for immediate client components (img elements)
 */
export function getQRImageUrl(data: string, size = 200): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(data)}&margin=1`;
}
